# Статический план проверки Moodle ТУСУР 0.4.7

Этот план проверяет исходники без запуска Gradle или сборки APK.

1. Запустить `python scripts/verify-source-static.py` из любой рабочей папки.
2. Убедиться, что скрипт находит 15 Kotlin-файлов и не сообщает о неразрешённых внутренних импортах или незакрытых строках/скобках.
3. Убедиться, что в `MoodleWebViewScreen.kt` запрос создаётся через `DownloadManager.Request(uri).apply { ... }`.
4. Убедиться, что `User-Agent` и `Cookie` добавляются внутри этого блока.
5. Убедиться, что после создания запроса вызывается `downloadManager.enqueue(request)`.
6. Убедиться, что `allowScanningByMediaScanner()` больше не используется в коде.
7. Сверить `versionName=0.4.7`, `versionCode=21`, `applicationId=ru.tusur.study`.

Ожидаемый результат скрипта — `PASS`. Скрипт не запускает компиляцию, Gradle или Android SDK.
