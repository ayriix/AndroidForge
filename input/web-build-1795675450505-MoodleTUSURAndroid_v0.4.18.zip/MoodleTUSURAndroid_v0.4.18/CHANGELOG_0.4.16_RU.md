# Moodle.TUSUR 0.4.16

- Исправлен отсутствующий импорт `isMoodleFinishedAttempt` в `MainActivity.kt`.
- `HttpUrl.get(String)` заменён на Kotlin API OkHttp 4 `toHttpUrlOrNull()` в нативной авторизации.
- Устранена каскадная ошибка разрешения `MoodleNativeLoginRepository` в `MoodleViewModel.kt`.
- Версия приложения: 0.4.16 (versionCode 30).
- Восстановлен импорт `android.webkit.CookieManager`, который требуется для очистки WebView cookies при выходе из аккаунта.
