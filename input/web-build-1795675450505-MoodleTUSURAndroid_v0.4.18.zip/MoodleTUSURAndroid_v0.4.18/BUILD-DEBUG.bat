@echo off
setlocal
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\bootstrap-and-build.ps1"
if errorlevel 1 (
  echo.
  echo Build failed. Open the project in Android Studio and read ANDROID_START_GUIDE_RU.md.
  pause
  exit /b 1
)
echo.
echo Debug APK created in app\build\outputs\apk\debug\app-debug.apk
pause
endlocal
