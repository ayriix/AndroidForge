# Проверка исходников Moodle.TUSUR 0.4.9

## Исправленные причины ошибок 0.4.8

1. `formatQuizEpoch(Long)` отсутствовала, хотя вызывалась для `timeopen` и `timeclose`. Добавлена реализация с локальным часовым поясом устройства и русской локалью.
2. `formatQuizDuration(Long)` отсутствовала, хотя вызывалась для `timelimit`. Добавлена реализация форматирования секунд в часы/минуты/секунды.
3. `quiz.url?.takeIf { ... }.let(::normalizeMoodlePageUrl)` передавал в функцию nullable `String?`, хотя функция принимала `String`. Исправлено на безопасную цепочку `?.let { rawUrl -> ... }`.
4. `candidates` ранее полагался на generic inference из нескольких nullable-значений. Теперь тип задан как `List<String>` и значения собираются через `listOfNotNull`.
5. Массив `quizzes` из ответа Moodle теперь обрабатывается безопасно, если в JSON нет такого поля.
6. ViewModel проверяет parser version `< 3`; старые кэшированные записи версии 2 больше не обходят повторную загрузку деталей.

## Проверки, фактически выполненные в рабочей среде

- `MoodleDirectRepository.kt`, `MoodleApiModels.kt` и `MoodleTextNormalizer.kt` скомпилированы компилятором Kotlin 1.9.0 в отдельном наборе с сигнатурными заглушками Android `Html`, Gson и OkHttp: **0 ошибок компилятора**.
- `MoodleDirectDownload.kt`, `MoodleConfig.kt` и `MoodleTextNormalizer.kt` скомпилированы Kotlin 1.9.0 с сигнатурными Android-заглушками `DownloadManager`, `Context`, `Uri`, `Environment`, `CookieManager`, `URLUtil` и `Toast`: **0 ошибок компилятора**.
- Все Kotlin-файлы прошли лексическую проверку баланса скобок, строк и комментариев.
- Внутренние импорты `ru.tusur.*` сопоставлены с объявлениями проекта.
- Вызовы проектных helper-функций (format/normalize/extract/resolve/clean/load/merge/derive/download/display и т. п.) сопоставлены с объявлениями проекта.
- 16 регрессионных проверок проекта выполнены скриптом `scripts/verify-source-static.py`.

## Что не проверено

- Полная компиляция Android app module и `assembleDebug` не запускались: Android SDK/Gradle и реальные AndroidX/Compose зависимости в среде отсутствуют.
- Compose-экраны не проходили полноценную type-check компиляцию Android Gradle Plugin; для них выполнены лексическая и внутренняя статическая проверки и ревью изменённых участков.
- Реальный ответ Moodle API и загрузки с действующими cookies не тестировались на сервере.

**Вывод:** конкретные ошибки на скриншоте устранены; два затронутых самостоятельных набора исходников прошли Kotlin type-check с внешними API-заглушками. Это не равнозначно полной Android-сборке и не объявляется таковой.
