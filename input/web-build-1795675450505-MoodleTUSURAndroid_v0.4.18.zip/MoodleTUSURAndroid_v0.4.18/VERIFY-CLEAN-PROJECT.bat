@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo Проверка чистоты проекта TUSUR Study 0.3.8...
set "BAD=0"
for %%F in (
  "app\src\main\java\ru\tusur\moodle\data\MoodleApiFactory.kt"
  "app\src\main\java\ru\tusur\moodle\data\MoodleApiService.kt"
  "app\src\main\java\ru\tusur\moodle\data\MoodleRepository.kt"
  "app\src\main\java\ru\tusur\study\SettingsStore.kt"
) do (
  if exist %%F (
    echo [ОШИБКА] Найден устаревший файл: %%~F
    set "BAD=1"
  )
)
findstr /S /N /I /C:"retrofit2" app\src\main\java\*.kt >nul 2>&1
if not errorlevel 1 (
  echo [ОШИБКА] В исходниках найден импорт Retrofit.
  set "BAD=1"
)
findstr /N /C:"onCreateWindow" app\src\main\java\ru\tusur\study\MoodleWebViewScreen.kt >nul
if errorlevel 1 (
  echo [ОШИБКА] Не найден обработчик popup-окон WebView.
  set "BAD=1"
)
findstr /N /C:"target !== activeWebView" app\src\main\java\ru\tusur\study\MoodleWebViewScreen.kt >nul
if errorlevel 1 (
  echo [ОШИБКА] Не найдено отложенное переключение на popup.
  set "BAD=1"
)
if "%BAD%"=="1" (
  echo.
  echo Папка содержит старые или неполные файлы. Не собирайте её.
  exit /b 1
)
echo [OK] Старых Retrofit-файлов нет.
echo [OK] Popup-окна обрабатываются внутри приложения.
echo [OK] Пустое about:blank не должно перекрывать исходную страницу.
echo [OK] Прямой клиент Moodle использует WebView session.
exit /b 0
