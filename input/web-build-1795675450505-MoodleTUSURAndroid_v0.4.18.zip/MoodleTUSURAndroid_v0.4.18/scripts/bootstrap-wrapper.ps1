$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$GradleVersion = '9.5.0'
$ToolsRoot = Join-Path $ProjectRoot '.tools'
$GradleHome = Join-Path $ToolsRoot "gradle-$GradleVersion"
$ZipPath = Join-Path $ToolsRoot "gradle-$GradleVersion-bin.zip"

if (-not $env:JAVA_HOME) {
    $studioJbr = Join-Path $env:ProgramFiles 'Android/Android Studio/jbr'
    if (Test-Path $studioJbr) {
        $env:JAVA_HOME = $studioJbr
        $env:PATH = "$studioJbr/bin;$env:PATH"
    }
}
if (-not (Get-Command java -ErrorAction SilentlyContinue) -and -not $env:JAVA_HOME) {
    throw 'Java 17 or newer was not found. Install Android Studio or configure JAVA_HOME.'
}

New-Item -ItemType Directory -Force -Path $ToolsRoot | Out-Null
if (-not (Test-Path (Join-Path $GradleHome 'bin/gradle.bat'))) {
    Write-Host "Downloading Gradle $GradleVersion..."
    Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $ZipPath
    Expand-Archive -Path $ZipPath -DestinationPath $ToolsRoot -Force
}

Push-Location $ProjectRoot
try {
    & (Join-Path $GradleHome 'bin/gradle.bat') wrapper --gradle-version $GradleVersion --distribution-type bin
    if ($LASTEXITCODE -ne 0) { throw 'Gradle Wrapper generation failed.' }
}
finally { Pop-Location }
Write-Host 'Gradle Wrapper generated. You can now open the project in Android Studio.'
