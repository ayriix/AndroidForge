$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (-not $env:JAVA_HOME) {
    $studioJbr = Join-Path $env:ProgramFiles 'Android/Android Studio/jbr'
    if (Test-Path $studioJbr) {
        $env:JAVA_HOME = $studioJbr
        $env:PATH = "$studioJbr/bin;$env:PATH"
    }
}
if (-not (Get-Command java -ErrorAction SilentlyContinue) -and -not $env:JAVA_HOME) {
    throw 'Java 17 or newer was not found. Install Android Studio or configure JAVA_HOME.'
}
$GradleVersion = '9.5.0'
$ToolsRoot = Join-Path $ProjectRoot '.tools'
$GradleHome = Join-Path $ToolsRoot "gradle-$GradleVersion"
$ZipPath = Join-Path $ToolsRoot "gradle-$GradleVersion-bin.zip"

New-Item -ItemType Directory -Force -Path $ToolsRoot | Out-Null
if (-not (Test-Path (Join-Path $GradleHome 'bin/gradle.bat'))) {
    Write-Host "Downloading Gradle $GradleVersion..."
    Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $ZipPath
    Expand-Archive -Path $ZipPath -DestinationPath $ToolsRoot -Force
}

$GradleExe = Join-Path $GradleHome 'bin/gradle.bat'
$WrapperBat = Join-Path $ProjectRoot 'gradlew.bat'
if (-not (Test-Path (Join-Path $ProjectRoot 'gradle/wrapper/gradle-wrapper.jar'))) {
    Write-Host 'Generating the Gradle Wrapper files...'
    Push-Location $ProjectRoot
    try {
        & $GradleExe wrapper --gradle-version $GradleVersion --distribution-type bin
        if ($LASTEXITCODE -ne 0) { throw 'Gradle wrapper generation failed.' }
    }
    finally { Pop-Location }
}

if (-not (Test-Path $WrapperBat)) { throw 'gradlew.bat was not generated.' }
Write-Host 'Building debug APK...'
Push-Location $ProjectRoot
try {
    & $WrapperBat assembleDebug
    if ($LASTEXITCODE -ne 0) { throw 'Android build failed. Check Android SDK installation and Gradle output.' }
}
finally { Pop-Location }
Write-Host ''
Write-Host "APK: $ProjectRoot\app\build\outputs\apk\debug\app-debug.apk"
