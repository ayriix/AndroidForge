from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "app/src/main/java"
TESTS = ROOT / "app/src/test/java"
issues: list[str] = []


def fail(message: str) -> None:
    issues.append(message)


def scan_kotlin_lexical(path: Path, source: str) -> None:
    """Balance Kotlin delimiters while ignoring strings/comments; this is not a compiler."""
    pairs = {")": "(", "]": "[", "}": "{"}
    stack: list[tuple[str, int]] = []
    i = 0
    line = 1
    state = "code"
    while i < len(source):
        char = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ""
        if char == "\n":
            line += 1
        if state == "code":
            if char == "/" and nxt == "/":
                state = "line_comment"
                i += 2
                continue
            if char == "/" and nxt == "*":
                state = "block_comment"
                i += 2
                continue
            if char == '"' and source[i:i + 3] == '"""':
                state = "raw_string"
                i += 3
                continue
            if char == '"':
                state = "string"
                i += 1
                continue
            if char == "'":
                state = "char"
                i += 1
                continue
            if char == "`":
                state = "backtick"
                i += 1
                continue
            if char in "([{":
                stack.append((char, line))
            elif char in ")]}":
                if not stack or stack[-1][0] != pairs[char]:
                    fail(f"{path.relative_to(ROOT)}:{line}: unexpected {char}")
                else:
                    stack.pop()
        elif state == "line_comment":
            if char == "\n":
                state = "code"
        elif state == "block_comment":
            if char == "*" and nxt == "/":
                state = "code"
                i += 2
                continue
        elif state == "raw_string":
            if source[i:i + 3] == '"""':
                state = "code"
                i += 3
                continue
        elif state in ("string", "char"):
            if char == "\\":
                i += 2
                continue
            if (state == "string" and char == '"') or (state == "char" and char == "'"):
                state = "code"
        elif state == "backtick" and char == "`":
            state = "code"
        i += 1
    if stack:
        fail(f"{path.relative_to(ROOT)}: unclosed delimiters {stack[-5:]}")
    if state not in ("code", "line_comment"):
        fail(f"{path.relative_to(ROOT)}: unterminated lexical state {state}")


kotlin_files = sorted(p for p in ROOT.rglob("*.kt") if ".gradle" not in p.parts and "build" not in p.parts)
main_files = sorted(SRC.rglob("*.kt"))
all_sources = {p: p.read_text(encoding="utf-8", errors="replace") for p in kotlin_files}
for path, source in all_sources.items():
    scan_kotlin_lexical(path, source)

# Resolve internal imports by declaration name and package.
package_declarations: dict[str, set[str]] = {}
all_declarations: set[str] = set()
for path, source in all_sources.items():
    package_match = re.search(r"(?m)^package\s+([\w.]+)", source)
    package = package_match.group(1) if package_match else ""
    names = set(re.findall(r"\bfun\s+([A-Za-z_]\w*)\s*(?:<[^>{}]*>)?\s*\(", source))
    names.update(re.findall(r"\b(?:class|object|interface|typealias)\s+([A-Za-z_]\w*)", source))
    names.update(re.findall(r"\b(?:enum\s+class|annotation\s+class)\s+([A-Za-z_]\w*)", source))
    package_declarations.setdefault(package, set()).update(names)
    all_declarations.update(names)

for path, source in all_sources.items():
    package_match = re.search(r"(?m)^package\s+([\w.]+)", source)
    current_package = package_match.group(1) if package_match else ""
    for full in re.findall(r"(?m)^import\s+(ru\.tusur\.[\w.]+)(?:\s+as\s+\w+)?\s*$", source):
        imported_package, name = full.rsplit(".", 1)
        if name not in package_declarations.get(imported_package, set()):
            fail(f"{path.relative_to(ROOT)}: unresolved internal import {full}")

# Catch unresolved project-owned helper names. Member calls are excluded by the leading-dot guard.
helper_prefixes = (
    "format", "normalize", "extract", "resolve", "clean", "load", "merge", "derive",
    "unique", "download", "display", "friendly", "section", "isMoodle", "isQuiz", "isTrusted"
)
helper_re = re.compile(r"(?<![.\w:])((?:" + "|".join(helper_prefixes) + r")[A-Z][A-Za-z0-9_]*)\s*\(")
helper_refs: list[str] = []
for path, source in all_sources.items():
    for match in helper_re.finditer(source):
        name = match.group(1)
        helper_refs.append(name)
        if name not in all_declarations and name not in {"loadDataWithBaseURL"}:
            line = source.count("\n", 0, match.start()) + 1
            fail(f"{path.relative_to(ROOT)}:{line}: project helper call has no declaration: {name}")
    for name in re.findall(r"::((?:" + "|".join(helper_prefixes) + r")[A-Z][A-Za-z0-9_]*)", source):
        if name not in all_declarations:
            fail(f"{path.relative_to(ROOT)}: callable reference has no declaration: {name}")

# Focused regression checks for the 0.4.18 quiz access and native in-app quiz flow changes.
def source(rel: str) -> str:
    path = ROOT / rel
    if not path.exists():
        fail(f"missing required source file: {rel}")
        return ""
    return path.read_text(encoding="utf-8", errors="replace")

repo = source("app/src/main/java/ru/tusur/moodle/data/MoodleDirectRepository.kt")
parser = source("app/src/main/java/ru/tusur/moodle/data/MoodleQuizPageSettingsParser.kt")
date_parser = source("app/src/main/java/ru/tusur/moodle/data/MoodleDateTimeParser.kt")
row_parser = source("app/src/main/java/ru/tusur/moodle/data/MoodleQuizAttemptTableParser.kt")
summary_parser = source("app/src/main/java/ru/tusur/moodle/data/MoodleQuizOverviewSummaryParser.kt")
history_signal = source("app/src/main/java/ru/tusur/moodle/data/MoodleQuizOverviewHistorySignal.kt")
source_policy = source("app/src/main/java/ru/tusur/moodle/data/MoodleQuizAttemptSourcePolicy.kt")
api_boolean = source("app/src/main/java/ru/tusur/moodle/data/MoodleApiBoolean.kt")
progress = source("app/src/main/java/ru/tusur/moodle/data/MoodleQuizProgress.kt")
progress_tests = source("app/src/test/java/ru/tusur/moodle/data/MoodleQuizProgressTest.kt")
models = source("app/src/main/java/ru/tusur/moodle/data/MoodleApiModels.kt")
merger = source("app/src/main/java/ru/tusur/moodle/data/MoodleQuizMetadataMerger.kt")
viewmodel = source("app/src/main/java/ru/tusur/study/MoodleViewModel.kt")
offline = source("app/src/main/java/ru/tusur/study/OfflineDataStore.kt")
web = source("app/src/main/java/ru/tusur/study/MoodleWebViewScreen.kt")
main = source("app/src/main/java/ru/tusur/study/MainActivity.kt")
gradle = source("app/build.gradle.kts")
settings = source("settings.gradle.kts")
manifest = source("app/src/main/AndroidManifest.xml")
login = source("app/src/main/java/ru/tusur/study/MoodleNativeLoginRepository.kt")

checks = {
    "no unsupported quiz list method is sent to a generic AJAX endpoint": not bool(re.search(r"\bcall\s*\(\s*[\"']mod_quiz_get_quizzes_by_courses[\"']", repo)),
    "quiz attempt history uses Moodle 4.5+ full-state endpoint first": '"mod_quiz_get_user_quiz_attempts"' in repo,
    "legacy attempt API fallback occurs only for missing-function errors": "isWebServiceFunctionUnavailable(newFunctionError)" in repo and '"mod_quiz_get_user_attempts"' in repo,
    "function-not-available errors are distinguished from permission/session errors": "functionnotavailable" in repo and "unknownfunction" in repo,
    "API best grade is independently requested": '"mod_quiz_get_user_best_grade"' in repo,
    "hasgrade parser supports boolean and integer Moodle representations": "MoodleApiBoolean.parse" in repo and all(x in api_boolean for x in ('"true"', '"false"', '"1"', '"0"')),
    "quiz metadata retry includes missing best-grade evidence": "it.hasApiBestGrade == null" in viewmodel,
    "quiz settings fall back to authenticated HTML when API metadata is missing or incomplete": "if (apiSettingsComplete)" in repo and "API metadata can omit timelimit/attempts" in repo and "authenticated overview page independently" in repo,
    "cached detailsLoaded does not short-circuit quiz page fallback": "if (quiz.detailsLoaded && quiz.detailsParserVersion" not in repo,
    "API zero dates and limits are represented as explicit no-restriction values": "Без ограничения по дате" in repo and "Без ограничения времени" in repo,
    "missing API setting fields stay unknown and trigger HTML fallback": "hasCompleteSettings" in repo and "val apiSettingsComplete = apiMeta?.hasCompleteSettings == true" in repo,
    "current incomplete parser result overrides stale cached loaded flag": "freshIsCurrent -> fresh.detailsLoaded" in merger,
    "partial current refresh keeps cached values but marks details incomplete": "aPartialFreshParsePreservesCachedValuesButInvalidatesTheOldLoadedFlag" in source("app/src/test/java/ru/tusur/moodle/data/MoodleQuizMetadataMergerTest.kt"),
    "WebView session cannot inherit a token from a different or unidentified account": "sameKnownAccount" in viewmodel and "sameUnidentifiedSession" in viewmodel,
    "token request retries transient IO failure without persisting credentials": "repeat(2)" in login and "lastNetworkError" in login and "Thread.sleep(650L)" in login,
    "token errors distinguish disabled web services from network failure": "enablewsdescription" in login and "servicenotavailable" in login and "сетевой ошибки" in login,
    "network recovery prompts re-login only when the WS token is absent": "saved.webServiceToken.isNullOrBlank()" in viewmodel and "повторного получения токена" in viewmodel,
    "attempt table parser accepts rows without attempt number or attempt.php link": "A recognized status is sufficient evidence" in row_parser and '"row:${attemptNumber ?: rowIndex}"' in row_parser,
    "attempt table parser maps status, submitted timestamp and grade columns": all(x in row_parser for x in ("statusColumn", "extractSubmittedTimestamp(statusSource, cellTexts)", "gradeColumn")),
    "date parser recognizes Moodle localized submission timestamps": "fun extractSubmittedTimestamp" in date_parser and "пятница" in date_parser,
    "final grade block parser extracts score and maximum": "finalGradePattern" in summary_parser and "ваша" in summary_parser and "hasFinalGrade" in summary_parser,
    "attempt overview pages are required when the API response is empty": "mustRejectEmptyApiWhenOverviewUnavailable" in repo and "apiAttemptCount == 0 && !overviewReadSuccessfully" in source_policy,
    "unparsed attempt table cannot confirm an empty history": "pageAttempts.isEmpty() && !explicitlyNoAttempts && !summary.hasFinalGrade" in repo,
    "only explicit Moodle no-attempt wording confirms no history": "explicitlyConfirmsNoAttempts" in history_signal and "noAttemptsPattern" in history_signal,
    "fresh attempt refresh invalidates stale no-attempt confirmation": "hasConfirmedNoAttempts = null" in viewmodel,
    "no-attempt confirmation is set only after successful attempt refresh": "hasConfirmedNoAttempts = !hasFreshRows" in viewmodel and "attemptsLoaded = true" in viewmodel,
    "quiz progress only confirms not-started for a truly empty history": "attempts.isEmpty() && attemptsLoaded && quiz.hasConfirmedNoAttempts == true" in progress,
    "quiz progress treats submitted attempts and visible best grades as completed": "hasApiBestGrade == true" in progress and "isMoodleFinishedAttempt" in progress,
    "unknown non-empty attempt row cannot be masked by cached empty-history evidence": "attempts.isEmpty() && attemptsLoaded && quiz.hasConfirmedNoAttempts == true" in progress and "unrecognizedAttemptWithoutStartDoesNotBecomeNotStartedOrACompletionEstimate" in progress_tests,
    "attempt row score is available as a UI fallback when best-grade API is unavailable": "latestFinishedAttempt?.score" in main and "latestFinishedAttempt?.maxScore" in main,
    "quiz cards show no-attempt text only with Moodle confirmation": 'quiz.hasConfirmedNoAttempts == true' in main and '"Попыток пока нет"' in main,
    "technical parser diagnostics are not rendered on quiz screens": all(x not in main for x in ("detailsError", "Не удалось прочитать страницу теста", "Не удалось обновить параметры", "Оценка по расписанию")),
    "missing quiz fields render an em dash": 'val missingValue = if (isLoadingQuizDetails) "…" else "—"' in main and 'QuizInfoLine("Время на выполнение"' in main,
    "metadata merger preserves cached grade fields without treating false as no attempt": "gradeScore = fresh.gradeScore ?: old.gradeScore" in merger and "hasApiBestGrade = fresh.hasApiBestGrade ?: old.hasApiBestGrade" in merger,
    "metadata merger keeps attempt history separate from best-grade visibility": "hasConfirmedNoAttempts = fresh.hasConfirmedNoAttempts ?: old.hasConfirmedNoAttempts" in merger,
    "attempt refresh clears stale cached attempts only for explicitly empty quizzes": "confirmedEmptyCmids" in viewmodel and "fallbackAttempts = latest.attempts.filterNot" in viewmodel,
    "quiz settings use authenticated quiz overview and shared parser": "/mod/quiz/view.php?id=$cmid" in repo and "MoodleQuizPageSettingsParser.parseText" in repo,
    "parser version is 10": "const val VERSION: Int = 10" in parser,
    "calendar content remains left aligned": "horizontalAlignment = Alignment.Start" in main,
    "course statistics wrap when more than three chips": "if (details.size <= 3)" in main and "FlowRow(" in main,
    "download controls retain SpaceBetween footer layout": "horizontalArrangement = Arrangement.SpaceBetween" in source("app/src/main/java/ru/tusur/study/DownloadsScreen.kt"),
    "native login posts credentials without embedding the login page in WebView": all(x in login for x in ("logintoken", "FormBody", "username", "password", "Cookie")) and "MoodleWebViewScreen" not in login,
    "native quiz transport covers access, start, data, summary, review, save and process": all(x in repo for x in (
        "mod_quiz_get_quiz_access_information", "mod_quiz_get_attempt_access_information",
        "mod_quiz_start_attempt", "mod_quiz_get_attempt_data", "mod_quiz_get_attempt_summary",
        "mod_quiz_get_attempt_review", "mod_quiz_save_attempt", "mod_quiz_process_attempt")),
    "quiz runner is connected to native API methods": all(x in viewmodel for x in (
        "openNativeQuiz", "startQuizAttempt", "getQuizAttemptData", "getQuizAttemptReview",
        "advanceNativeQuiz", "saveNativeQuizResponses", "finishNativeQuiz", "getQuizAttemptSummary")),
    "quiz detail screen no longer sends quiz actions to Moodle URLs": "onOpenActivity" not in main and "onContinueAttempt(activeAttemptId)" in main and "onReviewAttempt(reviewAttemptId)" in main,
    "internal quiz HTML renderer blocks page navigation and form submission": "shouldOverrideUrlLoading(view: WebView?, request:" in main and "preventDefault()" in main and "QUIZ_COLLECT_RESPONSES_JS" in main,
    "quiz HTML renderer requests MathJax for TeX and MathML equations": "mathjax/3.2.2/es5/tex-mml-chtml.js" in main and "window.MathJax" in main,
    "quiz access information influences whether start is offered": "if (quiz.accessInfoLoaded) quiz.canAttempt == true else canStartBySchedule" in main and "applyQuizAccessInformation" in repo,
    "quiz access call matches Moodle's quizid-only parameter contract": (lambda block: 'mapOf("quizid" to quizId)' in block and '"userid"' not in block)(repo.split("fun getQuizAccessInformation(quizId: String)", 1)[1].split("/** Effective access to an existing attempt", 1)[0]),
    "new-attempt eligibility uses preventnewattemptreasons and isfinished": '"preventnewattemptreasons"' in repo and 'bool(it, "isfinished")' in repo and 'accessReasons.isEmpty() && newAttemptReasons.isEmpty() && !attemptsExhausted' in repo,
    "start action checks effective access and attempt limits": 'val attemptAccess = repository.getAttemptAccessInformation(quizId)' in viewmodel and '"preventnewattemptreasons"' in viewmodel and 'attemptsExhausted' in viewmodel,
    "resume action does not mistake global isfinished for the selected attempt state": 'if (isFinished == true)' not in viewmodel and 'authoritative check for resuming this' in viewmodel,
    "completed quiz can offer a new attempt when Moodle confirms eligibility": '"Начать новую попытку"' in main and 'if (canStart && !isLoadingQuizDetails)' in main,
    "current Moodle attempt page is retained for resume": "currentPage = row.int(\"currentpage\")" in repo and "matchingAttempt?.currentPage" in viewmodel,
    "settings screen no longer shows redundant connection heading": 'Text("Подключение", style = MaterialTheme.typography.titleMedium' not in main,
    "calendar close/deadline label is understandable": '"due", "close" -> "Открыто до: $time"' in main,
    "application version is 0.4.18 / code 32": 'versionName = "0.4.18"' in gradle and "versionCode = 32" in gradle,
    "root project name remains Moodle.TUSUR": 'rootProject.name = "Moodle.TUSUR"' in settings,
    "application label remains Moodle.TUSUR": 'android:label="Moodle.TUSUR"' in manifest,
}

unit_tests = "\n".join(path.read_text(encoding="utf-8", errors="replace") for path in TESTS.rglob("*Test.kt"))
checks["quiz regression tests cover screenshot row without a link and 10/18 grade"] = "screenshotCaseBuildsCompletedAttemptWithVisibleTenOutOfEighteenGrade" in unit_tests
checks["regression test methods are present"] = len(re.findall(r"@Test", unit_tests)) >= 81

print(f"Kotlin source files scanned: {len(kotlin_files)}")
print(f"Main Kotlin source files: {len(main_files)}")
print(f"Project helper call references checked: {len(helper_refs)}")
print(f"Internal declarations found: {len(all_declarations)}")
for label, passed in checks.items():
    print(("PASS" if passed else "FAIL") + " - " + label)
    if not passed:
        fail("failed regression check: " + label)

if issues:
    print("\nISSUES:")
    for issue in issues:
        print("- " + issue)
    sys.exit(1)

print(f"\nPASS: lexical scan, internal imports, project helper references and {len(checks)} targeted regression checks.")
print("NOTE: This is static source analysis, not a complete Android/Compose compiler or device integration test.")
