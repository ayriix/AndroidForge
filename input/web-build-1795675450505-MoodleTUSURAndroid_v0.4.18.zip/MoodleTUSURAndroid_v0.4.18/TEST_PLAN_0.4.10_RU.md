# План проверки Moodle.TUSUR 0.4.10

## Статические проверки

1. Запустить `python scripts/verify-source-static.py`.
2. Проверить, что `MainActivity` передаёт `this@MainActivity` параметру `appContext`.
3. Проверить, что `TUSURStudyApp` принимает `appContext: Context`.
4. Проверить, что `downloadMoodleResource` вызывается с `appContext` в обработчике файла.
5. Проверить сигнатуру загрузчика и его вызовы в WebView.
6. Проверить ZIP через `unzip -t`.

## Проверка на устройстве

1. Открыть курс, выбрать файл и нажать «Открыть».
2. Убедиться, что файл передаётся в системный DownloadManager.
3. Проверить обычные активности, тесты и ссылки — они по-прежнему открываются в Moodle WebView.

## Ограничения

Полная Android/Compose type-check компиляция и Gradle-сборка не выполнялись. Статическая проверка не заменяет компиляцию проекта с настоящим AndroidX/Compose classpath.
