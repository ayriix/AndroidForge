# Проверка Moodle.TUSUR 0.4.16

## Исправления, связанные со сборкой 0.4.15

1. `MainActivity.kt`: проверить компиляцию двух использований `isMoodleFinishedAttempt`. Добавлен unit compile-guard `MoodleFinishedAttemptImportCompileTest` из пакета `ru.tusur.study`.
2. `MoodleNativeLoginRepository.kt`: URL сайта теперь создаётся через OkHttp 4 Kotlin extension `toHttpUrlOrNull()`; некорректная строка даёт контролируемую ошибку входа.
3. `MoodleViewModel.kt`: `CookieManager` импортирован, чтобы `logout()` продолжал очищать WebView cookies.

## Локальные проверки, выполненные при подготовке архива

- Kotlin compiler: успешно скомпилированы `MoodleDateTimeParser.kt`, `MoodleApiModels.kt`, `MoodleQuizProgress.kt` и внешний probe в пакете `ru.tusur.study`, который импортирует и вызывает `isMoodleFinishedAttempt`.
- Статическая проверка: 11/11 условий.
- Проверено отсутствие `HttpUrl.get(` в исходниках приложения.
- Проверено наличие `CookieManager` import и вызова очистки при выходе.

## Что необходимо выполнить в Android Studio

1. Открыть архив/проект 0.4.16 и выполнить Sync Project with Gradle Files.
2. Запустить `Build > Make Project`.
3. Если сборка прошла, запустить `app` на эмуляторе/телефоне.
4. Проверить нативный вход, обновление курсов и выход из учётной записи.

## Ограничение

Полная Gradle/Android-сборка здесь не запускалась: Gradle 9.6.0 отсутствует в кеше, DNS-загрузка с `services.gradle.org` завершается `UnknownHostException`, Android SDK отсутствует. Не считать локальные source-level проверки доказательством успешной APK-сборки.
