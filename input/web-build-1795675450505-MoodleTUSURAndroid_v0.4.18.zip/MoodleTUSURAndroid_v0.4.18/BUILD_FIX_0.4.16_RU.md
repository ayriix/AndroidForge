# Исправление сборки Moodle.TUSUR 0.4.16

## Причины ошибок в 0.4.15

1. `MainActivity.kt`: использовалась `isMoodleFinishedAttempt`, объявленная в пакете `ru.tusur.moodle.data`, но импорт отсутствовал. Исправлены оба места вызова одним импортом.
2. `MoodleNativeLoginRepository.kt`: `HttpUrl.get(String)` — Java-стиль API OkHttp, непригодный для Kotlin API OkHttp 4.12. Заменён на `String.toHttpUrlOrNull()` с явной обработкой некорректного адреса.
3. Ошибка `MoodleViewModel.kt` была каскадной: репозиторий авторизации не компилировался, из-за чего ссылка на его класс в ViewModel не разрешалась.

## Изменения

- `versionName`: 0.4.16
- `versionCode`: 30
- User-Agent обновлён на 0.4.16.

## Проверка

- Проверено, что все вызовы `isMoodleFinishedAttempt` доступны: внутри `ru.tusur.moodle.data` — напрямую, из `ru.tusur.study` — через импорт.
- Проверено, что `MoodleNativeLoginRepository` использует `toHttpUrlOrNull`, уже применяемую в другом файле проекта с OkHttp 4.12.
- Проверено отсутствие оставшихся вызовов `HttpUrl.get(String)`.
- Проверен ZIP после упаковки.

Полная Gradle/Android-сборка в этой среде не выполнена: Gradle 9.6.0 отсутствует в локальном кеше, загрузка с services.gradle.org блокируется DNS (`UnknownHostException`), Android SDK также не установлен. Поэтому исправление исходных причин подтверждено статически, но успешную APK-сборку утверждать нельзя.

## Дополнительная ошибка из полного списка Android Studio

4. `MoodleViewModel.kt`: импорт `android.webkit.CookieManager` был удалён вместе с прежним чтением активных WebView-cookie, но `logout()` всё ещё вызывает `CookieManager.getInstance()` для очистки cookie jar. Импорт восстановлен: очистка WebView-cookie при выходе остаётся намеренной, чтобы старый WebView-сеанс не пережил выход пользователя.

Таким образом, на скриншоте были четыре compiler errors в трёх файлах: два call site с одним отсутствующим импортом, один вызов устаревшего для Kotlin API OkHttp метода и один отсутствующий Android import.
