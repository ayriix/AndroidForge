package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MoodleQuizSettingsHtmlRowsParserTest {
    private fun visibleText(fragment: String): String = fragment
        .replace(Regex("(?is)<br\\s*/?>"), " ")
        .replace(Regex("(?is)<[^>]+>"), " ")
        .replace("&nbsp;", " ", ignoreCase = true)
        .replace("&amp;", "&", ignoreCase = true)
        .replace(Regex("\\s+"), " ")
        .trim()

    @Test
    fun extractsThTdAndTdTdRowsAndFeedsThemToSettingsParser() {
        val html = """
            <table class="quizinfo">
              <tr><th>Открыто с:</th><td>11 сентября 2026, 10:00</td></tr>
              <tr><td>Закрыто с:</td><td>11 сентября 2026 в 10:20</td></tr>
              <tr><th>Ограничение по времени:</th><td>20 мин.</td></tr>
              <tr><td>Разрешено попыток:</td><td>2</td></tr>
            </table>
        """.trimIndent()

        val rows = MoodleQuizSettingsHtmlRowsParser.extract(html, ::visibleText)
        val parsed = MoodleQuizPageSettingsParser.parseText(rows.joinToString("\n"), hasQuizInfoBlock = true)

        assertEquals(4, rows.size)
        assertEquals("11 сентября 2026, 10:00", parsed.openTime)
        assertEquals("11 сентября 2026 в 10:20", parsed.closeTime)
        assertEquals("20 мин.", parsed.timeLimit)
        assertEquals("2", parsed.allowedAttempts)
        assertTrue(parsed.isComplete)
    }

    @Test
    fun extractsDefinitionListRowsAndIgnoresUnrelatedEntries() {
        val html = """
            <dl class="quizinfo">
              <dt>Закрыто с:</dt><dd>21 нояб. 2026 г. в 14:30</dd>
              <dt>Имя преподавателя:</dt><dd>Иван Иванов</dd>
              <dt>Ограничение по времени:</dt><dd>45 мин.</dd>
              <dt>Разрешено попыток:</dt><dd>3</dd>
            </dl>
        """.trimIndent()

        val rows = MoodleQuizSettingsHtmlRowsParser.extract(html, ::visibleText)
        val parsed = MoodleQuizPageSettingsParser.parseText(rows.joinToString("\n"), hasQuizInfoBlock = true)

        assertEquals(3, rows.size)
        assertEquals("21 нояб. 2026 г. в 14:30", parsed.closeTime)
        assertEquals("45 мин.", parsed.timeLimit)
        assertEquals("3", parsed.allowedAttempts)
    }

    @Test
    fun skipsRowsWithEmptyValuesAndDoesNotInventQuizSettings() {
        val html = """
            <table>
              <tr><th>Закрыто с:</th><td> </td></tr>
              <tr><th>Имя преподавателя:</th><td>Петров</td></tr>
            </table>
        """.trimIndent()

        val rows = MoodleQuizSettingsHtmlRowsParser.extract(html, ::visibleText)
        val parsed = MoodleQuizPageSettingsParser.parseText(rows.joinToString("\n"), hasQuizInfoBlock = true)

        assertTrue(rows.isEmpty())
        assertEquals(null, parsed.closeTime)
        assertEquals(4, parsed.missingFields.size)
    }
}
