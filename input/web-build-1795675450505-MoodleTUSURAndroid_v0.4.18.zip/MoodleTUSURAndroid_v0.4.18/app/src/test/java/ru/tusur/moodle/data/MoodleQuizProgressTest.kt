package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MoodleQuizProgressTest {
    private fun quiz(
        open: String? = "четверг, 10 сентября 2026, 10:39",
        close: String? = "четверг, 10 сентября 2026, 12:00",
        limit: String? = "16 мин.",
        confirmedNoAttempts: Boolean? = true
    ) = MoodleQuiz(
        courseId = "42", quizName = "Тест", openTimeText = open, closeTimeText = close,
        timeLimit = limit, hasConfirmedNoAttempts = confirmedNoAttempts
    )

    private fun attempt(
        number: Int,
        status: String?,
        started: String? = null,
        completed: String? = null,
        elapsed: String? = null
    ) = MoodleQuizAttempt(
        courseId = "42",
        attemptId = "row:$number",
        cmid = "101",
        quizName = "Тест",
        attemptRow = number.toString(),
        status = status,
        started = started,
        completed = completed,
        elapsed = elapsed
    )

    @Test
    fun noAttemptShowsTeacherDeadlineAndNeverInfersStudentCompletionFromQuizOpening() {
        val progress = resolveMoodleQuizProgress(quiz(), emptyList())

        assertEquals(MoodleQuizProgressState.NOT_STARTED, progress.state)
        assertEquals("четверг, 10 сентября 2026, 12:00", progress.deadlineAt)
        assertNull(progress.completedAt)
    }

    @Test
    fun noAttemptWithoutTeacherDeadlineStaysNotStarted() {
        val progress = resolveMoodleQuizProgress(quiz(close = null), emptyList())

        assertEquals(MoodleQuizProgressState.NOT_STARTED, progress.state)
        assertNull(progress.deadlineAt)
        assertNull(progress.completedAt)
    }

    @Test
    fun unfinishedAttemptShowsInProgressInsteadOfTeacherDeadline() {
        val progress = resolveMoodleQuizProgress(
            quiz(),
            listOf(attempt(1, "В процессе", started = "четверг, 10 сентября 2026, 10:39"))
        )

        assertEquals(MoodleQuizProgressState.IN_PROGRESS, progress.state)
        assertNull(progress.deadlineAt)
        assertNull(progress.completedAt)
    }

    @Test
    fun newerInProgressAttemptTakesPriorityOverAnOlderFinishedAttempt() {
        val progress = resolveMoodleQuizProgress(
            quiz(),
            listOf(
                attempt(1, "Завершена", completed = "10.09.2026 10:55"),
                attempt(2, "В процессе", started = "11.09.2026 10:39")
            )
        )

        assertEquals(MoodleQuizProgressState.IN_PROGRESS, progress.state)
        assertNull(progress.completedAt)
    }

    @Test
    fun finishedAttemptUsesTimestampReceivedFromMoodle() {
        val progress = resolveMoodleQuizProgress(
            quiz(),
            listOf(attempt(1, "Завершена", completed = "пятница, 20 ноября 2026, 13:00"))
        )

        assertEquals(MoodleQuizProgressState.COMPLETED, progress.state)
        assertEquals("пятница, 20 ноября 2026, 13:00", progress.completedAt)
        assertNull(progress.deadlineAt)
    }

    @Test
    fun finishedAttemptWithoutTimestampUsesItsStartAndActualElapsedDuration() {
        val progress = resolveMoodleQuizProgress(
            quiz(),
            listOf(
                attempt(
                    1,
                    "Завершена",
                    started = "пятница, 14 ноября 2025, 10:38",
                    elapsed = "9 мин."
                )
            )
        )

        assertEquals(MoodleQuizProgressState.COMPLETED, progress.state)
        assertEquals("14.11.2025 10:47", progress.completedAt)
    }

    @Test
    fun finishedAttemptWithoutElapsedUsesItsStartAndQuizTimeLimit() {
        val progress = resolveMoodleQuizProgress(
            quiz(limit = "12 мин."),
            listOf(attempt(1, "Завершена", started = "пятница, 14 ноября 2025, 10:38"))
        )

        assertEquals(MoodleQuizProgressState.COMPLETED, progress.state)
        assertEquals("14.11.2025 10:50", progress.completedAt)
    }

    @Test
    fun explicitInProgressFlagIsHonoredEvenWhenAttemptRowIsNotAvailable() {
        val progress = resolveMoodleQuizProgress(
            quiz().copy(hasInProgressAttempt = 1),
            emptyList()
        )

        assertEquals(MoodleQuizProgressState.IN_PROGRESS, progress.state)
        assertNull(progress.completedAt)
        assertNull(progress.deadlineAt)
    }

    @Test
    fun attemptWithStartButNoStatusOrSubmissionIsTreatedAsInProgress() {
        val progress = resolveMoodleQuizProgress(
            quiz(),
            listOf(attempt(1, null, started = "четверг, 10 сентября 2026, 10:39"))
        )

        assertEquals(MoodleQuizProgressState.IN_PROGRESS, progress.state)
        assertNull(progress.completedAt)
    }

    @Test
    fun submissionTimestampWinsOverConflictingInProgressLabel() {
        val progress = resolveMoodleQuizProgress(
            quiz(),
            listOf(attempt(1, "В процессе", completed = "пятница, 20 ноября 2026, 13:00"))
        )

        assertEquals(MoodleQuizProgressState.COMPLETED, progress.state)
        assertEquals("пятница, 20 ноября 2026, 13:00", progress.completedAt)
    }

    @Test
    fun unrecognizedAttemptWithoutStartDoesNotBecomeNotStartedOrACompletionEstimate() {
        val progress = resolveMoodleQuizProgress(
            quiz(),
            listOf(attempt(1, "unknown Moodle state"))
        )

        assertEquals(MoodleQuizProgressState.UNKNOWN, progress.state)
        assertNull(progress.completedAt)
    }

    @Test
    fun emptyHistoryIsUnknownUntilMoodleConfirmsTheRequestSucceeded() {
        val progress = resolveMoodleQuizProgress(
            quiz(confirmedNoAttempts = null), emptyList(), attemptsLoaded = false
        )
        assertEquals(MoodleQuizProgressState.UNKNOWN, progress.state)
        assertNull(progress.completedAt)
        assertNull(progress.deadlineAt)
    }


    @Test
    fun loadedButUnconfirmedEmptyHistoryDoesNotBecomeNotStarted() {
        val progress = resolveMoodleQuizProgress(
            quiz(confirmedNoAttempts = null), emptyList(), attemptsLoaded = true
        )
        assertEquals(MoodleQuizProgressState.UNKNOWN, progress.state)
        assertNull(progress.deadlineAt)
        assertNull(progress.completedAt)
    }

    @Test
    fun visibleMoodleBestGradeConfirmsCompletedQuizEvenWhenAttemptRowsAreHidden() {
        val progress = resolveMoodleQuizProgress(
            quiz().copy(hasApiBestGrade = true, gradeScore = "10", gradeMax = "18"),
            emptyList(),
            attemptsLoaded = false
        )
        assertEquals(MoodleQuizProgressState.COMPLETED, progress.state)
        assertNull(progress.completedAt)
    }

    @Test
    fun hiddenOrUnavailableBestGradeDoesNotInventACompletedAttempt() {
        val progress = resolveMoodleQuizProgress(
            quiz().copy(hasApiBestGrade = false),
            emptyList(),
            attemptsLoaded = false
        )
        assertEquals(MoodleQuizProgressState.UNKNOWN, progress.state)
        assertNull(progress.completedAt)
    }

    @Test
    fun moodleFiveSubmittedApiStateIsTreatedAsCompleted() {
        assertEquals("Завершена", normalizeMoodleApiAttemptStatus("submitted"))
        assertEquals("Завершена", normalizeMoodleApiAttemptStatus("finished"))
    }

    @Test
    fun moodleFiveNotStartedApiStateDoesNotBecomeAnInProgressAttempt() {
        assertEquals("Не начата", normalizeMoodleApiAttemptStatus("not_started"))
        val progress = resolveMoodleQuizProgress(
            quiz(),
            listOf(attempt(1, normalizeMoodleApiAttemptStatus("not_started")))
        )
        assertEquals(MoodleQuizProgressState.NOT_STARTED, progress.state)
    }

}
