package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MoodleQuizPageSettingsParserTest {
    @Test
    fun parsesBothDatesAndLimitsFromRussianMoodleQuizInfo() {
        val pageText = """
            Комплексные числа. Модуль. Главное значение аргумента
            Выполнено
            Открыто с: четверг, 10 сентября 2026, 10:39
            Закрыто с: четверг, 10 сентября 2026, 10:55
            Разрешено попыток: 1
            Ограничение по времени: 16 мин.
            Результаты ваших предыдущих попыток
        """.trimIndent()

        val result = MoodleQuizPageSettingsParser.parseText(pageText, hasQuizInfoBlock = true)

        assertEquals("четверг, 10 сентября 2026, 10:39", result.openTime)
        assertEquals("четверг, 10 сентября 2026, 10:55", result.closeTime)
        assertEquals("16 мин.", result.timeLimit)
        assertEquals("1", result.allowedAttempts)
        assertTrue(result.isComplete)
        assertTrue(result.missingFields.isEmpty())
    }

    @Test
    fun omittedRowsMeanNoRestrictionOnlyWhenAtLeastOneSettingsRowWasRead() {
        val confirmedWithOneRow = MoodleQuizPageSettingsParser.parseText(
            "Ограничение по времени: 16 мин.",
            hasQuizInfoBlock = true
        )
        val pageWithoutReadableSettings = MoodleQuizPageSettingsParser.parseText(
            "Тест. Результаты ваших предыдущих попыток",
            hasQuizInfoBlock = true
        )
        val unconfirmed = MoodleQuizPageSettingsParser.parseText(
            "Ограничение по времени: 16 мин.",
            hasQuizInfoBlock = false
        )

        assertEquals("Без ограничения по дате", confirmedWithOneRow.openTime)
        assertEquals("Без ограничения по дате", confirmedWithOneRow.closeTime)
        assertEquals("16 мин.", confirmedWithOneRow.timeLimit)
        assertEquals("Неограниченно", confirmedWithOneRow.allowedAttempts)
        assertTrue(confirmedWithOneRow.isComplete)

        assertFalse(pageWithoutReadableSettings.isComplete)
        assertEquals(4, pageWithoutReadableSettings.missingFields.size)
        assertFalse(unconfirmed.isComplete)
    }

    @Test
    fun parsesEnglishMonthFirstDates() {
        val result = MoodleQuizPageSettingsParser.parseText(
            "Opens: Friday, September 11, 2026, 10:00 Closes: Friday, September 11, 2026, 10:20 Time limit: 20 minutes Attempts allowed: 1",
            hasQuizInfoBlock = false
        )
        assertEquals("Friday, September 11, 2026, 10:00", result.openTime)
        assertEquals("Friday, September 11, 2026, 10:20", result.closeTime)
        assertEquals("20 minutes", result.timeLimit)
        assertEquals("1", result.allowedAttempts)
        assertTrue(result.isComplete)
    }

    @Test
    fun partialSettingsStayIncompleteSoTheyCanBeRetried() {
        val pageText = """
            Открыто с: четверг, 10 сентября 2026, 10:39
            Закрыто с:
            Ограничение по времени: 16 мин.
            Разрешено попыток: 1
        """.trimIndent()

        val result = MoodleQuizPageSettingsParser.parseText(pageText, hasQuizInfoBlock = true)

        assertEquals("четверг, 10 сентября 2026, 10:39", result.openTime)
        assertEquals(null, result.closeTime)
        assertEquals(listOf("дата закрытия"), result.missingFields)
        assertFalse(result.isComplete)
    }

    @Test
    fun parsesRussianAbbreviatedMonthAndTimeSeparatedByWordV() {
        val result = MoodleQuizPageSettingsParser.parseText(
            "Открыто с: пт., 11 сент. 2026 г. в 10:00\n" +
                "Закрыто с: пт., 11 сент. 2026 г. в 10:20\n" +
                "Ограничение по времени: 20 мин.\n" +
                "Разрешено попыток: 1",
            hasQuizInfoBlock = true
        )

        assertEquals("пт., 11 сент. 2026 г. в 10:00", result.openTime)
        assertEquals("пт., 11 сент. 2026 г. в 10:20", result.closeTime)
        assertEquals("20 мин.", result.timeLimit)
        assertEquals("1", result.allowedAttempts)
        assertTrue(result.isComplete)
    }

    @Test
    fun doesNotTreatAnUnrecognizedClosingValueAsNoRestriction() {
        val result = MoodleQuizPageSettingsParser.parseText(
            "Открыто с: 21 нояб. 2026, 10:00\n" +
                "Закрыто с: дата будет объявлена преподавателем\n" +
                "Ограничение по времени: 20 мин.\n" +
                "Разрешено попыток: 1",
            hasQuizInfoBlock = true
        )

        assertEquals("21 нояб. 2026, 10:00", result.openTime)
        assertEquals(null, result.closeTime)
        assertFalse(result.isComplete)
        assertTrue(result.missingFields.contains("дата закрытия"))
    }

    @Test
    fun parsesSettingsWhenHtmlRowsWereConvertedIntoSeparateLabelValueLines() {
        val result = MoodleQuizPageSettingsParser.parseText(
            "Открыто с:\n21 ноября 2026, 10:00\n" +
                "Закрыто с:\n21 ноября 2026, 10:30\n" +
                "Ограничение по времени:\n30 мин.\n" +
                "Разрешено попыток:\n2",
            hasQuizInfoBlock = true
        )

        assertEquals("21 ноября 2026, 10:00", result.openTime)
        assertEquals("21 ноября 2026, 10:30", result.closeTime)
        assertEquals("30 мин.", result.timeLimit)
        assertEquals("2", result.allowedAttempts)
        assertTrue(result.isComplete)
    }
    @Test
    fun parsesRussianMobileQuizViewTextWithSubmissionAndSeparateRestrictionRows() {
        val text = """
            Демовариант работы по теме Кривые второго порядка
            Выполнено
            Закрыто с: пятница, 20 ноября 2026, 13:00
            Метод оценивания: Высшая оценка
            Ограничение по времени: 15 мин.
            Разрешено попыток: 1
        """.trimIndent()
        val parsed = MoodleQuizPageSettingsParser.parseText(text, hasQuizInfoBlock = true)
        assertEquals("пятница, 20 ноября 2026, 13:00", parsed.closeTime)
        assertEquals("15 мин.", parsed.timeLimit)
        assertEquals("1", parsed.allowedAttempts)
    }

}
