package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MoodleQuizAttemptTableParserTest {
    private fun visibleText(fragment: String): String = fragment
        .replace(Regex("(?is)<br\\s*/?>"), " ")
        .replace(Regex("(?is)<[^>]+>"), " ")
        .replace("&nbsp;", " ", ignoreCase = true)
        .replace("&amp;", "&", ignoreCase = true)
        .replace(Regex("\\s+"), " ")
        .trim()

    @Test
    fun readsFinishedAttemptTimestampWhenReviewIsForbiddenAndThereIsNoAttemptLink() {
        val html = """
            <table class="generaltable quizattemptsummary">
              <thead><tr><th>Попытка</th><th>Состояние</th><th>Просмотр</th></tr></thead>
              <tbody><tr>
                <td>1</td>
                <td>Завершены Отправлено пятница, 20 ноября 2026, 13:00</td>
                <td>Не разрешается</td>
              </tr></tbody>
            </table>
        """.trimIndent()

        val attempts = MoodleQuizAttemptTableParser.extract(html, ::visibleText)

        assertEquals(1, attempts.size)
        assertEquals("row:1", attempts.single().attemptId)
        assertEquals("1", attempts.single().attemptRow)
        assertEquals("Завершена", attempts.single().status)
        assertEquals("пятница, 20 ноября 2026, 13:00", attempts.single().completed)
        assertNull(attempts.single().reviewHref)
    }

    @Test
    fun rowHeaderThIsNotMistakenForTheTableHeader() {
        val html = """
            <table class="generaltable quizattemptsummary">
              <tr><th>Попытка</th><th>Состояние</th><th>Просмотр</th></tr>
              <tr>
                <th scope="row" class="cell c0">1</th>
                <td>Завершены Отправлено пятница, 20 ноября 2026, 13:00</td>
                <td>Не разрешается</td>
              </tr>
              <tr>
                <th scope="row" class="cell c0">2</th>
                <td>Завершены Отправлено пятница, 21 ноября 2026, 13:00</td>
                <td>Не разрешается</td>
              </tr>
            </table>
        """.trimIndent()

        val attempts = MoodleQuizAttemptTableParser.extract(html, ::visibleText)

        assertEquals(2, attempts.size)
        assertEquals(listOf("row:1", "row:2"), attempts.map { it.attemptId })
        assertEquals(listOf("1", "2"), attempts.map { it.attemptRow })
        assertEquals(
            listOf("пятница, 20 ноября 2026, 13:00", "пятница, 21 ноября 2026, 13:00"),
            attempts.map { it.completed }
        )
    }

    @Test
    fun ignoresNumberedTablesThatDoNotContainAttemptStatusOrReviewLink() {
        val html = """
            <table>
              <tr><th>Номер</th><th>Материал</th></tr>
              <tr><td>1</td><td>Лекция 1</td></tr>
            </table>
        """.trimIndent()

        assertTrue(MoodleQuizAttemptTableParser.extract(html, ::visibleText).isEmpty())
    }

    @Test
    fun readsAnInProgressAttemptWithoutInventingACompletionTimestamp() {
        val html = """
            <table class="generaltable quizattemptsummary">
              <thead><tr><th>Попытка</th><th>Состояние</th><th>Просмотр</th></tr></thead>
              <tbody><tr>
                <td>2</td>
                <td>В процессе</td>
                <td><a href="attempt.php?attempt=987">Продолжить попытку</a></td>
              </tr></tbody>
            </table>
        """.trimIndent()

        val attempt = MoodleQuizAttemptTableParser.extract(html, ::visibleText).single()

        assertEquals("В процессе", attempt.status)
        assertNull(attempt.completed)
        assertTrue(attempt.reviewHref.orEmpty().contains("attempt=987"))
    }

    @Test
    fun incompleteRussianStatusIsNormalizedToInProgress() {
        val html = """
            <table>
              <tr><th>Попытка</th><th>Состояние</th></tr>
              <tr><td>1</td><td>Не завершена</td></tr>
            </table>
        """.trimIndent()

        val attempt = MoodleQuizAttemptTableParser.extract(html, ::visibleText).single()

        assertEquals("В процессе", attempt.status)
    }

    @Test
    fun notSubmittedAttemptIsNotMistakenForFinished() {
        val html = """
            <table>
              <tr><th>Попытка</th><th>Состояние</th></tr>
              <tr><td>1</td><td>Не отправлена</td></tr>
            </table>
        """.trimIndent()

        val attempt = MoodleQuizAttemptTableParser.extract(html, ::visibleText).single()

        assertEquals("В процессе", attempt.status)
        assertNull(attempt.completed)
    }

    @Test
    fun englishNotSubmittedStateIsNormalizedToInProgress() {
        val html = """
            <table>
              <tr><th>Attempt</th><th>Status</th></tr>
              <tr><td>1</td><td>Not submitted</td></tr>
            </table>
        """.trimIndent()

        val attempt = MoodleQuizAttemptTableParser.extract(html, ::visibleText).single()

        assertEquals("В процессе", attempt.status)
        assertNull(attempt.completed)
    }


    @Test
    fun readsMoodleTableWithoutAttemptColumnOrReviewLinkAndGetsMaximumFromHeader() {
        val html = """
            <table class="generaltable quizattemptsummary">
              <tr><th>Состояние</th><th>Оценка / 18,00</th><th>Просмотр</th></tr>
              <tr>
                <td>Завершены Отправлено четверг, 10 сентября 2026, 10:55</td>
                <td>10,00</td>
                <td>Не разрешается</td>
              </tr>
            </table>
        """.trimIndent()

        val attempts = MoodleQuizAttemptTableParser.extract(html, ::visibleText)

        assertEquals(1, attempts.size)
        assertEquals("row:1", attempts.single().attemptId)
        assertNull(attempts.single().attemptRow)
        assertEquals("Завершена", attempts.single().status)
        assertEquals("четверг, 10 сентября 2026, 10:55", attempts.single().completed)
        assertEquals("10.00", attempts.single().score)
        assertEquals("18.00", attempts.single().maxScore)
        assertNull(attempts.single().reviewHref)
    }

    @Test
    fun readsFinishedAttemptWithoutAttemptNumberAndWithSeparateGradeCell() {
        val html = """
            <table class="generaltable quizattemptsummary">
              <tr><th>Состояние</th><th>Оценка / 18,00</th><th>Просмотр</th></tr>
              <tr><td>Завершены Отправлено четверг, 10 сентября 2026, 10:55</td>
                  <td>10,00</td><td>Не разрешается</td></tr>
            </table>
        """.trimIndent()
        val row = MoodleQuizAttemptTableParser.extract(html, ::visibleText).single()
        assertEquals("Завершена", row.status)
        assertEquals("10.00", row.score)
        assertEquals("18.00", row.maxScore)
        assertEquals("четверг, 10 сентября 2026, 10:55", row.completed)
        assertNull(row.reviewHref)
    }

    @Test
    fun keepsInternalAttemptIdAndReviewLinkWhenMoodleProvidesThem() {
        val html = """
            <table>
              <tr><th>Attempt</th><th>Status</th><th>Review</th></tr>
              <tr>
                <td><a href="review.php?attempt=987">Attempt 2</a></td>
                <td>Finished - Submitted Monday, November 23, 2026, 11:30</td>
                <td><a href="review.php?attempt=987">Review</a></td>
              </tr>
            </table>
        """.trimIndent()

        val attempt = MoodleQuizAttemptTableParser.extract(html, ::visibleText).single()

        assertEquals("987", attempt.attemptId)
        assertEquals("Attempt 2", attempt.attemptRow)
        assertEquals("Завершена", attempt.status)
        assertEquals("Monday, November 23, 2026, 11:30", attempt.completed)
        assertTrue(attempt.reviewHref.orEmpty().contains("attempt=987"))
    }
    @Test
    fun screenshotCaseBuildsCompletedAttemptWithVisibleTenOutOfEighteenGrade() {
        val html = """
            <table class="generaltable quizattemptsummary">
              <thead><tr>
                <th>Состояние</th><th>Оценка / 18,00</th><th>Просмотр</th>
              </tr></thead>
              <tbody><tr>
                <td>Завершены<br>Отправлено четверг, 10 сентября 2026, 10:55</td>
                <td>10,00</td>
                <td>Не разрешается</td>
              </tr></tbody>
            </table>
        """.trimIndent()
        val row = MoodleQuizAttemptTableParser.extract(html, ::visibleText).single()
        val attempt = MoodleQuizAttempt(
            courseId = "42",
            attemptId = row.attemptId,
            cmid = "101",
            quizName = "Комплексные числа. Модуль. Главное значение аргумента",
            attemptRow = row.attemptRow,
            status = row.status,
            started = row.started,
            completed = row.completed,
            elapsed = row.elapsed,
            score = row.score,
            maxScore = row.maxScore
        )
        val progress = resolveMoodleQuizProgress(
            MoodleQuiz(
                courseId = "42",
                cmid = "101",
                quizName = "Комплексные числа. Модуль. Главное значение аргумента",
                hasConfirmedNoAttempts = false
            ),
            listOf(attempt),
            attemptsLoaded = true
        )

        assertEquals("Завершена", attempt.status)
        assertEquals("10.00", attempt.score)
        assertEquals("18.00", attempt.maxScore)
        assertEquals("четверг, 10 сентября 2026, 10:55", progress.completedAt)
        assertEquals(MoodleQuizProgressState.COMPLETED, progress.state)
    }

}
