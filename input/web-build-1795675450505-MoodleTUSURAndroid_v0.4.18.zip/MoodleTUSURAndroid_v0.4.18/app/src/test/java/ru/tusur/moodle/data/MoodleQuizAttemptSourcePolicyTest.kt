package ru.tusur.moodle.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MoodleQuizAttemptSourcePolicyTest {
    @Test
    fun emptyApiAndFailedOverviewMustNotBeReportedAsNoAttempts() {
        assertTrue(MoodleQuizAttemptSourcePolicy.mustRejectEmptyApiWhenOverviewUnavailable(0, false))
    }

    @Test
    fun successfulOverviewCanConfirmAnExplicitlyEmptyHistory() {
        assertFalse(MoodleQuizAttemptSourcePolicy.mustRejectEmptyApiWhenOverviewUnavailable(0, true))
    }

    @Test
    fun nonEmptyApiHistoryCanBeUsedWhenOverviewIsTemporarilyUnavailable() {
        assertFalse(MoodleQuizAttemptSourcePolicy.mustRejectEmptyApiWhenOverviewUnavailable(1, false))
    }
}
