package ru.tusur.moodle.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MoodleQuizOverviewHistorySignalTest {
    @Test
    fun recognizesRussianMoodleNoAttemptPhrases() {
        assertTrue(MoodleQuizOverviewHistorySignal.explicitlyConfirmsNoAttempts("Вы ещё не предпринимали попыток."))
        assertTrue(MoodleQuizOverviewHistorySignal.explicitlyConfirmsNoAttempts("У вас пока нет попыток в этом тесте."))
        assertTrue(MoodleQuizOverviewHistorySignal.explicitlyConfirmsNoAttempts("Вы еще не делали ни одной попытки."))
    }

    @Test
    fun recognizesEnglishMoodleNoAttemptPhrases() {
        assertTrue(MoodleQuizOverviewHistorySignal.explicitlyConfirmsNoAttempts("You have not attempted this quiz yet."))
        assertTrue(MoodleQuizOverviewHistorySignal.explicitlyConfirmsNoAttempts("No attempts have been made yet."))
    }

    @Test
    fun aGenericHistoryTableOrStatusWordDoesNotConfirmNoAttempts() {
        assertFalse(MoodleQuizOverviewHistorySignal.explicitlyConfirmsNoAttempts("Status: Submitted. Grade: 10 / 18."))
        assertFalse(MoodleQuizOverviewHistorySignal.explicitlyConfirmsNoAttempts("The status of the activity is available."))
    }
}
