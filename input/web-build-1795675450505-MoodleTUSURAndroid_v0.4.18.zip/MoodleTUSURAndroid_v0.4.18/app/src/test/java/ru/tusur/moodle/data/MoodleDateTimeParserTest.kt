package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MoodleDateTimeParserTest {
    @Test
    fun parsesRussianAbbreviatedMonthWithAbbreviatedWeekday() {
        assertEquals(
            "ср., 21 нояб. 2026 г., 14:30",
            MoodleDateTimeParser.extract("ср., 21 нояб. 2026 г., 14:30")
        )
    }

    @Test
    fun parsesDateWhenMoodleUsesTheWordVBeforeTime() {
        assertEquals(
            "21 сент. 2026 в 10:20",
            MoodleDateTimeParser.extract("21 сент. 2026 в 10:20")
        )
    }

    @Test
    fun parsesNumericAndIsoDateTimes() {
        assertEquals("21.11.2026 14:30", MoodleDateTimeParser.extract("21.11.2026 14:30"))
        assertEquals(
            "2026-11-21T14:30:00+07:00",
            MoodleDateTimeParser.extract("2026-11-21T14:30:00+07:00")
        )
    }

    @Test
    fun returnsNullInsteadOfInventingDateForUnrecognizedText() {
        assertNull(MoodleDateTimeParser.extract("не указано"))
        assertNull(MoodleDateTimeParser.extract(null))
    }
    @Test
    fun parsesAttemptSubmissionWithFullRussianMonthAndWeekday() {
        assertEquals(
            java.time.LocalDateTime.of(2026, 11, 20, 13, 0),
            MoodleDateTimeParser.parseLocalDateTime("пятница, 20 ноября 2026, 13:00")
        )
    }

    @Test
    fun parsesIsoTimestampWithOffsetToDeviceLocalTime() {
        // ISO timestamps are accepted; the raw extracted value remains unchanged.
        assertEquals(
            "2026-11-21T14:30:00+07:00",
            MoodleDateTimeParser.extract("2026-11-21T14:30:00+07:00")
        )
    }

    @Test
    fun extractsSubmittedTimeFromMoodleStatusCell() {
        assertEquals(
            "пятница, 20 ноября 2026, 13:00",
            MoodleDateTimeParser.extractSubmittedTimestamp(
                "Завершены Отправлено пятница, 20 ноября 2026, 13:00",
                listOf("1", "Завершены Отправлено пятница, 20 ноября 2026, 13:00", "Не разрешается")
            )
        )
    }

    @Test
    fun doesNotTreatAnUnfinishedAttemptAsSubmitted() {
        assertNull(MoodleDateTimeParser.extractSubmittedTimestamp(
            "В процессе", listOf("В процессе", "пятница, 20 ноября 2026, 13:00")
        ))
    }

}
