package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Test

class MoodleApiBooleanTest {
    @Test
    fun acceptsJsonBooleanTextAndNumericEncodings() {
        assertEquals(true, MoodleApiBoolean.parse("true"))
        assertEquals(true, MoodleApiBoolean.parse("1"))
        assertEquals(true, MoodleApiBoolean.parse("yes"))
        assertEquals(false, MoodleApiBoolean.parse("false"))
        assertEquals(false, MoodleApiBoolean.parse("0"))
        assertEquals(false, MoodleApiBoolean.parse("no"))
    }

    @Test
    fun unknownOrMissingValuesRemainUnknown() {
        assertEquals(null, MoodleApiBoolean.parse(null))
        assertEquals(null, MoodleApiBoolean.parse(""))
        assertEquals(null, MoodleApiBoolean.parse("maybe"))
    }
}
