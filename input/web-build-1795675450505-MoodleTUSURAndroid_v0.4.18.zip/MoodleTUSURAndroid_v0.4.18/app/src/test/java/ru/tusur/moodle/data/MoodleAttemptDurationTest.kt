package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MoodleAttemptDurationTest {
    @Test
    fun reviewColumnIsNeverShownAsElapsedTime() {
        assertNull(cleanMoodleElapsed("Просмотр"))
        assertNull(cleanMoodleElapsed("Review"))
    }

    @Test
    fun elapsedTimeIsDerivedFromRussianStartAndSubmissionDates() {
        assertEquals(
            "24 мин",
            deriveMoodleElapsed(
                "вторник, 10 ноября 2026, 14:30",
                "вторник, 10 ноября 2026, 14:54"
            )
        )
    }

    @Test
    fun explicitRussianDurationIsKept() {
        assertEquals("15 мин", cleanMoodleElapsed("15 мин."))
    }
    @Test
    fun derivesSubmissionTimeFromRecordedStartAndElapsedDuration() {
        assertEquals(
            "14.11.2025 10:50",
            deriveMoodleCompletedTime("пятница, 14 ноября 2025, 10:38", "12 мин.")
        )
    }

    @Test
    fun parsesSubmissionTimeShownInsideMoodleAttemptStatusCell() {
        assertEquals(
            "пятница, 20 ноября 2026, 13:00",
            MoodleDateTimeParser.extract("Завершены Отправлено пятница, 20 ноября 2026, 13:00")
        )
    }

    @Test
    fun derivesSubmissionTimeFromAttemptStartAndConfiguredQuizLimitWhenElapsedIsMissing() {
        assertEquals(
            "14.11.2025 10:50",
            deriveMoodleAttemptCompletedTime(
                started = "пятница, 14 ноября 2025, 10:38",
                actualElapsed = null,
                recordedCompleted = null,
                configuredTimeLimit = "12 мин."
            )
        )
    }

    @Test
    fun actualElapsedTimeTakesPrecedenceOverConfiguredQuizLimit() {
        assertEquals(
            "14.11.2025 10:47",
            deriveMoodleAttemptCompletedTime(
                started = "пятница, 14 ноября 2025, 10:38",
                actualElapsed = "9 мин.",
                recordedCompleted = null,
                configuredTimeLimit = "12 мин."
            )
        )
    }

}
