package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Test

class MoodleAttemptMergeTest {
    @Test
    fun mergesApiAttemptAndOverviewRowWhenMoodleHidesAttemptLinkAndNumber() {
        val apiAttempt = MoodleQuizAttempt(
            courseId = "42",
            attemptId = "987",
            cmid = "101",
            attemptRow = "1",
            status = "Завершена",
            started = "четверг, 10 сентября 2026, 10:39"
        )
        val overviewRow = MoodleQuizAttempt(
            courseId = "42",
            attemptId = "row:1",
            cmid = "101",
            status = "Завершена",
            completed = "четверг, 10 сентября 2026, 10:55",
            score = "10.00",
            maxScore = "18.00"
        )

        val merged = mergeMoodleQuizAttempts(listOf(apiAttempt), listOf(overviewRow))

        assertEquals(1, merged.size)
        assertEquals("987", merged.single().attemptId)
        assertEquals("1", merged.single().attemptRow)
        assertEquals("четверг, 10 сентября 2026, 10:55", merged.single().completed)
        assertEquals("10.00", merged.single().score)
        assertEquals("18.00", merged.single().maxScore)
    }

    @Test
    fun keepsTwoDifferentCompletedAttemptsWhenReviewLinksAreNotAvailable() {
        val rows = listOf(
            MoodleQuizAttempt(
                courseId = "42", attemptId = "row:1", cmid = "101",
                status = "Завершена", completed = "четверг, 10 сентября 2026, 10:55"
            ),
            MoodleQuizAttempt(
                courseId = "42", attemptId = "row:2", cmid = "101",
                status = "Завершена", completed = "пятница, 11 сентября 2026, 10:55"
            )
        )

        val merged = mergeMoodleQuizAttempts(rows, emptyList())

        assertEquals(2, merged.size)
    }
    @Test
    fun keepsApiCurrentPageWhenMergingOverviewAttemptRows() {
        val apiAttempt = MoodleQuizAttempt(
            courseId = "42", attemptId = "987", cmid = "101", attemptRow = "1", currentPage = 2
        )
        val overviewRow = MoodleQuizAttempt(
            courseId = "42", attemptId = "row:1", cmid = "101", attemptRow = "1"
        )
        val merged = mergeMoodleQuizAttempts(listOf(apiAttempt), listOf(overviewRow))
        assertEquals(2, merged.single().currentPage)
    }

}
