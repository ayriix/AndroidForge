package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MoodleQuizOverviewSummaryParserTest {
    @Test
    fun readsRussianFinalGradeAndSubmissionTimeFromOverviewSummary() {
        val result = MoodleQuizOverviewSummaryParser.parse(
            """
                Результаты ваших предыдущих попыток
                Попытка 1 Завершены Отправлено четверг, 10 сентября 2026, 10:55
                Ваша итоговая оценка за этот тест: 10,00/18,00
            """.trimIndent()
        )

        assertEquals("10.00", result.score)
        assertEquals("18.00", result.maxScore)
        assertEquals("четверг, 10 сентября 2026, 10:55", result.submittedAt)
        assertTrue(result.hasFinalGrade)
    }

    @Test
    fun readsEnglishFinalGrade() {
        val result = MoodleQuizOverviewSummaryParser.parse(
            "Your final grade for this quiz: 10.5 / 18.0"
        )
        assertEquals("10.5", result.score)
        assertEquals("18.0", result.maxScore)
    }

    @Test
    fun readsGradeWhenMoodleSplitsTheLabelAndScoreAcrossHtmlLineBreaks() {
        val result = MoodleQuizOverviewSummaryParser.parse(
            "Ваша итоговая оценка за этот тест:\n  10,00\n / \n 18,00"
        )
        assertEquals("10.00", result.score)
        assertEquals("18.00", result.maxScore)
        assertTrue(result.hasFinalGrade)
    }

    @Test
    fun doesNotInventGradeWhenNoFinalGradeBlockExists() {
        val result = MoodleQuizOverviewSummaryParser.parse(
            "The quiz opens on Thursday, 10 September 2026, 10:39"
        )
        assertFalse(result.hasFinalGrade)
        assertEquals(null, result.score)
        assertEquals(null, result.maxScore)
        assertEquals(null, result.submittedAt)
    }
}
