package ru.tusur.study

import org.junit.Assert.assertTrue
import org.junit.Test
import ru.tusur.moodle.data.MoodleQuizAttempt
import ru.tusur.moodle.data.isMoodleFinishedAttempt

/** Guards the cross-package import used by the Compose quiz list and detail screen. */
class MoodleFinishedAttemptImportCompileTest {
    @Test
    fun finishedAttemptPredicateIsVisibleFromStudyPackage() {
        val attempt = MoodleQuizAttempt(
            courseId = "course-1",
            attemptId = "row:1",
            status = "Завершены. Отправлено 10 сентября 2026, 10:55",
            score = "10,00",
            maxScore = "18,00"
        )

        assertTrue(isMoodleFinishedAttempt(attempt))
    }
}
