package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MoodleTextNormalizerTest {
    @Test
    fun normalizesStudyProgramDateAndGroupCode() {
        assertEquals(
            "РПД 09.03.01 разработка ПО.pdf",
            normalizeMoodleDisplayName("РПД_09_03_01_разработка ПО.pdf")
        )
        assertEquals(
            "Итог по тестам 574-1.pdf",
            normalizeMoodleDisplayName("Итог_по_тестам_574_1.pdf")
        )
        assertEquals(
            "План 31.12.2026.pdf",
            normalizeMoodleDisplayName("План_31_12_2026.pdf")
        )
    }

    @Test
    fun ignoresViewLabelInsteadOfTreatingItAsDuration() {
        assertNull(cleanMoodleElapsed("Просмотр"))
        assertEquals("15 мин", cleanMoodleElapsed("15 мин."))
    }

    @Test
    fun derivesDurationFromMoodleRussianTimestamps() {
        assertEquals(
            "24 мин",
            deriveMoodleElapsed(
                "вторник, 10 ноября 2026, 14:30",
                "вторник, 10 ноября 2026, 14:54"
            )
        )
    }

    @Test
    fun detectsQuizOutsideOpeningWindow() {
        assertEquals(true, isMoodleDateWindowClosed(
            "четверг, 19 ноября 2026, 10:30",
            "четверг, 19 ноября 2026, 11:20",
            java.time.LocalDateTime.of(2026, 11, 21, 9, 0)
        ))
        assertEquals(false, isMoodleDateWindowClosed(
            "четверг, 19 ноября 2026, 10:30",
            "четверг, 19 ноября 2026, 11:20",
            java.time.LocalDateTime.of(2026, 11, 19, 10, 40)
        ))
    }

}
