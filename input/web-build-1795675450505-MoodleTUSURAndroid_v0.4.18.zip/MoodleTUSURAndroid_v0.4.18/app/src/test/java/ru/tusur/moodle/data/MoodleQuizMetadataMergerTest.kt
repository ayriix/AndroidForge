package ru.tusur.moodle.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MoodleQuizMetadataMergerTest {
    private fun quiz(
        cmid: String? = "123",
        name: String = "Комплексные числа",
        url: String? = "https://moodle.math.tusur.ru/mod/quiz/view.php?id=123",
        open: String? = null,
        close: String? = null,
        limit: String? = null,
        attempts: String? = null,
        loaded: Boolean = false,
        parserVersion: Int = 0
    ) = MoodleQuiz(
        courseId = "7",
        cmid = cmid,
        quizName = name,
        url = url,
        openTimeText = open,
        closeTimeText = close,
        timeLimit = limit,
        allowedAttempts = attempts,
        detailsLoaded = loaded,
        detailsParserVersion = parserVersion
    )

    @Test
    fun cachedSettingsSurviveFreshCourseSnapshotWhenCmidIsMissing() {
        val old = quiz(
            open = "четверг, 10 сентября 2026, 10:39",
            close = "четверг, 10 сентября 2026, 10:55",
            limit = "16 мин.",
            attempts = "1",
            loaded = true,
            parserVersion = MoodleQuizPageSettingsParser.VERSION
        )
        val fresh = quiz(cmid = null, url = null)

        val merged = MoodleQuizMetadataMerger.merge(listOf(old), listOf(fresh)).single()

        assertEquals(old.openTimeText, merged.openTimeText)
        assertEquals(old.closeTimeText, merged.closeTimeText)
        assertEquals(old.timeLimit, merged.timeLimit)
        assertEquals(old.allowedAttempts, merged.allowedAttempts)
        assertTrue(merged.detailsLoaded)
    }

    @Test
    fun aPartialFreshParsePreservesCachedValuesButInvalidatesTheOldLoadedFlag() {
        val old = quiz(
            open = "четверг, 10 сентября 2026, 10:39",
            close = "четверг, 10 сентября 2026, 10:55",
            limit = "16 мин.",
            attempts = "1",
            loaded = true,
            parserVersion = MoodleQuizPageSettingsParser.VERSION
        )
        val fresh = quiz(open = "пятница, 11 сентября 2026, 10:00", parserVersion = MoodleQuizPageSettingsParser.VERSION)

        val merged = MoodleQuizMetadataMerger.merge(listOf(old), listOf(fresh)).single()

        assertEquals("пятница, 11 сентября 2026, 10:00", merged.openTimeText)
        assertEquals(old.closeTimeText, merged.closeTimeText)
        assertEquals(old.timeLimit, merged.timeLimit)
        assertEquals(old.allowedAttempts, merged.allowedAttempts)
        assertFalse(merged.detailsLoaded)
        assertEquals(MoodleQuizPageSettingsParser.VERSION, merged.detailsParserVersion)
    }

    @Test
    fun currentParserIncompleteRefreshOverridesCachedDetailsLoadedFlag() {
        val old = quiz(
            open = "10 сентября 2026, 10:39",
            close = "10 сентября 2026, 10:55",
            limit = "16 мин.",
            attempts = "1",
            loaded = true,
            parserVersion = MoodleQuizPageSettingsParser.VERSION
        )
        val fresh = quiz(
            open = "11 сентября 2026, 10:00",
            loaded = false,
            parserVersion = MoodleQuizPageSettingsParser.VERSION
        )

        val merged = MoodleQuizMetadataMerger.merge(listOf(old), listOf(fresh)).single()

        assertEquals("11 сентября 2026, 10:00", merged.openTimeText)
        assertEquals(old.closeTimeText, merged.closeTimeText)
        assertEquals(old.timeLimit, merged.timeLimit)
        assertEquals(old.allowedAttempts, merged.allowedAttempts)
        assertFalse(merged.detailsLoaded)
    }

    @Test
    fun oldParserCompletionDoesNotPreventCurrentParserRetry() {
        val old = quiz(loaded = true, parserVersion = 3, close = "старое значение")
        val fresh = quiz(parserVersion = MoodleQuizPageSettingsParser.VERSION, loaded = false)

        val merged = MoodleQuizMetadataMerger.merge(listOf(old), listOf(fresh)).single()

        assertFalse(merged.detailsLoaded)
        assertEquals(MoodleQuizPageSettingsParser.VERSION, merged.detailsParserVersion)
        assertEquals("старое значение", merged.closeTimeText)
    }
    @Test
    fun explicitFreshNoGradeEvidenceDoesNotEraseCachedGradeButMarksItNotCurrent() {
        val old = quiz().copy(
            gradeScore = "10",
            gradeMax = "18",
            gradePercent = "55.56",
            hasApiBestGrade = true
        )
        val fresh = quiz().copy(hasApiBestGrade = false)

        val merged = MoodleQuizMetadataMerger.merge(listOf(old), listOf(fresh)).single()

        assertEquals(false, merged.hasApiBestGrade)
        assertEquals("10", merged.gradeScore)
        assertEquals("18", merged.gradeMax)
        assertEquals("55.56", merged.gradePercent)
    }

    @Test
    fun unavailableFreshGradeEvidenceDoesNotErasePreviouslyConfirmedGrade() {
        val old = quiz().copy(
            gradeScore = "10",
            gradeMax = "18",
            hasApiBestGrade = true
        )
        val fresh = quiz()

        val merged = MoodleQuizMetadataMerger.merge(listOf(old), listOf(fresh)).single()

        assertEquals(true, merged.hasApiBestGrade)
        assertEquals("10", merged.gradeScore)
        assertEquals("18", merged.gradeMax)
    }

    @Test
    fun cachedSettingsCanMatchByUrlIdOrUniqueNameWhenCmidChanges() {
        val old = quiz(
            cmid = "123",
            open = "10 сентября 2026, 10:39",
            close = "10 сентября 2026, 10:55",
            limit = "16 мин.",
            attempts = "1",
            loaded = true,
            parserVersion = MoodleQuizPageSettingsParser.VERSION
        )
        val fresh = quiz(cmid = "999", url = "https://moodle.math.tusur.ru/mod/quiz/view.php?id=999")

        val merged = MoodleQuizMetadataMerger.merge(listOf(old), listOf(fresh)).single()

        assertEquals(old.closeTimeText, merged.closeTimeText)
        assertEquals(old.allowedAttempts, merged.allowedAttempts)
        assertTrue(merged.detailsLoaded)
    }


    @Test
    fun parserUpgradeKeepsStoredDataButAllowsTheNewParserToRetryIncompleteCards() {
        val stored = quiz(
            open = "21 нояб. 2026, 10:00",
            close = null,
            limit = "20 мин.",
            attempts = "1",
            loaded = false,
            parserVersion = 5
        )
        val fresh = quiz(parserVersion = MoodleQuizPageSettingsParser.VERSION)

        val merged = MoodleQuizMetadataMerger.merge(listOf(stored), listOf(fresh)).single()

        assertEquals(stored.openTimeText, merged.openTimeText)
        assertEquals(stored.timeLimit, merged.timeLimit)
        assertFalse(merged.detailsLoaded)
        assertEquals(MoodleQuizPageSettingsParser.VERSION, merged.detailsParserVersion)
    }
}
