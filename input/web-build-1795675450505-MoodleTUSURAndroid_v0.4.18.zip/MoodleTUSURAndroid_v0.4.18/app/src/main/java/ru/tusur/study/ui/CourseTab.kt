package ru.tusur.study.ui

enum class CourseTab(val label: String) {
    MATERIALS("Материалы"),
    PRACTICE("Практика"),
    QUIZZES("Тесты"),
    GRADES("Оценки"),
    ATTEMPTS("Попытки"),
    CALENDAR("Календарь"),
    ONLINE("Moodle")
}
