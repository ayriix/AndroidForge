package ru.tusur.study

import android.app.Application
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.webkit.CookieManager
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.tusur.moodle.data.MoodleAttemptDetail
import ru.tusur.moodle.data.MoodleCourse
import ru.tusur.moodle.data.MoodleCourseSnapshot
import ru.tusur.moodle.data.mergeMoodleQuizAttempts
import ru.tusur.moodle.data.MoodleDirectRepository
import ru.tusur.moodle.data.MoodleQuizPageSettingsParser
import ru.tusur.moodle.data.MoodleSearchResponse
import ru.tusur.moodle.data.MoodleSessionExpiredException
import ru.tusur.moodle.data.MoodleModule
import ru.tusur.moodle.data.MoodleQuiz
import ru.tusur.moodle.data.MoodleQuizAttempt
import ru.tusur.moodle.data.normalizeMoodleDisplayName


data class MoodleQuizRunnerQuestion(
    val slot: Int,
    val number: String?,
    val html: String,
    val status: String? = null,
    val mark: String? = null,
    val maxMark: String? = null
)

data class MoodleQuizRunnerExtraData(
    val id: String,
    val title: String,
    val content: String
)

data class MoodleQuizRunnerUiState(
    val quizName: String,
    val courseId: String,
    val quizId: String,
    val attemptId: String? = null,
    val currentPage: Int = 0,
    val nextPage: Int = -1,
    val isReview: Boolean = false,
    val isSummary: Boolean = false,
    val isCompleted: Boolean = false,
    val questions: List<MoodleQuizRunnerQuestion> = emptyList(),
    val additionalData: List<MoodleQuizRunnerExtraData> = emptyList(),
    val gradeText: String? = null,
    val message: String? = null,
    val error: String? = null,
    val isLoading: Boolean = false,
    val isSubmitting: Boolean = false
)

data class MoodleAppState(
    val moodleBaseUrl: String = DEFAULT_MOODLE_BASE_URL,
    val isConnecting: Boolean = false,
    val isAuthenticating: Boolean = false,
    val isLoadingCourse: Boolean = false,
    val isSearching: Boolean = false,
    val isLoadingAttempts: Boolean = false,
    val isLoadingQuizDetails: Boolean = false,
    val message: String? = null,
    val notice: String? = null,
    val courses: List<MoodleCourse> = emptyList(),
    val courseSnapshot: MoodleCourseSnapshot? = null,
    val attemptDetail: MoodleAttemptDetail? = null,
    val quizRunner: MoodleQuizRunnerUiState? = null,
    val searchResults: MoodleSearchResponse? = null,
    val isConnected: Boolean = false,
    val hasSavedSession: Boolean = false,
    val isShowingCachedData: Boolean = false,
    val cacheSavedAt: Long? = null,
    val syncProgress: String? = null
)

/** Direct phone-to-Moodle client. No laptop, local API, IP address or shared API key is used. */
class MoodleViewModel(application: Application) : AndroidViewModel(application) {
    private val sessionStore = MoodleSessionStore(application)
    private val offlineStore = OfflineDataStore(application)
    private val _state = MutableStateFlow(MoodleAppState())
    val state: StateFlow<MoodleAppState> = _state.asStateFlow()
    @Volatile private var noticeSequence = 0
    private var searchJob: Job? = null
    private val quizDetailsInFlight = mutableSetOf<String>()
    private val attemptsInFlight = mutableSetOf<String>()
    private val attemptsLoadedCourses = mutableSetOf<String>()
    private val connectivityManager = application.getSystemService(ConnectivityManager::class.java)
    @Volatile private var networkWasUnavailable = run {
        val active = connectivityManager.activeNetwork
        val capabilities = active?.let(connectivityManager::getNetworkCapabilities)
        capabilities == null || !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
            !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onLost(network: Network) {
            networkWasUnavailable = true
            _state.update { current ->
                current.copy(
                    isConnected = false,
                    isShowingCachedData = current.courseSnapshot != null || current.courses.isNotEmpty()
                )
            }
        }

        override fun onAvailable(network: Network) {
            if (!networkWasUnavailable) return
            networkWasUnavailable = false
            showTransientNotice("Подключение восстановлено")
            viewModelScope.launch {
                val saved = withContext(Dispatchers.IO) { sessionStore.load() }
                if (saved != null && !_state.value.isConnecting && !_state.value.isLoadingCourse) {
                    if (saved.webServiceToken.isNullOrBlank()) {
                        showTransientNotice(
                            "Интернет восстановлен. Для повторного получения токена функций тестов войдите в Moodle заново."
                        )
                    }
                    refreshCourseList()
                }
            }
        }
    }

    init {
        runCatching { connectivityManager.registerDefaultNetworkCallback(networkCallback) }
        viewModelScope.launch {
            val cachedCourses = withContext(Dispatchers.IO) { offlineStore.loadCourses() }
            val session = withContext(Dispatchers.IO) { sessionStore.load() }
            _state.update {
                it.copy(
                    courses = cachedCourses?.data ?: emptyList(),
                    hasSavedSession = session != null,
                    isShowingCachedData = cachedCourses != null,
                    cacheSavedAt = cachedCourses?.savedAtEpochMs
                )
            }
            // On app launch make a lightweight request for the course list only. Course details
            // are loaded lazily when opened; full-course sync runs only after an explicit user action.
            if (session != null) refreshCourseList()
        }
    }

    fun onMoodleSessionCaptured(baseUrl: String, sesskey: String, cookieHeader: String, userId: String?) {
        onMoodleSessionCaptured(baseUrl, sesskey, cookieHeader, userId, afterSaved = null)
    }

    /** Invoke [afterSaved] only after the authenticated session is durably stored. */
    fun onMoodleSessionCaptured(
        baseUrl: String,
        sesskey: String,
        cookieHeader: String,
        userId: String?,
        afterSaved: (() -> Unit)?
    ) {
        val normalized = baseUrl.trim().let { if (it.endsWith('/')) it else "$it/" }
        val host = runCatching { Uri.parse(normalized).host.orEmpty().lowercase() }.getOrDefault("")
        if (!normalized.startsWith("https://", true) || host != MOODLE_HOST) {
            _state.update { it.copy(message = "Сессия получена не с основного сайта Moodle ТУСУР и не сохранена.") }
            return
        }
        if (sesskey.isBlank() || cookieHeader.isBlank()) {
            _state.update { it.copy(message = "Moodle пока не подтвердил авторизацию. Завершите вход на сайте.") }
            return
        }
        viewModelScope.launch {
            try {
                val shouldRefreshCourses = withContext(Dispatchers.IO) {
                    val previous = sessionStore.load()
                    val accountChanged = !userId.isNullOrBlank() &&
                        !previous?.userId.isNullOrBlank() && previous?.userId != userId
                    if (accountChanged) {
                        offlineStore.clearAll()
                        getApplication<Application>()
                            .getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS)
                            ?.listFiles()?.forEach { it.deleteRecursively() }
                    }
                    val sameAuthenticatedSession = previous != null &&
                        previous.sesskey == sesskey &&
                        (previous.userId.isNullOrBlank() || userId.isNullOrBlank() || previous.userId == userId)
                    val sameKnownAccount = previous != null &&
                        !userId.isNullOrBlank() && !previous.userId.isNullOrBlank() &&
                        userId == previous.userId
                    val sameUnidentifiedSession = previous != null &&
                        userId.isNullOrBlank() && previous.userId.isNullOrBlank() &&
                        previous.sesskey == sesskey
                    sessionStore.save(MoodleBrowserSession(
                        normalized, cookieHeader, sesskey, userId,
                        webServiceToken = previous?.webServiceToken.takeIf {
                            sameKnownAccount || sameUnidentifiedSession
                        }
                    ))
                    previous == null || accountChanged || !sameAuthenticatedSession
                }
                if (shouldRefreshCourses) attemptsLoadedCourses.clear()
                _state.update { current ->
                    current.copy(moodleBaseUrl = normalized, hasSavedSession = true, message = null)
                }
                // This callback is used by the login screen. It is deliberately after save + state update.
                afterSaved?.invoke()
                if (shouldRefreshCourses) refreshCourseList()
            } catch (error: Exception) {
                _state.update { it.copy(message = "Не удалось безопасно сохранить сессию: ${error.localizedMessage}") }
            }
        }
    }

    /** Native Moodle login. Credentials are not stored; only the encrypted session and optional WS token are kept. */
    fun loginWithCredentials(username: String, password: String, afterLogin: (() -> Unit)? = null) {
        if (_state.value.isAuthenticating) return
        _state.update { it.copy(isAuthenticating = true, message = null, notice = null) }
        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val auth = MoodleNativeLoginRepository().authenticate(username, password)
                    val previous = sessionStore.load()
                    val accountChanged = !auth.session.userId.isNullOrBlank() &&
                        !previous?.userId.isNullOrBlank() && previous?.userId != auth.session.userId
                    if (accountChanged) {
                        offlineStore.clearAll()
                        getApplication<Application>()
                            .getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS)
                            ?.listFiles()?.forEach { it.deleteRecursively() }
                    }
                    sessionStore.save(auth.session)
                    auth to accountChanged
                }
                attemptsLoadedCourses.clear()
                _state.update {
                    it.copy(
                        isAuthenticating = false,
                        isConnected = true,
                        hasSavedSession = true,
                        moodleBaseUrl = result.first.session.baseUrl,
                        message = null,
                        notice = result.first.mobileServiceWarning
                    )
                }
                afterLogin?.invoke()
                refreshCourseList()
            } catch (cancelled: CancellationException) {
                _state.update { it.copy(isAuthenticating = false) }
                throw cancelled
            } catch (error: Exception) {
                _state.update {
                    it.copy(
                        isAuthenticating = false,
                        isConnected = false,
                        hasSavedSession = sessionStore.load() != null,
                        message = error.localizedMessage ?: "Не удалось войти в Moodle."
                    )
                }
            }
        }
    }

    /** Fast refresh: retrieve only enrolled courses; do not download every card on mobile data. */
    fun refreshCourseList() {
        viewModelScope.launch {
            val session = withContext(Dispatchers.IO) { sessionStore.load() }
            if (session == null) {
                showOfflineCourseList("Войдите в Moodle, чтобы обновить список курсов.")
                return@launch
            }
            _state.update { it.copy(isConnecting = true, message = null, syncProgress = "Обновление списка курсов…") }
            try {
                val courses = withContext(Dispatchers.IO) { MoodleDirectRepository(session).getCourses() }
                val persistedCourses = withContext(Dispatchers.IO) { offlineStore.saveCourses(courses) }
                _state.update {
                    it.copy(
                        isConnecting = false,
                        isConnected = true,
                        hasSavedSession = true,
                        courses = persistedCourses,
                        isShowingCachedData = false,
                        cacheSavedAt = System.currentTimeMillis(),
                        syncProgress = null,
                        message = null
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                handleConnectionFailure(error, "Не удалось обновить список курсов.")
            }
        }
    }

    /** Full foreground sync, invoked only when the user explicitly asks for it. */
    fun syncAllCourses() {
        viewModelScope.launch {
            val session = withContext(Dispatchers.IO) { sessionStore.load() }
            if (session == null) {
                showOfflineCourseList("Для синхронизации войдите в Moodle.")
                return@launch
            }
            _state.update { it.copy(isConnecting = true, message = null, syncProgress = "Подготовка синхронизации…") }
            try {
                val (courses, snapshots) = withContext(Dispatchers.IO) {
                    MoodleDirectRepository(session).syncAll(
                        onProgress = { progress -> _state.update { it.copy(syncProgress = progress) } },
                        cachedSnapshot = { course -> offlineStore.loadSnapshot(course.courseId)?.data }
                    )
                }
                val persistedSnapshots = withContext(Dispatchers.IO) {
                    val merged = snapshots.map(offlineStore::saveSnapshot)
                    offlineStore.saveCourses(merged.map { it.course }.ifEmpty { courses })
                    merged
                }
                val openId = _state.value.courseSnapshot?.course?.courseId
                val updatedOpen = persistedSnapshots.firstOrNull { it.course.courseId == openId }
                _state.update {
                    it.copy(
                        isConnecting = false,
                        isConnected = true,
                        hasSavedSession = true,
                        courses = persistedSnapshots.map { it.course }.ifEmpty { courses },
                        courseSnapshot = updatedOpen ?: it.courseSnapshot,
                        isShowingCachedData = false,
                        cacheSavedAt = System.currentTimeMillis(),
                        syncProgress = null,
                        message = null,
                        notice = null
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                handleConnectionFailure(error, "Не удалось синхронизировать данные Moodle.")
            }
        }
    }

    fun openCourse(courseId: String, forceRefreshCards: Boolean = false) {
        // Reopening a course must re-read attempt history. Quiz state and grades can change
        // while the course screen is closed or while another attempt is submitted.
        attemptsLoadedCourses.remove(courseId)
        viewModelScope.launch {
            val cached = withContext(Dispatchers.IO) { offlineStore.loadSnapshot(courseId) }
            _state.update {
                it.copy(
                    isLoadingCourse = false,
                    courseSnapshot = cached?.data,
                    attemptDetail = null,
                    isShowingCachedData = cached != null,
                    cacheSavedAt = cached?.savedAtEpochMs ?: it.cacheSavedAt,
                    message = null
                )
            }

            val session = withContext(Dispatchers.IO) { sessionStore.load() }
            if (session == null) {
                _state.update {
                    it.copy(
                        isLoadingCourse = false,
                        message = if (cached != null) null else "Этот курс ещё не сохранён. Подключитесь к Интернету и войдите в Moodle."
                    )
                }
                return@launch
            }

            _state.update { it.copy(isLoadingCourse = true) }
            try {
                val course = _state.value.courses.firstOrNull { it.courseId == courseId }
                    ?: cached?.data?.course
                    ?: MoodleCourse(courseId = courseId, name = "Курс $courseId", url = "${session.baseUrl}course/view.php?id=$courseId")
                val snapshot = withContext(Dispatchers.IO) {
                    MoodleDirectRepository(session).loadCourseSnapshot(
                        course = course,
                        cachedSnapshot = cached?.data,
                        forceRefreshCards = forceRefreshCards
                    )
                }
                val persistedSnapshot = withContext(Dispatchers.IO) { offlineStore.saveSnapshot(snapshot) }
                _state.update {
                    it.copy(
                        isLoadingCourse = false,
                        courseSnapshot = persistedSnapshot,
                        courses = it.courses.map { course -> if (course.courseId == persistedSnapshot.course.courseId) persistedSnapshot.course else course },
                        isConnected = true,
                        isShowingCachedData = false,
                        cacheSavedAt = System.currentTimeMillis(),
                        message = null
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (error is MoodleSessionExpiredException) clearExpiredSession()
                _state.update {
                    it.copy(
                        isLoadingCourse = false,
                        isConnected = false,
                        hasSavedSession = error !is MoodleSessionExpiredException,
                        isShowingCachedData = cached != null,
                        cacheSavedAt = cached?.savedAtEpochMs ?: it.cacheSavedAt,
                        message = if (cached != null) {
                            "Moodle не ответил. Оставил последнюю сохранённую версию курса. Онлайн-тесты требуют соединения."
                        } else {
                            "Не удалось загрузить курс: ${error.localizedMessage ?: error.javaClass.simpleName}"
                        }
                    )
                }
            }
        }
    }

    fun loadQuizDetails(courseId: String, forceRefresh: Boolean = false) {
        val snapshot = _state.value.courseSnapshot ?: return
        if (snapshot.course.courseId != courseId || _state.value.isLoadingQuizDetails) return
        if (snapshot.quizzes.isEmpty()) return
        val needsDetails = snapshot.quizzes.any {
            !it.detailsLoaded || it.detailsParserVersion < MoodleQuizPageSettingsParser.VERSION ||
                it.hasApiBestGrade == null || !it.accessInfoLoaded
        }
        if ((!needsDetails && !forceRefresh) || !quizDetailsInFlight.add(courseId)) return
        viewModelScope.launch {
            try {
                val current = _state.value.courseSnapshot ?: return@launch
                val session = loadCurrentMoodleSession() ?: return@launch
                _state.update { it.copy(isLoadingQuizDetails = true, message = null, syncProgress = null) }
                val quizzes = withContext(Dispatchers.IO) {
                    MoodleDirectRepository(session).loadQuizDetails(current.quizzes)
                }
                val updated = current.copy(quizzes = quizzes)
                val persisted = withContext(Dispatchers.IO) { offlineStore.saveSnapshot(updated) }
                _state.update { state ->
                    state.copy(
                        courseSnapshot = if (state.courseSnapshot?.course?.courseId == courseId) persisted else state.courseSnapshot,
                        isLoadingQuizDetails = false,
                        syncProgress = null,
                        message = null
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (error is MoodleSessionExpiredException) clearExpiredSession()
                _state.update {
                    it.copy(
                        isLoadingQuizDetails = false,
                        syncProgress = null,
                        // Missing quiz fields are rendered as "—" in the quiz UI. Do not
                        // inject a technical parser/network error into every test card.
                        message = if (error is MoodleSessionExpiredException) "Сессия Moodle завершилась. Войдите снова." else null
                    )
                }
            } finally {
                quizDetailsInFlight.remove(courseId)
            }
        }
    }

    /** The encrypted session created by native login is the source of truth; WebView cookies are not consulted. */
    private suspend fun loadCurrentMoodleSession(): MoodleBrowserSession? =
        withContext(Dispatchers.IO) { sessionStore.load() }

    /** Resolve resource activities to their pluginfile target before opening the in-app WebView. */
    fun resolveResourceFileUrl(module: MoodleModule, onResolved: (String) -> Unit) {
        viewModelScope.launch {
            val fallback = module.url?.takeIf { it.isNotBlank() }
                ?: "${_state.value.moodleBaseUrl}course/view.php?id=${module.courseId}"
            val session = loadCurrentMoodleSession()
            val target = if (session == null) fallback else withContext(Dispatchers.IO) {
                runCatching { MoodleDirectRepository(session).resolveDirectResourceFileUrl(module) }.getOrNull()
            } ?: fallback
            onResolved(target)
        }
    }

    /** Persist settings parsed from the full text of Moodle's authenticated quiz overview page. */
    fun saveQuizPageMetadata(
        courseId: String,
        cmid: String,
        quizName: String?,
        pageText: String,
        hasQuizInfoBlock: Boolean
    ) {
        val parsed = MoodleQuizPageSettingsParser.parseText(pageText, hasQuizInfoBlock)
        val hasAnyParsedValue = listOf(parsed.openTime, parsed.closeTime, parsed.timeLimit, parsed.allowedAttempts)
            .any { !it.isNullOrBlank() }
        // Missing labels stay null. The UI represents them with an em dash instead of
        // surfacing parser/network diagnostics in every quiz card.
        if (!hasAnyParsedValue && !hasQuizInfoBlock) return
        val current = _state.value.courseSnapshot ?: return
        if (current.course.courseId != courseId) return
        var matched = false
        var changed = false
        val updatedQuizzes = current.quizzes.map { quiz ->
            val idMatches = quiz.cmid == cmid || quiz.url?.let {
                Regex("[?&]id=${Regex.escape(cmid)}(?:&|$)").containsMatchIn(it)
            } == true
            val expectedName = normalizeMoodleDisplayName(quiz.quizName).trim()
            val receivedName = normalizeMoodleDisplayName(quizName).trim()
            val nameMatches = receivedName.isNotBlank() && expectedName.equals(receivedName, ignoreCase = true)
            if (!idMatches && !nameMatches) return@map quiz
            matched = true
            val updated = quiz.copy(
                openTimeText = parsed.openTime ?: quiz.openTimeText,
                closeTimeText = parsed.closeTime ?: quiz.closeTimeText,
                timeLimit = parsed.timeLimit ?: quiz.timeLimit,
                allowedAttempts = parsed.allowedAttempts ?: quiz.allowedAttempts,
                // This page parse is the newest evidence. An older cached success must not
                // keep an incomplete current parse marked as loaded.
                detailsLoaded = parsed.isComplete,
                detailsParserVersion = MoodleQuizPageSettingsParser.VERSION,
                detailsError = null,
                status = null
            )
            if (updated != quiz) changed = true
            updated
        }
        if (!matched || !changed) return
        val updatedSnapshot = current.copy(quizzes = updatedQuizzes)
        viewModelScope.launch {
            val persisted = withContext(Dispatchers.IO) { offlineStore.saveSnapshot(updatedSnapshot) }
            _state.update { state ->
                if (state.courseSnapshot?.course?.courseId == courseId) state.copy(courseSnapshot = persisted) else state
            }
        }
    }

    fun loadAttempts(courseId: String, forceRefresh: Boolean = false) {
        val initial = _state.value.courseSnapshot ?: return
        if (initial.course.courseId != courseId) return
        if (!forceRefresh && courseId in attemptsLoadedCourses) return
        if (!attemptsInFlight.add(courseId)) return

        viewModelScope.launch {
            _state.update { current ->
                val currentSnapshot = current.courseSnapshot
                val invalidatedSnapshot = if (currentSnapshot?.course?.courseId == courseId) {
                    currentSnapshot.copy(
                        attemptsLoaded = false,
                        quizzes = currentSnapshot.quizzes.map { it.copy(hasConfirmedNoAttempts = null) }
                    )
                } else currentSnapshot
                current.copy(
                    courseSnapshot = invalidatedSnapshot,
                    isLoadingAttempts = true,
                    message = null,
                    syncProgress = "Загрузка истории попыток…"
                )
            }
            try {
                val session = loadCurrentMoodleSession()
                if (session == null) {
                    _state.update {
                        it.copy(
                            isLoadingAttempts = false,
                            syncProgress = null,
                            message = "Для загрузки истории попыток требуется сохранённая сессия Moodle."
                        )
                    }
                    return@launch
                }
                val current = _state.value.courseSnapshot
                    ?.takeIf { it.course.courseId == courseId } ?: return@launch
                val attempts = withContext(Dispatchers.IO) {
                    MoodleDirectRepository(session).loadQuizAttempts(current.course, current.quizzes)
                }
                // Merge against the newest snapshot, not the pre-request copy, so a concurrent
                // metadata refresh cannot erase attempt information and vice versa.
                val latest = _state.value.courseSnapshot
                    ?.takeIf { it.course.courseId == courseId } ?: current
                // An authoritative empty history for a quiz clears stale cached rows for that
                // quiz. The repository only returns successfully after every quiz overview was
                // read and any empty history was explicitly confirmed by Moodle.
                val freshCmidsWithAttempts = attempts.mapNotNull { it.cmid?.takeIf(String::isNotBlank) }.toSet()
                val confirmedEmptyCmids = latest.quizzes.mapNotNull { quiz ->
                    val cmid = quiz.cmid?.takeIf(String::isNotBlank)
                        ?: quiz.url?.let { Regex("[?&]id=(\\d+)").find(it)?.groupValues?.get(1) }
                    cmid?.takeIf { it !in freshCmidsWithAttempts }
                }.toSet()
                val fallbackAttempts = latest.attempts.filterNot { it.cmid in confirmedEmptyCmids }
                val mergedAttempts = mergeMoodleQuizAttempts(attempts, fallbackAttempts)
                val updatedQuizzes = latest.quizzes.map { quiz ->
                    val cmid = quiz.cmid?.takeIf(String::isNotBlank)
                        ?: quiz.url?.let { Regex("[?&]id=(\\d+)").find(it)?.groupValues?.get(1) }
                    val hasFreshRows = attempts.any { attempt ->
                        (cmid != null && attempt.cmid == cmid) ||
                            (cmid == null && attempt.quizName.equals(quiz.quizName, ignoreCase = true))
                    }
                    quiz.copy(hasConfirmedNoAttempts = !hasFreshRows)
                }
                val updated = latest.copy(
                    quizzes = updatedQuizzes,
                    attempts = mergedAttempts,
                    attemptsLoaded = true
                )
                val persisted = withContext(Dispatchers.IO) { offlineStore.saveSnapshot(updated) }
                attemptsLoadedCourses.add(courseId)
                _state.update { state ->
                    state.copy(
                        courseSnapshot = if (state.courseSnapshot?.course?.courseId == courseId) persisted else state.courseSnapshot,
                        isLoadingAttempts = false,
                        syncProgress = null,
                        message = null
                    )
                }
            } catch (cancelled: CancellationException) {
                _state.update { it.copy(isLoadingAttempts = false, syncProgress = null) }
                throw cancelled
            } catch (error: Exception) {
                if (error is MoodleSessionExpiredException) clearExpiredSession()
                _state.update { current ->
                    val currentSnapshot = current.courseSnapshot
                    val invalidatedSnapshot = if (currentSnapshot?.course?.courseId == courseId) {
                        currentSnapshot.copy(
                            attemptsLoaded = false,
                            quizzes = currentSnapshot.quizzes.map { it.copy(hasConfirmedNoAttempts = null) }
                        )
                    } else currentSnapshot
                    current.copy(
                        courseSnapshot = invalidatedSnapshot,
                        isLoadingAttempts = false,
                        syncProgress = null,
                        message = if (error is MoodleSessionExpiredException) "Сессия Moodle завершилась. Войдите снова." else null
                    )
                }
            } finally {
                attemptsInFlight.remove(courseId)
            }
        }
    }

    /** Start, resume, or review a quiz using only Moodle Mobile Web Service calls. */
    fun openNativeQuiz(quiz: MoodleQuiz, attemptId: String? = null, review: Boolean = false) {
        if (_state.value.quizRunner?.isLoading == true) return
        _state.update {
            it.copy(quizRunner = MoodleQuizRunnerUiState(
                quizName = quiz.quizName,
                courseId = quiz.courseId,
                quizId = quiz.quizId.orEmpty(),
                attemptId = attemptId,
                isReview = review,
                isLoading = true,
                message = when {
                    review -> "Загружаем разбор попытки…"
                    attemptId != null -> "Восстанавливаем попытку…"
                    else -> "Подготавливаем тест…"
                }
            ), message = null)
        }
        viewModelScope.launch {
            try {
                val session = loadCurrentMoodleSession()
                    ?: throw IllegalStateException("Сессия Moodle не найдена. Войдите в аккаунт заново.")
                installQuizWebViewCookies(session)
                val runner = withContext(Dispatchers.IO) {
                    val repository = MoodleDirectRepository(session)
                    val quizId = repository.resolveQuizInstanceId(quiz)
                        ?: throw IllegalStateException("Не удалось определить внутренний ID теста. Обновите параметры курса.")
                    if (review) {
                        val id = attemptId?.takeIf { it.toLongOrNull() != null }
                            ?: throw IllegalStateException("Moodle не предоставил числовой ID этой попытки; открыть её разбор через внешний сайт нельзя.")
                        val response = repository.getQuizAttemptReview(id, -1)
                        parseQuizRunnerResponse(quiz, quizId, id, response, review = true)
                    } else {
                        val id: String
                        val initialPage: Int
                        if (attemptId.isNullOrBlank()) {
                            val access = repository.getQuizAccessInformation(quizId)
                            val canAttempt = access.get("canattempt")?.let(::jsonBoolean)
                            val accessReasons = jsonStringArray(access.get("preventaccessreasons"))
                            val attemptAccess = repository.getAttemptAccessInformation(quizId)
                            val newAttemptReasons = jsonStringArray(attemptAccess.get("preventnewattemptreasons"))
                            val attemptsExhausted = attemptAccess.get("isfinished")?.let(::jsonBoolean) == true
                            if (canAttempt == false || accessReasons.isNotEmpty() ||
                                newAttemptReasons.isNotEmpty() || attemptsExhausted
                            ) {
                                throw IllegalStateException(
                                    (accessReasons + newAttemptReasons).firstOrNull()
                                        ?: "Moodle не разрешает начать новую попытку этого теста."
                                )
                            }
                            val started = repository.startQuizAttempt(quizId)
                            val attempt = started.get("attempt")?.takeIf { it.isJsonObject }?.asJsonObject ?: started
                            id = attempt.get("id")?.let(::jsonScalar)?.takeIf { it.toLongOrNull() != null }
                                ?: throw IllegalStateException("Moodle не вернул ID созданной попытки.")
                            initialPage = attempt.get("currentpage")?.let { runCatching { it.asInt }.getOrNull() } ?: 0
                        } else {
                            id = attemptId
                            // This endpoint's isfinished flag means that the user cannot ever
                            // start another attempt; it does NOT report the state of attemptId.
                            // get_attempt_data below is the authoritative check for resuming this
                            // specific attempt and Moodle rejects a closed attempt there.
                            repository.getAttemptAccessInformation(quizId, id)
                            val matchingAttempt = _state.value.courseSnapshot?.attempts?.firstOrNull { it.attemptId == id }
                            initialPage = matchingAttempt?.currentPage ?: 0
                        }
                        val pageResponse = repository.getQuizAttemptData(id, initialPage)
                        parseQuizRunnerResponse(quiz, quizId, id, pageResponse, review = false)
                    }
                }
                _state.update { it.copy(quizRunner = runner, message = null) }
            } catch (cancelled: CancellationException) {
                _state.update { it.copy(quizRunner = null) }
                throw cancelled
            } catch (error: Exception) {
                if (error is MoodleSessionExpiredException) clearExpiredSession()
                _state.update { current ->
                    current.copy(quizRunner = current.quizRunner?.copy(
                        isLoading = false,
                        error = error.localizedMessage ?: "Не удалось загрузить тест.",
                        message = null
                    ))
                }
            }
        }
    }

    /** Save currently entered values without submitting the attempt. */
    fun saveNativeQuizResponses(responses: List<Pair<String, String>>) {
        val runner = _state.value.quizRunner ?: return
        val attemptId = runner.attemptId ?: return
        if (runner.isReview || runner.isSummary || runner.isSubmitting) return
        _state.update { it.copy(quizRunner = runner.copy(isSubmitting = true, error = null, message = "Сохраняем ответы…")) }
        viewModelScope.launch {
            try {
                val session = loadCurrentMoodleSession() ?: throw IllegalStateException("Сессия Moodle завершена.")
                withContext(Dispatchers.IO) { MoodleDirectRepository(session).saveQuizAttempt(attemptId, responses) }
                _state.update { current -> current.copy(quizRunner = current.quizRunner?.copy(
                    isSubmitting = false, message = "Ответы сохранены на сервере Moodle.", error = null
                )) }
            } catch (error: Exception) {
                _state.update { current -> current.copy(quizRunner = current.quizRunner?.copy(
                    isSubmitting = false, error = error.localizedMessage ?: "Не удалось сохранить ответы."
                )) }
            }
        }
    }

    fun returnToNativeQuizQuestions() {
        val runner = _state.value.quizRunner ?: return
        val attemptId = runner.attemptId ?: return
        if (!runner.isSummary || runner.isLoading || runner.isSubmitting) return
        _state.update { it.copy(quizRunner = runner.copy(isLoading = true, error = null, message = "Возвращаемся к вопросам…")) }
        viewModelScope.launch {
            try {
                val session = loadCurrentMoodleSession() ?: throw IllegalStateException("Сессия Moodle завершена.")
                val updated = withContext(Dispatchers.IO) {
                    val response = MoodleDirectRepository(session).getQuizAttemptData(attemptId, runner.currentPage)
                    parseQuizRunnerResponseFromData(runner, response, runner.currentPage)
                }
                _state.update { it.copy(quizRunner = updated) }
            } catch (error: Exception) {
                _state.update { it.copy(quizRunner = runner.copy(isLoading = false, error = error.localizedMessage ?: "Не удалось вернуться к вопросам.")) }
            }
        }
    }

    /** Save current question fields, then request the exact next page supplied by Moodle. */
    fun advanceNativeQuiz(responses: List<Pair<String, String>>) {
        val runner = _state.value.quizRunner ?: return
        val attemptId = runner.attemptId ?: return
        if (runner.isLoading || runner.isSubmitting || runner.isReview || runner.isSummary) return
        _state.update { it.copy(quizRunner = runner.copy(isSubmitting = true, error = null, message = "Сохраняем ответы…")) }
        viewModelScope.launch {
            try {
                val session = loadCurrentMoodleSession() ?: throw IllegalStateException("Сессия Moodle завершена.")
                val updated = withContext(Dispatchers.IO) {
                    val repository = MoodleDirectRepository(session)
                    val payload = if (runner.nextPage >= 0) responses + ("nextpage" to runner.nextPage.toString()) else responses + ("nextpage" to "-1")
                    repository.processQuizAttempt(attemptId, payload, finish = false)
                    if (runner.nextPage < 0) {
                        val summary = repository.getQuizAttemptSummary(attemptId)
                        parseQuizRunnerResponseFromSummary(runner, summary)
                    } else {
                        val pageResponse = repository.getQuizAttemptData(attemptId, runner.nextPage)
                        parseQuizRunnerResponseFromData(runner, pageResponse, runner.nextPage)
                    }
                }
                _state.update { it.copy(quizRunner = updated, message = null) }
            } catch (error: Exception) {
                _state.update { it.copy(quizRunner = runner.copy(isSubmitting = false, error = error.localizedMessage ?: "Не удалось сохранить ответы.")) }
            }
        }
    }

    /** Final submission is explicit and separate from moving to the summary page. */
    fun finishNativeQuiz() {
        val runner = _state.value.quizRunner ?: return
        val attemptId = runner.attemptId ?: return
        if (!runner.isSummary || runner.isSubmitting) return
        _state.update { it.copy(quizRunner = runner.copy(isSubmitting = true, error = null, message = "Отправляем тест…")) }
        viewModelScope.launch {
            try {
                val session = loadCurrentMoodleSession() ?: throw IllegalStateException("Сессия Moodle завершена.")
                val result = withContext(Dispatchers.IO) {
                    val repository = MoodleDirectRepository(session)
                    repository.processQuizAttempt(attemptId, emptyList(), finish = true)
                    runCatching { repository.getQuizAttemptReview(attemptId, -1) }.getOrNull()
                }
                val completed = if (result != null) {
                    parseQuizRunnerResponse(_state.value.courseSnapshot?.quizzes?.firstOrNull { it.quizId == runner.quizId }
                        ?: MoodleQuiz(courseId = runner.courseId, quizName = runner.quizName, quizId = runner.quizId),
                        runner.quizId, attemptId, result, review = true).copy(isCompleted = true,
                        message = "Попытка отправлена. Разбор доступен в соответствии с настройками Moodle.")
                } else runner.copy(
                    isSubmitting = false,
                    isCompleted = true,
                    isReview = true,
                    isSummary = false,
                    questions = emptyList(),
                    additionalData = emptyList(),
                    message = "Попытка отправлена. Moodle пока не разрешает просмотр ответов и обратной связи.",
                    error = null
                )
                _state.update { it.copy(quizRunner = completed, message = null) }
                loadAttempts(runner.courseId, forceRefresh = true)
            } catch (error: Exception) {
                _state.update { it.copy(quizRunner = runner.copy(isSubmitting = false, error = error.localizedMessage ?: "Не удалось отправить тест.")) }
            }
        }
    }

    fun closeQuizRunner() {
        _state.update { it.copy(quizRunner = null) }
    }

    private fun installQuizWebViewCookies(session: MoodleBrowserSession) {
        val cookies = CookieManager.getInstance()
        cookies.setAcceptCookie(true)
        session.cookieHeader.split(';').map(String::trim).filter { it.contains('=') }.forEach { pair ->
            // Cookie values are scoped to the configured Moodle origin; do not synthesize a Domain.
            cookies.setCookie(session.baseUrl, "$pair; Path=/; Secure")
        }
        cookies.flush()
    }

    private fun parseQuizRunnerResponse(
        quiz: MoodleQuiz,
        quizId: String,
        attemptId: String,
        response: JsonObject,
        review: Boolean
    ): MoodleQuizRunnerUiState {
        val attempt = response.get("attempt")?.takeIf { it.isJsonObject }?.asJsonObject
        val questions = parseQuizRunnerQuestions(response.get("questions"))
        val extras = parseQuizRunnerExtraData(response.get("additionaldata"))
        val grade = attempt?.get("grade")?.let(::jsonScalar)
            ?: attempt?.get("sumgrades")?.let(::jsonScalar)
            ?: response.get("grade")?.let(::jsonScalar)
        val maxGrade = attempt?.get("maxgrade")?.let(::jsonScalar)
        val gradeText = grade?.let { if (maxGrade.isNullOrBlank()) "Оценка: $it" else "Оценка: $it из $maxGrade" }
        return MoodleQuizRunnerUiState(
            quizName = quiz.quizName,
            courseId = quiz.courseId,
            quizId = quizId,
            attemptId = attemptId,
            currentPage = response.get("attempt")?.asJsonObject?.get("currentpage")?.let { runCatching { it.asInt }.getOrNull() } ?: 0,
            nextPage = response.get("nextpage")?.let { runCatching { it.asInt }.getOrNull() } ?: -1,
            isReview = review,
            isCompleted = review,
            questions = questions,
            additionalData = extras,
            gradeText = gradeText,
            isLoading = false,
            message = if (questions.isEmpty()) "Moodle не вернул HTML содержимого вопросов для этой попытки." else null
        )
    }

    private fun parseQuizRunnerResponseFromData(
        previous: MoodleQuizRunnerUiState,
        response: JsonObject,
        page: Int
    ): MoodleQuizRunnerUiState = previous.copy(
        currentPage = page,
        nextPage = response.get("nextpage")?.let { runCatching { it.asInt }.getOrNull() } ?: -1,
        questions = parseQuizRunnerQuestions(response.get("questions")),
        additionalData = emptyList(),
        isReview = false,
        isSummary = false,
        isCompleted = false,
        isLoading = false,
        isSubmitting = false,
        message = null,
        error = null
    )

    private fun parseQuizRunnerResponseFromSummary(
        previous: MoodleQuizRunnerUiState,
        response: JsonObject
    ): MoodleQuizRunnerUiState = previous.copy(
        questions = parseQuizRunnerQuestions(response.get("questions")),
        isSummary = true,
        isLoading = false,
        isSubmitting = false,
        message = "Проверьте статус ответов. После отправки вернуться к редактированию будет нельзя.",
        error = null
    )

    private fun parseQuizRunnerQuestions(element: JsonElement?): List<MoodleQuizRunnerQuestion> =
        element?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { item ->
            if (!item.isJsonObject) return@mapNotNull null
            val obj = item.asJsonObject
            val number = obj.get("number")?.let(::jsonScalar)
                ?: obj.get("questionnumber")?.let(::jsonScalar)
            val status = obj.get("status")?.let(::jsonScalar)
            val mark = obj.get("mark")?.let(::jsonScalar)
            val maxMark = obj.get("maxmark")?.let(::jsonScalar)
            val rawHtml = obj.get("html")?.let(::jsonScalar).orEmpty()
            val html = rawHtml.ifBlank {
                val title = number?.let { "Вопрос $it" } ?: "Вопрос"
                val detail = listOfNotNull(status, if (mark != null && maxMark != null) "$mark из $maxMark" else mark).joinToString(" · ")
                "<div class=\"quiz-summary-row\"><strong>${title.htmlEscape()}</strong><div>${detail.htmlEscape()}</div></div>"
            }
            if (html.isBlank()) return@mapNotNull null
            MoodleQuizRunnerQuestion(
                slot = obj.get("slot")?.let { runCatching { it.asInt }.getOrNull() } ?: 0,
                number = number,
                html = html,
                status = status,
                mark = mark,
                maxMark = maxMark
            )
        }.orEmpty()

    private fun parseQuizRunnerExtraData(element: JsonElement?): List<MoodleQuizRunnerExtraData> =
        element?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { item ->
            if (!item.isJsonObject) return@mapNotNull null
            val obj = item.asJsonObject
            MoodleQuizRunnerExtraData(
                id = obj.get("id")?.let(::jsonScalar).orEmpty(),
                title = obj.get("title")?.let(::jsonScalar).orEmpty(),
                content = obj.get("content")?.let(::jsonScalar).orEmpty()
            )
        }.orEmpty()

    private fun String.htmlEscape(): String = replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")

    private fun jsonScalar(element: JsonElement): String? = if (element.isJsonNull) null else runCatching {
        if (element.isJsonPrimitive) element.asString else element.toString()
    }.getOrNull()

    private fun jsonBoolean(element: JsonElement): Boolean? = runCatching {
        when {
            element.isJsonNull -> null
            element.asJsonPrimitive.isBoolean -> element.asBoolean
            element.asJsonPrimitive.isNumber -> element.asInt != 0
            else -> element.asString.lowercase() in setOf("1", "true", "yes")
        }
    }.getOrNull()

    private fun jsonStringArray(element: JsonElement?): List<String> =
        element?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { item ->
            jsonScalar(item)?.takeIf(String::isNotBlank)
        }.orEmpty()

    fun loadAttemptDetail(courseId: String, attemptId: String) {
        viewModelScope.launch {
            _state.update { it.copy(isLoadingCourse = true, attemptDetail = null, message = null) }
            val cached = withContext(Dispatchers.IO) { offlineStore.loadAttemptDetail(courseId, attemptId) }
            if (cached != null) {
                _state.update { it.copy(isLoadingCourse = false, attemptDetail = cached.data, isShowingCachedData = true, cacheSavedAt = cached.savedAtEpochMs) }
            } else {
                _state.update { it.copy(isLoadingCourse = false, message = "Подробный разбор не сохранён в приложении. Откройте историю попыток Moodle при подключении к Интернету.") }
            }
        }
    }

    fun search(query: String) {
        searchJob?.cancel()
        if (query.trim().length < 2) {
            _state.update { it.copy(isSearching = false, searchResults = null, message = null) }
            return
        }
        searchJob = viewModelScope.launch {
            _state.update { it.copy(isSearching = true, message = null) }
            val result = withContext(Dispatchers.IO) { offlineStore.search(query.trim()) }
            _state.update {
                it.copy(
                    isSearching = false,
                    searchResults = result,
                    isShowingCachedData = true,
                    message = null
                )
            }
        }
    }

    fun logout() {
        attemptsLoadedCourses.clear()
        quizDetailsInFlight.clear()
        val cookies = CookieManager.getInstance()
        // CookieManager completes asynchronously; clear the encrypted session/cache only after
        // WebView cookies have also been removed so a second account cannot inherit the first.
        cookies.removeAllCookies {
            cookies.flush()
            viewModelScope.launch {
                withContext(Dispatchers.IO) {
                    sessionStore.clear()
                    offlineStore.clearAll()
                    getApplication<Application>().getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS)
                        ?.listFiles()?.forEach { it.deleteRecursively() }
                }
                _state.update {
                    it.copy(
                        isConnected = false,
                        hasSavedSession = false,
                        courses = emptyList(),
                        courseSnapshot = null,
                        attemptDetail = null,
                        quizRunner = null,
                        searchResults = null,
                        isShowingCachedData = false,
                        cacheSavedAt = null,
                        message = null,
                        notice = null
                    )
                }
            }
        }
    }

    override fun onCleared() {
        runCatching { connectivityManager.unregisterNetworkCallback(networkCallback) }
        super.onCleared()
    }

    private suspend fun showOfflineCourseList(message: String) {
        val cached = withContext(Dispatchers.IO) { offlineStore.loadCourses() }
        _state.update {
            it.copy(
                isConnected = false,
                isConnecting = false,
                courses = cached?.data ?: it.courses,
                isShowingCachedData = cached != null,
                cacheSavedAt = cached?.savedAtEpochMs ?: it.cacheSavedAt,
                syncProgress = null,
                message = message
            )
        }
    }

    private suspend fun handleConnectionFailure(error: Exception, prefix: String) {
        if (error is MoodleSessionExpiredException) clearExpiredSession()
        val cached = withContext(Dispatchers.IO) { offlineStore.loadCourses() }
        _state.update {
            it.copy(
                isConnected = false,
                isConnecting = false,
                hasSavedSession = error !is MoodleSessionExpiredException && it.hasSavedSession,
                courses = cached?.data ?: it.courses,
                isShowingCachedData = cached != null || it.courseSnapshot != null,
                cacheSavedAt = cached?.savedAtEpochMs ?: it.cacheSavedAt,
                syncProgress = null,
                notice = null,
                message = when {
                    error is MoodleSessionExpiredException -> "Сессия Moodle завершилась. Войдите повторно; офлайн-кэш останется доступен."
                    cached != null -> "$prefix Показана сохранённая копия; повторите позже."
                    else -> "$prefix ${error.localizedMessage ?: error.javaClass.simpleName}"
                }
            )
        }
    }

    private fun showTransientNotice(text: String, durationMs: Long = 2800L) {
        val sequence = ++noticeSequence
        _state.update { it.copy(notice = text) }
        viewModelScope.launch {
            delay(durationMs)
            if (noticeSequence == sequence) {
                _state.update { current -> if (current.notice == text) current.copy(notice = null) else current }
            }
        }
    }

    private suspend fun clearExpiredSession() {
        attemptsLoadedCourses.clear()
        withContext(Dispatchers.IO) { sessionStore.clear() }
        _state.update { it.copy(hasSavedSession = false) }
    }

    fun closeCourse() = _state.update { it.copy(courseSnapshot = null, attemptDetail = null, quizRunner = null) }
    fun clearMessage() = _state.update { it.copy(message = null, notice = null) }
    fun closeAttemptDetail() = _state.update { it.copy(attemptDetail = null) }
}
