package ru.tusur.study

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkManager
import androidx.work.WorkerParameters

/**
 * Legacy worker retained for installations that may still have an older WorkManager request
 * persisted. New versions do not schedule it, and it intentionally performs no background work.
 */
class MoodleSyncWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result = Result.success()
}

object MoodleSyncScheduler {
    private const val UNIQUE_WORK_NAME = "tusur_moodle_direct_cache_refresh"

    /** Cancel the old periodic refresh so Android does not keep a background-update job alive. */
    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
    }
}
