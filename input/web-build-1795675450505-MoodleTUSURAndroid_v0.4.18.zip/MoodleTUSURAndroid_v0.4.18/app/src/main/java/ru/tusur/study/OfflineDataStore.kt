package ru.tusur.study

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import ru.tusur.moodle.data.MoodleAttemptDetail
import ru.tusur.moodle.data.MoodleCourse
import ru.tusur.moodle.data.MoodleCourseSnapshot
import ru.tusur.moodle.data.MoodleQuizMetadataMerger
import ru.tusur.moodle.data.mergeMoodleQuizAttempts
import ru.tusur.moodle.data.MoodleSearchGrade
import ru.tusur.moodle.data.MoodleSearchModule
import ru.tusur.moodle.data.MoodleSearchResponse
import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypted, account-local cache. Files live inside app-private storage and are not
 * exported through shared storage. The AES key is generated and retained by Android Keystore.
 */
class OfflineDataStore(context: Context) {
    data class Cached<T>(val data: T, val savedAtEpochMs: Long)
    private data class Record<T>(val data: T, val savedAtEpochMs: Long)

    private val gson: Gson = GsonBuilder().disableHtmlEscaping().create()
    private val root = File(context.filesDir, "moodle_offline_cache").apply { mkdirs() }

    @Synchronized
    fun clearAll() {
        root.listFiles()?.forEach { file -> file.deleteRecursively() }
        root.mkdirs()
    }

    @Synchronized
    fun saveCourses(courses: List<MoodleCourse>): List<MoodleCourse> {
        val previous = loadCourses()?.data.orEmpty().associateBy { it.courseId }
        val merged = courses.map { fresh ->
            val old = previous[fresh.courseId] ?: return@map fresh
            fresh.copy(
                sectionCount = fresh.sectionCount ?: old.sectionCount,
                moduleCount = fresh.moduleCount ?: old.moduleCount,
                userVisibleCount = fresh.userVisibleCount ?: old.userVisibleCount,
                accessVisibleCount = fresh.accessVisibleCount ?: old.accessVisibleCount,
                activityCardCount = fresh.activityCardCount ?: old.activityCardCount,
                detailPagesRead = fresh.detailPagesRead ?: old.detailPagesRead,
                sectionCountActual = fresh.sectionCountActual ?: old.sectionCountActual,
                moduleCountActual = fresh.moduleCountActual ?: old.moduleCountActual,
                quizCount = fresh.quizCount ?: old.quizCount,
                gradeCount = fresh.gradeCount ?: old.gradeCount,
                counts = fresh.counts ?: old.counts
            )
        }
        write("courses.json", Record(merged, System.currentTimeMillis()))
        return merged
    }

    @Synchronized
    fun loadCourses(): Cached<List<MoodleCourse>>? {
        val type = object : TypeToken<Record<List<MoodleCourse>>>() {}.type
        val record: Record<List<MoodleCourse>> = read("courses.json", type) ?: return null
        return Cached(record.data, record.savedAtEpochMs)
    }

    @Synchronized
    fun saveSnapshot(snapshot: MoodleCourseSnapshot): MoodleCourseSnapshot {
        val type = object : TypeToken<Record<MoodleCourseSnapshot>>() {}.type
        val oldRecord: Record<MoodleCourseSnapshot>? = read(snapshotFile(snapshot.course.courseId), type)
        val old = oldRecord?.data
        val merged = if (old == null) snapshot else mergeSnapshot(old, snapshot)
        write(snapshotFile(snapshot.course.courseId), Record(merged, System.currentTimeMillis()))
        return merged
    }

    /** Keep previously collected attempt reviews and rich fields when a live sync endpoint omits them. */
    private fun mergeSnapshot(old: MoodleCourseSnapshot, fresh: MoodleCourseSnapshot): MoodleCourseSnapshot {
        val oldModules = old.modules.associateBy { it.cmid }
        val modules = if (fresh.modules.isEmpty()) old.modules else fresh.modules.map { module ->
            val previous = oldModules[module.cmid] ?: return@map module
            module.copy(
                courseCardText = module.courseCardText?.takeIf { it.isNotBlank() } ?: previous.courseCardText,
                detailsText = module.detailsText?.takeIf { it.isNotBlank() } ?: previous.detailsText,
                detailsUrl = module.detailsUrl ?: previous.detailsUrl,
                fileLinksJson = module.fileLinksJson?.takeIf { it.isNotBlank() && it != "[]" } ?: previous.fileLinksJson
            )
        }
        val quizzes = MoodleQuizMetadataMerger.merge(old.quizzes, fresh.quizzes)
        val attempts = mergeMoodleQuizAttempts(fresh.attempts, old.attempts)
        val grades = if (fresh.grades.data.isNotEmpty()) fresh.grades else old.grades
        val sections = if (fresh.sections.isNotEmpty()) fresh.sections else old.sections
        val calendar = if (fresh.calendar.isNotEmpty()) fresh.calendar else old.calendar
        val mergedCourse = fresh.course.copy(
            sectionCount = fresh.course.sectionCount ?: old.course.sectionCount,
            moduleCount = fresh.course.moduleCount ?: old.course.moduleCount,
            userVisibleCount = fresh.course.userVisibleCount ?: old.course.userVisibleCount,
            accessVisibleCount = fresh.course.accessVisibleCount ?: old.course.accessVisibleCount,
            activityCardCount = fresh.course.activityCardCount ?: old.course.activityCardCount,
            detailPagesRead = fresh.course.detailPagesRead ?: old.course.detailPagesRead,
            sectionCountActual = fresh.course.sectionCountActual ?: old.course.sectionCountActual,
            moduleCountActual = fresh.course.moduleCountActual ?: old.course.moduleCountActual,
            quizCount = fresh.course.quizCount ?: old.course.quizCount,
            gradeCount = fresh.course.gradeCount ?: old.course.gradeCount,
            counts = fresh.course.counts ?: old.course.counts
        )
        return fresh.copy(
            course = mergedCourse,
            sections = sections,
            modules = modules,
            quizzes = quizzes,
            grades = grades,
            attempts = attempts,
            calendar = calendar
        )
    }

    @Synchronized
    fun loadSnapshot(courseId: String): Cached<MoodleCourseSnapshot>? {
        val type = object : TypeToken<Record<MoodleCourseSnapshot>>() {}.type
        val record: Record<MoodleCourseSnapshot> = read(snapshotFile(courseId), type) ?: return null
        return Cached(record.data, record.savedAtEpochMs)
    }

    @Synchronized
    fun saveAttemptDetail(detail: MoodleAttemptDetail) {
        write(attemptFile(detail.courseId, detail.attemptId), Record(detail, System.currentTimeMillis()))
    }

    @Synchronized
    fun loadAttemptDetail(courseId: String, attemptId: String): Cached<MoodleAttemptDetail>? {
        val type = object : TypeToken<Record<MoodleAttemptDetail>>() {}.type
        val record: Record<MoodleAttemptDetail> = read(attemptFile(courseId, attemptId), type) ?: return null
        return Cached(record.data, record.savedAtEpochMs)
    }

    @Synchronized
    fun search(query: String): MoodleSearchResponse {
        val term = query.trim().lowercase()
        if (term.length < 2) return MoodleSearchResponse(query = query)
        val modules = ArrayList<MoodleSearchModule>()
        val grades = ArrayList<MoodleSearchGrade>()
        root.listFiles { file -> file.isFile && file.name.startsWith("course_") && file.name.endsWith(".json") }
            .orEmpty()
            .forEach { file ->
                val courseId = file.name.removePrefix("course_").removeSuffix(".json")
                val cached = loadSnapshot(courseId)?.data ?: return@forEach
                cached.modules.filter { module ->
                    module.name.contains(term, true) ||
                        module.courseCardText.orEmpty().contains(term, true) ||
                        module.detailsText.orEmpty().contains(term, true)
                }.take(200).forEach { module ->
                    modules += MoodleSearchModule(
                        courseId = module.courseId,
                        courseName = cached.course.name,
                        cmid = module.cmid,
                        name = module.name,
                        type = module.type,
                        modname = module.modname,
                        sectionId = module.sectionId,
                        sectionNumber = module.sectionNumber,
                        url = module.url,
                        visible = module.visible,
                        uservisible = module.uservisible,
                        accessvisible = module.accessvisible,
                        detailsUrl = module.detailsUrl,
                        fileLinksJson = module.fileLinksJson
                    )
                }
                cached.grades.data.filter { it.name.contains(term, true) }.take(100).forEach { grade ->
                    grades += MoodleSearchGrade(
                        courseId = grade.courseId,
                        name = grade.name,
                        score = grade.score,
                        maxScore = grade.maxScore,
                        percent = grade.percent
                    )
                }
            }
        return MoodleSearchResponse(query = query, modules = modules.take(200), grades = grades.take(100))
    }

    private fun snapshotFile(courseId: String) = "course_${safeName(courseId)}.json"
    private fun attemptFile(courseId: String, attemptId: String) = "attempt_${safeName(courseId)}_${safeName(attemptId)}.json"
    private fun safeName(value: String) = value.filter { it.isLetterOrDigit() || it == '-' || it == '_' }.take(80).ifBlank { "unknown" }

    private fun <T> write(name: String, value: T) {
        val target = File(root, name)
        val temp = File(root, "$name.tmp")
        temp.writeText(encrypt(gson.toJson(value)), Charsets.UTF_8)
        try {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        } catch (_: Exception) {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    private fun <T> read(name: String, type: java.lang.reflect.Type): T? {
        val file = File(root, name)
        if (!file.isFile) return null
        return runCatching { gson.fromJson<T>(decrypt(file.readText(Charsets.UTF_8)), type) }.getOrNull()
    }

    private fun encrypt(plainText: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }

    private fun decrypt(blob: String): String {
        val parts = blob.split(":", limit = 2)
        require(parts.size == 2) { "Offline cache has an invalid encrypted payload" }
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val encrypted = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(encrypted).toString(Charsets.UTF_8)
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEY_STORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private companion object {
        const val KEY_ALIAS = "tusur_study_offline_cache_v1"
        const val ANDROID_KEY_STORE = "AndroidKeyStore"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
