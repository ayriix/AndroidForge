package ru.tusur.study

import ru.tusur.moodle.data.normalizeMoodleFileName

import android.Manifest
import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Environment
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import kotlinx.coroutines.flow.collect
import androidx.activity.ExperimentalActivityApi
import androidx.activity.compose.PredictiveBackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView


/** Creates a collision-free title for a public Download/ entry. */
private fun uniquePublicDownloadName(context: Context, preferredName: String): String {
    val manager = context.getSystemService(DownloadManager::class.java)
        ?: return preferredName
    val existing = mutableSetOf<String>()
    val cursor = try {
        manager.query(DownloadManager.Query())
    } catch (_: Exception) {
        null
    }
    cursor?.use { resultCursor ->
        val index: Int = resultCursor.getColumnIndex(DownloadManager.COLUMN_TITLE)
        if (index >= 0) {
            while (resultCursor.moveToNext()) {
                existing.add(resultCursor.getString(index).orEmpty().lowercase(java.util.Locale.ROOT))
            }
        }
    }
    val dot = preferredName.lastIndexOf('.')
    val stem = if (dot > 0) preferredName.substring(0, dot) else preferredName
    val extension = if (dot > 0) preferredName.substring(dot) else ""
    var candidate = preferredName
    var suffix = 2
    while (candidate.lowercase(java.util.Locale.ROOT) in existing) {
        candidate = "$stem ($suffix)$extension"
        suffix++
    }
    return candidate
}

@OptIn(ExperimentalActivityApi::class)
@Composable
fun MoodleWebViewScreen(
    startUrl: String,
    onClose: () -> Unit,
    onSessionReady: ((String, String, String, String?) -> Unit)? = null,
    onQuizMetadata: ((String, String?, String, Boolean) -> Unit)? = null
) {
    val context = LocalContext.current
    var progress by remember(startUrl) { mutableIntStateOf(0) }
    var currentUrl by remember(startUrl) { mutableStateOf(startUrl) }
    var loadError by remember(startUrl) { mutableStateOf<String?>(null) }
    var showLeaveAttemptConfirmation by remember { mutableStateOf(false) }
    var fileChooserCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    var pendingWebPermission by remember { mutableStateOf<PermissionRequest?>(null) }
    var customView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    val webView = remember(startUrl) { WebView(context) }
    val browserContainer = remember(webView) {
        FrameLayout(context).apply {
            setBackgroundColor(android.graphics.Color.WHITE)
            addView(
                webView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }
    }
    val popupViews = remember(webView) { mutableStateListOf<WebView>() }
    val popupParents = remember(webView) { mutableMapOf<WebView, WebView>() }
    var activeWebView by remember(webView) { mutableStateOf(webView) }
    val latestSessionCallback by rememberUpdatedState(onSessionReady)
    val latestQuizMetadataCallback by rememberUpdatedState(onQuizMetadata)
    var lastCapturedSession by remember(startUrl) { mutableStateOf("") }

    fun isBlockedHost(host: String): Boolean {
        val normalized = host.lowercase()
        return normalized == "sdo.tusur.ru" || normalized.endsWith(".sdo.tusur.ru")
    }

    fun isTrustedMediaOrigin(uri: Uri): Boolean {
        val host = uri.host.orEmpty().lowercase()
        return uri.scheme.equals("https", true) &&
            !isBlockedHost(host) &&
            (host == MOODLE_HOST || host.endsWith(".tusur.ru"))
    }

    fun configureWebView(target: WebView) {
        target.setBackgroundColor(android.graphics.Color.WHITE)
        target.settings.javaScriptEnabled = true
        target.settings.domStorageEnabled = true
        target.settings.databaseEnabled = true
        target.settings.loadsImagesAutomatically = true
        target.settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        target.settings.allowFileAccess = false
        target.settings.allowContentAccess = true
        target.settings.javaScriptCanOpenWindowsAutomatically = true
        target.settings.setSupportMultipleWindows(true)
        target.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        target.settings.mediaPlaybackRequiresUserGesture = true
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(target, true)
    }

    // WebView.webViewClient is non-null in the Android API. Replace the Compose-capturing
    // client with an inert default client before destroying the WebView.
    fun disposeWebView(target: WebView) {
        runCatching {
            target.stopLoading()
            target.webChromeClient = null
            target.webViewClient = WebViewClient()
            target.removeAllViews()
            target.destroy()
        }
    }

    fun downloadFromWebView(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        downloadMoodleResource(context, url, userAgent, contentDisposition, mimeType)
    }

    fun activatePopup(target: WebView, url: String) {
        val parsed = Uri.parse(url)
        if (parsed.scheme != "https" || isBlockedHost(parsed.host.orEmpty())) return
        if (target !== activeWebView && popupViews.contains(target)) {
            activeWebView.visibility = View.INVISIBLE
            activeWebView = target
            target.visibility = View.VISIBLE
        }
        currentUrl = url
        progress = 0
        loadError = null
    }

    fun closePopup(target: WebView) {
        if (!popupViews.contains(target)) return
        val parent = popupParents[target] ?: webView
        popupParents.entries
            .filter { it.value === target }
            .map { it.key }
            .forEach { child -> popupParents[child] = parent }
        browserContainer.removeView(target)
        popupViews.remove(target)
        popupParents.remove(target)
        disposeWebView(target)
        if (activeWebView === target) {
            val fallback = when {
                parent === webView -> webView
                popupViews.contains(parent) -> parent
                else -> popupViews.lastOrNull() ?: webView
            }
            activeWebView = fallback
            fallback.visibility = View.VISIBLE
            currentUrl = fallback.url ?: startUrl
            progress = 100
            loadError = null
        }
    }

    fun exitCustomView() {
        val shown = customView ?: return
        browserContainer.removeView(shown)
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        activeWebView.visibility = View.VISIBLE
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = fileChooserCallback
        fileChooserCallback = null
        val selected = if (result.resultCode == Activity.RESULT_OK) {
            WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        } else null
        callback?.onReceiveValue(selected)
    }

    val webPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val request = pendingWebPermission
        pendingWebPermission = null
        if (request == null) return@rememberLauncherForActivityResult
        val origin = request.origin
        if (!isTrustedMediaOrigin(origin)) {
            request.deny()
            return@rememberLauncherForActivityResult
        }
        val approved = request.resources.filter { resource ->
            when (resource) {
                PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                    results[Manifest.permission.RECORD_AUDIO] == true ||
                        context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                    results[Manifest.permission.CAMERA] == true ||
                        context.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                else -> false
            }
        }
        if (approved.isNotEmpty()) request.grant(approved.toTypedArray()) else request.deny()
    }

    fun createWebViewClient(target: WebView): WebViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val uri = request?.url ?: return false
            val host = uri.host.orEmpty().lowercase()
            if (isBlockedHost(host)) {
                Toast.makeText(context, "Переход на отдельную систему SDO отключён.", Toast.LENGTH_SHORT).show()
                return true
            }
            // Moodle's pluginfile downloads should be handed straight to Android DownloadManager.
            if (uri.scheme.equals("https", true) && host == MOODLE_HOST &&
                (uri.path?.contains("/pluginfile.php", true) == true ||
                 uri.getQueryParameter("forcedownload") == "1")) {
                downloadMoodleResource(context, uri.toString())
                return true
            }
            // HTTPS pages stay in the in-app browser. Moodle cookies remain scoped by WebView.
            return !uri.scheme.equals("https", true)
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
            val startedUrl = url ?: target.url ?: return
            if (target !== activeWebView && popupViews.contains(target)) {
                // Keep the previous valid page visible while a new target=_blank window is still
                // at about:blank. Switch only after a real HTTPS navigation has begun.
                activatePopup(target, startedUrl)
            } else if (target === activeWebView) {
                currentUrl = startedUrl
                progress = 0
                loadError = null
            }
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            val finishedUrl = url ?: target.url ?: return
            if (target === activeWebView) {
                currentUrl = finishedUrl
                progress = 100
                    }
            CookieManager.getInstance().flush()

            // Only adjust the Moodle page chrome. Do not inject scripts into BBB or other hosts:
            // their popup, window.open, navigation and question JavaScript must remain untouched.
            val finishedUri = Uri.parse(finishedUrl)
            val finishedPath = finishedUri.path.orEmpty()
            val isQuizPage = finishedPath.contains("/mod/quiz/", ignoreCase = true)
            val isQuizOverviewPage = finishedPath.contains("/mod/quiz/view.php", ignoreCase = true)
            if (finishedUri.host.orEmpty().equals(MOODLE_HOST, ignoreCase = true)) {
                // Read-only fallback from the exact, authenticated page Moodle has rendered.
                // This is more reliable than a second HTTP parser for themes that split labels
                // and values across nested spans. It never opens attempt.php or changes an attempt.
                if (isQuizOverviewPage) {
                    // Moodle can fill parts of the overview asynchronously. Capture the visible
                    // settings more than once after load so the native quiz card is not tied to
                    // the first, sometimes incomplete, DOM snapshot.
                    val metadataScript = """(() => {
                        const path = (location.pathname || '').toLowerCase();
                        const isQuizOverview = /\/mod\/quiz\/view\.php$/.test(path);
                        const url = new URL(location.href);
                        const id = url.searchParams.get('id') || url.searchParams.get('cmid') || '';
                        const heading = document.querySelector('#page-header h1, h1.h2, h1');
                        const name = ((heading && heading.innerText) || '').replace(/\s+/g, ' ').trim();

                        // Moodle themes place quiz settings in different containers. Read those
                        // blocks first, then the main content; never slice the first 16 KB of
                        // document.body, because a long nav drawer can push the quiz table out.
                        const selectors = [
                            '.quizinfo', '.quizdates', '.quizattempt', '.box.quizinfo',
                            '[class*=\"quizinfo\"]', '#region-main', '#region-main-box',
                            '#page-content', 'main'
                        ];
                        const fragments = [];
                        const seen = new Set();
                        for (const selector of selectors) {
                            for (const element of document.querySelectorAll(selector)) {
                                const value = (element.innerText || '').trim();
                                if (value && !seen.has(value)) {
                                    seen.add(value);
                                    fragments.push(value);
                                }
                            }
                        }
                        if (fragments.length === 0) {
                            const fallback = (document.body && document.body.innerText) ||
                                (document.documentElement && document.documentElement.innerText) || '';
                            if (fallback.trim()) fragments.push(fallback);
                        }
                        const text = fragments.join('\n').replace(/\u00a0/g, ' ').replace(/\r/g, '')
                            .split('\n').map(line => line.replace(/[\t ]+/g, ' ').trim())
                            .filter(Boolean).join('\n');
                        return JSON.stringify({id, name, text, hasInfo: isQuizOverview});
                    })()""".trimIndent()

                    val captureMetadata = {
                        if (target.url == finishedUrl) {
                            target.evaluateJavascript(metadataScript) { raw ->
                                runCatching {
                                    val decoded = com.google.gson.JsonParser.parseString(raw).asString
                                    val result = com.google.gson.JsonParser.parseString(decoded).asJsonObject
                                    val cmid = result.get("id")?.takeIf { !it.isJsonNull }?.asString.orEmpty()
                                    val quizName = result.get("name")?.takeIf { !it.isJsonNull }?.asString
                                    val pageText = result.get("text")?.takeIf { !it.isJsonNull }?.asString.orEmpty()
                                    val hasInfo = result.get("hasInfo")?.takeIf { !it.isJsonNull }?.asBoolean ?: false
                                    if (cmid.isNotBlank() && pageText.isNotBlank()) {
                                        latestQuizMetadataCallback?.invoke(cmid, quizName, pageText, hasInfo)
                                    }
                                }
                            }
                        }
                    }
                    target.postDelayed({ if (target.isAttachedToWindow) captureMetadata() }, 250L)
                    target.postDelayed({ if (target.isAttachedToWindow) captureMetadata() }, 900L)
                    target.postDelayed({ if (target.isAttachedToWindow) captureMetadata() }, 1800L)
                    target.postDelayed({ if (target.isAttachedToWindow) captureMetadata() }, 3200L)
                    target.postDelayed({ if (target.isAttachedToWindow) captureMetadata() }, 6000L)
                    target.postDelayed({ if (target.isAttachedToWindow) captureMetadata() }, 10000L)
                }
                if (!isQuizPage) {
                    val appChromeScript = """(function(){
                    try {
                        if (!document.getElementById('tusur-study-app-style')) {
                            const style = document.createElement('style');
                            style.id = 'tusur-study-app-style';
                            style.textContent = `
                                #page-header,
                                #page-navbar,
                                #nav-drawer,
                                #page-footer,
                                .navbar,
                                .primary-navigation,
                                .secondary-navigation,
                                .tertiary-navigation,
                                .breadcrumb,
                                .breadcrumb-nav,
                                .breadcrumb-container,
                                [data-region="drawer"],
                                [data-region="header-actions-container"] { display: none !important; }
                                #page.drawers, #page, #page-content, #region-main-box, #region-main {
                                    margin: 0 !important; padding-top: 0 !important;
                                }
                                #page-content, .main-inner {
                                    max-width: none !important; padding-left: 8px !important; padding-right: 8px !important;
                                }
                                body { overflow-x: hidden !important; }
                            `;
                            (document.head || document.documentElement).appendChild(style);
                        }
                    } catch (ignored) {}
                })();"""
                    target.evaluateJavascript(appChromeScript, null)
                }

                val js = """(() => {
                    const cfg = (window.M && window.M.cfg) ? window.M.cfg : {};
                    const loginForm = !!document.querySelector('form#login, form[action*="login/index.php"]');
                    const logoutLink = !!Array.from(document.querySelectorAll('a[href]')).find(a => /logout/i.test(a.href));
                    const userMenu = !!document.querySelector('.usermenu, [data-region="user-menu"], [data-region="user-menu-toggle"], #usernavigation, a[href*="/user/profile.php"]');
                    const profileLink = Array.from(document.querySelectorAll('a[href]')).find(a => /\/user\/profile\.php\?id=\d+/i.test(a.href));
                    const profileMatch = profileLink ? profileLink.href.match(/[?&]id=(\d+)/i) : null;
                    const userNode = document.querySelector('[data-userid], [data-user-id]');
                    const userId = (profileMatch && profileMatch[1]) || cfg.userid || (userNode && (userNode.getAttribute('data-userid') || userNode.getAttribute('data-user-id'))) || '';
                    const path = (window.location.pathname || '').toLowerCase();
                    const looksLikeLogin = path.includes('/login/') || loginForm;
                    const hasLogoutText = /\blog ?out\b|\blogout\b|выход/i.test(document.body ? document.body.innerText : '');
                    const authenticatedUserId = /^\d+$/.test(userId) && Number(userId) > 1;
                    return JSON.stringify({sesskey: cfg.sesskey || '', userId: userId, loggedIn: !!cfg.sesskey && !looksLikeLogin && (logoutLink || userMenu || hasLogoutText || authenticatedUserId)});
                })()"""
                target.evaluateJavascript(js) { raw ->
                    runCatching {
                        val encoded = com.google.gson.JsonParser.parseString(raw).asString
                        val info = com.google.gson.JsonParser.parseString(encoded).asJsonObject
                        val loggedIn = info.get("loggedIn")?.asBoolean == true
                        val sesskey = info.get("sesskey")?.asString.orEmpty()
                        val userId = info.get("userId")?.asString?.takeIf { it.matches(Regex("[0-9]{1,12}")) }
                        val current = Uri.parse(finishedUrl)
                        val base = "${current.scheme}://${current.authority}/"
                        val cookies = CookieManager.getInstance().getCookie(base).orEmpty()
                        val fingerprint = (userId.orEmpty()) + ":" + sesskey + ":" + cookies.hashCode()
                        if (loggedIn && sesskey.isNotBlank() && cookies.isNotBlank() && fingerprint != lastCapturedSession) {
                            lastCapturedSession = fingerprint
                            latestSessionCallback?.invoke(base, sesskey, cookies, userId)
                        }
                    }
                }
            }
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: android.webkit.WebResourceError?
        ) {
            if (request?.isForMainFrame == true && target === activeWebView) {
                loadError = "Ошибка загрузки (${error?.errorCode ?: "?"}): ${error?.description ?: "сетевой сбой"}. Проверьте мобильную сеть/VPN и повторите попытку."
            }
        }

        override fun onReceivedHttpError(
            view: WebView?,
            request: WebResourceRequest?,
            errorResponse: android.webkit.WebResourceResponse?
        ) {
            if (request?.isForMainFrame == true && target === activeWebView && (errorResponse?.statusCode ?: 200) >= 400) {
                loadError = "Сайт вернул HTTP ${errorResponse?.statusCode}. Возможно, закончилась сессия или активность недоступна."
            }
        }
    }

    fun createWebChromeClient(target: WebView): WebChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            if (target === activeWebView) progress = newProgress
        }

        override fun onShowFileChooser(
            view: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            fileChooserCallback?.onReceiveValue(null)
            if (filePathCallback == null || fileChooserParams == null) return false
            fileChooserCallback = filePathCallback
            return runCatching {
                filePicker.launch(fileChooserParams.createIntent())
                true
            }.getOrElse {
                fileChooserCallback = null
                filePathCallback.onReceiveValue(null)
                false
            }
        }

        override fun onPermissionRequest(request: PermissionRequest?) {
            val permissionRequest = request ?: return
            if (!isTrustedMediaOrigin(permissionRequest.origin)) {
                permissionRequest.deny()
                return
            }
            val required = buildList {
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in permissionRequest.resources) {
                    add(Manifest.permission.RECORD_AUDIO)
                }
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in permissionRequest.resources) {
                    add(Manifest.permission.CAMERA)
                }
            }.distinct()
            if (required.isEmpty()) {
                permissionRequest.deny()
                return
            }
            val missing = required.filter {
                context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isEmpty()) {
                val approved = permissionRequest.resources.filter {
                    it == PermissionRequest.RESOURCE_AUDIO_CAPTURE || it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
                }
                permissionRequest.grant(approved.toTypedArray())
            } else {
                pendingWebPermission?.deny()
                pendingWebPermission = permissionRequest
                webPermissionLauncher.launch(missing.toTypedArray())
            }
        }

        override fun onPermissionRequestCanceled(request: PermissionRequest?) {
            if (pendingWebPermission === request) pendingWebPermission = null
        }

        override fun onCreateWindow(
            view: WebView?,
            isDialog: Boolean,
            isUserGesture: Boolean,
            resultMsg: Message?
        ): Boolean {
            // Ignore unsolicited popups. Moodle/BBB windows initiated by a user click are kept
            // inside TUSUR Study. The original page remains visible until the popup navigates.
            if (!isUserGesture) return false
            val message = resultMsg ?: return false
            val sourceUri = Uri.parse(view?.url ?: target.url ?: startUrl)
            if (!sourceUri.scheme.equals("https", true) || isBlockedHost(sourceUri.host.orEmpty())) return false

            val popup = WebView(context)
            configureWebView(popup)
            popup.visibility = View.INVISIBLE
            popup.webViewClient = createWebViewClient(popup)
            popup.webChromeClient = createWebChromeClient(popup)
            popup.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                downloadFromWebView(url, userAgent, contentDisposition, mimeType)
            }
            popupParents[popup] = activeWebView
            browserContainer.addView(
                popup,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            popupViews.add(popup)

            val transport = message.obj as? WebView.WebViewTransport
            if (transport == null) {
                closePopup(popup)
                return false
            }
            transport.webView = popup
            message.sendToTarget()
            return true
        }

        override fun onCloseWindow(window: WebView?) {
            if (window != null) closePopup(window)
        }

        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
            if (view == null || customView != null) {
                callback?.onCustomViewHidden()
                return
            }
            customView = view
            customViewCallback = callback
            activeWebView.visibility = View.INVISIBLE
            browserContainer.addView(
                view,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }

        override fun onHideCustomView() {
            exitCustomView()
        }
    }

    fun attachDownloadListener(target: WebView) {
        target.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            downloadFromWebView(url, userAgent, contentDisposition, mimeType)
        }
    }

    val isActiveQuizAttempt = currentUrl.contains("/mod/quiz/attempt.php", ignoreCase = true) ||
        currentUrl.contains("/mod/quiz/summary.php", ignoreCase = true)

    PredictiveBackHandler(enabled = true) { progress ->
        // Collect the complete gesture stream. Navigation is performed only when the user
        // commits the edge swipe; a cancelled predictive gesture leaves the WebView untouched.
        progress.collect { /* progress animation is intentionally not needed here */ }
        when {
            customView != null -> exitCustomView()
            isActiveQuizAttempt -> showLeaveAttemptConfirmation = true
            activeWebView.canGoBack() -> activeWebView.goBack()
            activeWebView !== webView && popupViews.contains(activeWebView) -> closePopup(activeWebView)
            else -> onClose()
        }
    }

    DisposableEffect(webView, startUrl) {
        configureWebView(webView)
        webView.webViewClient = createWebViewClient(webView)
        webView.webChromeClient = createWebChromeClient(webView)
        attachDownloadListener(webView)

        val parsed = Uri.parse(startUrl)
        val allowed = parsed.scheme == "https" && parsed.host.orEmpty().equals(MOODLE_HOST, ignoreCase = true)
        if (allowed && webView.url != startUrl) {
            val savedSession = MoodleSessionStore(context).load()
            val savedBase = savedSession?.baseUrl.orEmpty()
            val sameMoodleHost = runCatching { Uri.parse(savedBase).host.equals(MOODLE_HOST, true) }.getOrDefault(false)
            val savedCookies = savedSession?.cookieHeader.orEmpty()
                .split(';')
                .map { it.trim() }
                .filter { it.contains('=') && !it.startsWith("Path=", true) }
            val liveWebViewCookies = CookieManager.getInstance().getCookie("https://$MOODLE_HOST/").orEmpty()
            if (sameMoodleHost && savedCookies.isNotEmpty() && liveWebViewCookies.isBlank()) {
                var pending = savedCookies.size
                savedCookies.forEach { cookie ->
                    CookieManager.getInstance().setCookie("https://$MOODLE_HOST/", "$cookie; Path=/; Secure") {
                        pending -= 1
                        if (pending == 0) {
                            CookieManager.getInstance().flush()
                            if (webView.url != startUrl) webView.loadUrl(startUrl)
                        }
                    }
                }
            } else {
                webView.loadUrl(startUrl)
            }
        } else if (!allowed) {
            loadError = "Открытие заблокировано: разрешён только основной HTTPS-сайт Moodle ТУСУР."
        }

        onDispose {
            fileChooserCallback?.onReceiveValue(null)
            fileChooserCallback = null
            pendingWebPermission?.deny()
            pendingWebPermission = null
            if (customView != null) exitCustomView()
            popupViews.toList().forEach { popup ->
                browserContainer.removeView(popup)
                disposeWebView(popup)
            }
            popupViews.clear()
            popupParents.clear()
            CookieManager.getInstance().flush()
            browserContainer.removeView(webView)
            disposeWebView(webView)
        }
    }

    // Keep Moodle content immersive: navigation is handled by the Android back gesture/button
    // through PredictiveBackHandler above. Avoid a second, bulky browser toolbar inside the app.
    Column(modifier = Modifier.fillMaxSize()) {
        if (progress in 1..99) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth().height(2.dp)
            )
        }
        loadError?.let {
            Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Text(it, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { loadError = null; activeWebView.reload() }) { Text("Повторить") }
                }
            }
        }
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { browserContainer })
    }

    if (showLeaveAttemptConfirmation) {
        AlertDialog(
            onDismissRequest = { showLeaveAttemptConfirmation = false },
            title = { Text("Покинуть активную попытку?") },
            text = {
                Text("Вы находитесь на странице прохождения теста. Перед выходом убедитесь, что Moodle сохранил ответы и вы отправили попытку штатной кнопкой. Выход из страницы не отправляет тест автоматически.")
            },
            confirmButton = {
                TextButton(onClick = {
                    showLeaveAttemptConfirmation = false
                    if (activeWebView !== webView && popupViews.contains(activeWebView)) closePopup(activeWebView) else onClose()
                }) { Text("Выйти со страницы") }
            },
            dismissButton = {
                TextButton(onClick = { showLeaveAttemptConfirmation = false }) { Text("Остаться") }
            }
        )
    }
}
