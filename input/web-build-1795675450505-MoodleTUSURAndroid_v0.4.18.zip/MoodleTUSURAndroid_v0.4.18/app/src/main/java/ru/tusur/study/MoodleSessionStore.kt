package ru.tusur.study

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.google.gson.Gson
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Moodle session created by the native login flow (cookies + sesskey + optional mobile WS token). */
data class MoodleBrowserSession(
    val baseUrl: String,
    val cookieHeader: String,
    val sesskey: String,
    val userId: String? = null,
    val capturedAtEpochMs: Long = System.currentTimeMillis(),
    val webServiceToken: String? = null
)

/** Session cookies and sesskey are encrypted with a key stored in Android Keystore. */
class MoodleSessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("tusur_moodle_session", Context.MODE_PRIVATE)
    private val gson = Gson()

    @Synchronized
    fun save(session: MoodleBrowserSession) {
        check(prefs.edit().putString(KEY_SESSION, encrypt(gson.toJson(session))).commit()) {
            "Не удалось сохранить зашифрованную сессию Moodle в памяти приложения"
        }
    }

    @Synchronized
    fun load(): MoodleBrowserSession? {
        val encrypted = prefs.getString(KEY_SESSION, null) ?: return null
        return runCatching { gson.fromJson(decrypt(encrypted), MoodleBrowserSession::class.java) }.getOrNull()
    }

    @Synchronized
    fun clear() {
        prefs.edit().remove(KEY_SESSION).commit()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" +
            Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        val parts = value.split(":", limit = 2)
        require(parts.size == 2) { "Invalid encrypted Moodle session" }
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val bytes = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return cipher.doFinal(bytes).toString(Charsets.UTF_8)
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private companion object {
        const val KEY_SESSION = "encrypted_browser_session"
        const val KEY_ALIAS = "tusur_study_moodle_session_v1"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
