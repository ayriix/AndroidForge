package ru.tusur.moodle.data

/**
 * Extracts the final grade block rendered on Moodle's quiz overview page.
 * Moodle can show the grade below the attempts table (and may forbid attempt review),
 * so the grade is independent evidence that at least one attempt was submitted.
 */
object MoodleQuizOverviewSummaryParser {
    data class Summary(
        val score: String? = null,
        val maxScore: String? = null,
        val submittedAt: String? = null
    ) {
        val hasFinalGrade: Boolean get() = score != null && maxScore != null
    }

    private val finalGradePattern = Regex(
        "(?iu)(?:ваша\\s+итоговая\\s+оценка\\s+за\\s+этот\\s+тест|" +
            "ваша\\s+итоговая\\s+оценка|your\\s+final\\s+grade\\s+for\\s+this\\s+quiz|" +
            "your\\s+final\\s+grade)\\s*:?\\s*" +
            "(-?\\d[\\d\\s\\u00A0]*(?:[,.]\\d+)?)\\s*/\\s*" +
            "(-?\\d[\\d\\s\\u00A0]*(?:[,.]\\d+)?)"
    )

    private val submittedMarker = Regex("(?iu)(?:отправлено|submitted)\\s*:?[ \\t]*")

    fun parse(plainText: String): Summary {
        // HTML-to-text implementations differ in whether they add line breaks between nested
        // Moodle blocks. Collapse all whitespace so the final grade pattern works in both cases.
        val normalized = plainText
            .replace('\u00A0', ' ')
            .replace('\u202F', ' ')
            .replace(Regex("\\s+"), " ")
        val grade = finalGradePattern.find(normalized)
        val submittedAt = submittedMarker.findAll(normalized).lastOrNull()?.let { marker ->
            val tail = normalized.substring(marker.range.last + 1)
                .trim()
            MoodleDateTimeParser.extract(tail)
        }
        return Summary(
            score = grade?.groupValues?.getOrNull(1)?.normalizeNumber(),
            maxScore = grade?.groupValues?.getOrNull(2)?.normalizeNumber(),
            submittedAt = submittedAt
        )
    }

    private fun String.normalizeNumber(): String =
        replace(Regex("\\s+"), "").replace(',', '.')
}
