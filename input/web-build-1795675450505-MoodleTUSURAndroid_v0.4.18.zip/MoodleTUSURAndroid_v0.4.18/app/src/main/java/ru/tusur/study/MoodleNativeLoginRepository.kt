package ru.tusur.study

import com.google.gson.JsonParser
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Authenticates directly against Moodle without opening a WebView or an external browser.
 * Passwords are used only for the two HTTPS login requests and are never persisted.
 */
class MoodleNativeLoginRepository(
    private val baseUrl: String = DEFAULT_MOODLE_BASE_URL
) {
    data class Result(
        val session: MoodleBrowserSession,
        val mobileServiceWarning: String? = null
    )

    private val clientBuilder = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .followRedirects(false)
        .followSslRedirects(false)

    fun authenticate(username: String, password: String): Result {
        require(username.isNotBlank()) { "Введите логин Moodle." }
        require(password.isNotBlank()) { "Введите пароль Moodle." }
        require(baseUrl.startsWith("https://", true)) { "Авторизация разрешена только через HTTPS." }

        val siteRoot = (baseUrl.trimEnd('/') + "/").toHttpUrlOrNull()
            ?: throw MoodleNativeLoginException("Некорректный адрес Moodle.")
        val initialUrl = siteRoot.newBuilder().addPathSegments("login/index.php").build()
        require(initialUrl.host.equals(MOODLE_HOST, true)) { "Разрешён только официальный Moodle ТУСУР." }
        val jar = InMemoryCookieJar()
        val client = clientBuilder.cookieJar(jar).build()

        val loginPage = executeFollowingSameHostRedirects(
            client,
            Request.Builder().url(initialUrl).header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml")
                .get().build()
        ).first
        val loginToken = inputValue(loginPage, "logintoken")
            ?: throw MoodleNativeLoginException("Moodle не выдал защитный logintoken. Вход через форму не выполнен.")

        val loginBody = FormBody.Builder()
            .add("username", username.trim())
            .add("password", password)
            .add("logintoken", loginToken)
            .build()
        val loginResponse = executeFollowingSameHostRedirects(
            client,
            Request.Builder().url(initialUrl)
                .header("User-Agent", USER_AGENT)
                .header("Origin", initialUrl.scheme + "://" + initialUrl.host)
                .header("Referer", initialUrl.toString())
                .header("Accept", "text/html,application/xhtml+xml")
                .post(loginBody).build()
        ).first

        if (looksLikeLoginForm(loginResponse)) {
            val reason = findLoginError(loginResponse)
            throw MoodleNativeLoginException(reason ?: "Moodle отклонил логин или пароль.")
        }

        val myUrl = siteRoot.newBuilder().addPathSegments("my/").build()
        val dashboard = executeFollowingSameHostRedirects(
            client,
            Request.Builder().url(myUrl)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml")
                .get().build()
        ).first
        if (looksLikeLoginForm(dashboard)) {
            throw MoodleNativeLoginException("Moodle не подтвердил вход. Проверьте логин, пароль и способ авторизации аккаунта.")
        }

        val sesskey = findConfigValue(dashboard, "sesskey")
            ?: inputValue(dashboard, "sesskey")
            ?: Regex("(?is)[?&]sesskey=([A-Za-z0-9]+)").find(dashboard)?.groupValues?.getOrNull(1)
            ?: throw MoodleNativeLoginException("Вход выполнен не полностью: Moodle не передал sesskey.")
        val userId = findConfigValue(dashboard, "userid")
            ?: Regex("(?is)data-userid\\s*=\\s*[\"'](\\d+)[\"']").find(dashboard)?.groupValues?.getOrNull(1)
        val cookieHeader = jar.loadForRequest(myUrl)
            .joinToString("; ") { "${it.name}=${it.value}" }
        if (cookieHeader.isBlank()) {
            throw MoodleNativeLoginException("Moodle подтвердил страницу профиля, но не выдал сессионные cookies.")
        }

        // The official Mobile Web Services token is optional for ordinary cookie/AJAX use,
        // but required for Moodle's quiz attempt API. Keep login successful if the site admin
        // has disabled this service and expose the limitation to the user in app state.
        val tokenResult = requestMobileServiceToken(client, siteRoot, username.trim(), password)
        val session = MoodleBrowserSession(
            baseUrl = baseUrl.trimEnd('/') + "/",
            cookieHeader = cookieHeader,
            sesskey = sesskey,
            userId = userId,
            webServiceToken = tokenResult.first
        )
        return Result(session, tokenResult.second)
    }

    private fun requestMobileServiceToken(
        client: OkHttpClient,
        loginBase: HttpUrl,
        username: String,
        password: String
    ): Pair<String?, String?> {
        val tokenUrl = loginBase.newBuilder().addPathSegments("login/token.php").build()
        val body = FormBody.Builder()
            .add("username", username)
            .add("password", password)
            .add("service", "moodle_mobile_app")
            .build()
        var lastNetworkError: IOException? = null

        // The token request happens immediately after native login. Retry once for a transient
        // network failure while the credentials are still in memory; never persist the password.
        repeat(2) { attempt ->
            try {
                val response = executeFollowingSameHostRedirects(
                    client,
                    Request.Builder().url(tokenUrl)
                        .header("User-Agent", USER_AGENT)
                        .header("Accept", "application/json")
                        .post(body).build()
                ).first
                val json = runCatching { JsonParser.parseString(response) }.getOrNull()
                val root = json?.takeIf { it.isJsonObject }?.asJsonObject
                val token = root?.get("token")?.takeIf { !it.isJsonNull }?.asString
                    ?.takeIf { it.isNotBlank() }
                if (token != null) return token to null

                val errorCode = root?.get("errorcode")?.takeIf { !it.isJsonNull }
                    ?.let { runCatching { it.asString }.getOrNull() }
                    ?.lowercase()
                val serverMessage = root?.let {
                    it.get("message")?.takeIf { value -> !value.isJsonNull }
                        ?: it.get("error")?.takeIf { value -> !value.isJsonNull }
                }?.let { runCatching { it.asString }.getOrNull() }
                val rawLower = response.lowercase()
                val warning = when {
                    errorCode == "enablewsdescription" || rawLower.contains("enablewsdescription") ||
                        rawLower.contains("необходимо включить веб-службы") ->
                        "На сервере Moodle отключены веб-службы. Приложение не может включить их самостоятельно; нативные функции тестов останутся недоступны."
                    errorCode == "servicenotavailable" || rawLower.contains("servicenotavailable") ->
                        "На сервере Moodle отключена служба moodle_mobile_app. Нужна доступная служба Mobile Web Services."
                    errorCode == "invalidlogin" ->
                        "Moodle не выдал токен Mobile Web Services: сервер отклонил повторную проверку учётных данных. Войдите в Moodle заново."
                    !serverMessage.isNullOrBlank() -> serverMessage.take(180)
                    else ->
                        "Вход выполнен, но Moodle не выдал токен Mobile Web Services. Проверьте доступность службы moodle_mobile_app или повторите вход при стабильном соединении."
                }
                return null to warning
            } catch (error: IOException) {
                lastNetworkError = error
                if (attempt == 0) {
                    try {
                        Thread.sleep(650L)
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return null to "Получение токена Mobile Web Services было прервано. Повторите вход в Moodle."
                    }
                }
            } catch (error: Exception) {
                return null to (error.message?.take(180)
                    ?: "Не удалось получить токен Mobile Web Services Moodle.")
            }
        }

        val detail = lastNetworkError?.message?.takeIf { it.isNotBlank() }
        return null to buildString {
            append("Вход выполнен, но запрос токена Mobile Web Services не прошёл из-за сетевой ошибки.")
            append(" Пароль не сохраняется; для повторного получения токена войдите в Moodle заново после восстановления соединения.")
            if (!detail.isNullOrBlank()) append(" Детали: ").append(detail)
        }
    }

    private fun executeFollowingSameHostRedirects(
        client: OkHttpClient,
        initial: Request
    ): Pair<String, HttpUrl> {
        var request = initial
        repeat(7) {
            client.newCall(request).execute().use { response ->
                if (response.code in 300..399) {
                    val location = response.header("Location")
                        ?: throw MoodleNativeLoginException("Moodle вернул перенаправление без адреса.")
                    val target = response.request.url.resolve(location)
                        ?: throw MoodleNativeLoginException("Moodle вернул некорректное перенаправление.")
                    if (!target.isHttps || !target.host.equals(MOODLE_HOST, true)) {
                        throw MoodleNativeLoginException("Moodle перенаправил авторизацию на другой домен. Переход остановлен.")
                    }
                    request = if (response.code == 303 || (response.code in 301..302 && request.method == "POST")) {
                        Request.Builder().url(target)
                            .header("User-Agent", USER_AGENT)
                            .header("Accept", "text/html,application/xhtml+xml,application/json")
                            .get().build()
                    } else request.newBuilder().url(target).build()
                } else {
                    val body = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw MoodleNativeLoginException("Moodle вернул HTTP ${response.code} при авторизации.")
                    }
                    return body to response.request.url
                }
            }
        }
        throw MoodleNativeLoginException("Moodle превысил допустимое число перенаправлений при авторизации.")
    }

    private fun inputValue(html: String, name: String): String? {
        val tag = Regex("(?is)<input\\b[^>]*>").findAll(html).firstOrNull { match ->
            attribute(match.value, "name").equals(name, true)
        }?.value ?: return null
        return attribute(tag, "value")?.takeIf { it.isNotBlank() }
    }

    private fun attribute(tag: String, name: String): String? = Regex(
        "(?is)\\b${Regex.escape(name)}\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))"
    ).find(tag)?.let { it.groupValues.drop(1).firstOrNull(String::isNotEmpty) }
        ?.replace("&amp;", "&")

    private fun findConfigValue(html: String, name: String): String? {
        val patterns = listOf(
            Regex("(?is)[\"']${Regex.escape(name)}[\"']\\s*:\\s*[\"']([^\"']+)[\"']"),
            Regex("(?is)(?:M\\.cfg\\.)?${Regex.escape(name)}\\s*=\\s*[\"']([^\"']+)[\"']"),
            Regex("(?is)[\"']${Regex.escape(name)}[\"']\\s*:\\s*(\\d+)")
        )
        return patterns.firstNotNullOfOrNull { it.find(html)?.groupValues?.getOrNull(1) }
    }

    private fun looksLikeLoginForm(html: String): Boolean =
        Regex("(?is)<input\\b[^>]*name=[\"']username[\"']").containsMatchIn(html) &&
            Regex("(?is)<input\\b[^>]*name=[\"']password[\"']").containsMatchIn(html)

    private fun findLoginError(html: String): String? {
        val block = Regex("(?is)<(?:div|span)\\b[^>]*id=[\"'](?:loginerrormessage|loginerrors)[\"'][^>]*>(.*?)</(?:div|span)>")
            .find(html)?.groupValues?.getOrNull(1) ?: return null
        return block.replace(Regex("(?is)<[^>]+>"), " ")
            .replace("&nbsp;", " ", true).replace("&amp;", "&", true)
            .replace(Regex("\\s+"), " ").trim().takeIf { it.isNotBlank() }
    }

    private class InMemoryCookieJar : CookieJar {
        private val cookies = mutableListOf<Cookie>()

        @Synchronized
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            cookies.forEach { incoming ->
                this.cookies.removeAll {
                    it.name == incoming.name && it.domain == incoming.domain && it.path == incoming.path
                }
                if (!incoming.persistent || incoming.expiresAt > System.currentTimeMillis()) {
                    this.cookies += incoming
                }
            }
            this.cookies.removeAll { it.persistent && it.expiresAt <= System.currentTimeMillis() }
        }

        @Synchronized
        override fun loadForRequest(url: HttpUrl): List<Cookie> = cookies.filter { it.matches(url) }
    }

    private companion object {
        const val USER_AGENT = "MoodleTUSURAndroid/0.4.18 (Android; native login)"
    }
}

class MoodleNativeLoginException(message: String) : Exception(message)
