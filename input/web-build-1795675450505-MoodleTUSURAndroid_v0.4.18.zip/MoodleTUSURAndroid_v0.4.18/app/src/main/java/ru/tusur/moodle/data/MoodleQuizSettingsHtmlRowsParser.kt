package ru.tusur.moodle.data

/**
 * Extracts Moodle quiz settings as label/value pairs before HTML-to-text flattening can
 * lose table-cell boundaries. The caller supplies Android's Html.fromHtml conversion.
 */
object MoodleQuizSettingsHtmlRowsParser {
    private val labels = listOf(
        "открыто с", "открыт с", "открывается", "дата открытия", "дата начала", "доступно с", "opens", "available from",
        "закрыто с", "закрыт с", "закрывается", "дата закрытия", "дата окончания", "доступно до", "закрытие", "closes", "available until",
        "ограничение по времени", "ограничение времени", "время выполнения", "время на выполнение", "лимит времени", "time limit",
        "разрешено попыток", "количество попыток", "число попыток", "attempts allowed"
    )

    /** Returns only rows whose label is a recognized quiz setting and whose value is non-empty. */
    fun extract(html: String, toText: (String) -> String): List<String> {
        fun normalizedLabel(value: String): String = value
            .lowercase()
            .replace('ё', 'е')
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()

        fun isSettingsLabel(value: String): Boolean {
            val normalized = normalizedLabel(value)
            return labels.any { label ->
                val candidate = normalizedLabel(label)
                normalized == candidate || normalized.startsWith("$candidate ")
            }
        }

        val output = mutableListOf<String>()
        Regex("(?is)<tr\\b[^>]*>(.*?)</tr>").findAll(html).forEach { row ->
            val fragment = row.groupValues[1]
            val header = Regex("(?is)<th\\b[^>]*>(.*?)</th>").find(fragment)?.groupValues?.get(1)
            val cells = Regex("(?is)<td\\b[^>]*>(.*?)</td>").findAll(fragment).map { it.groupValues[1] }.toList()
            val labelHtml = header ?: cells.getOrNull(0) ?: return@forEach
            val valueHtml = if (header != null) cells.firstOrNull() else cells.getOrNull(1)
            val label = toText(labelHtml).trim().trimEnd(':')
            val value = toText(valueHtml.orEmpty()).trim()
            if (isSettingsLabel(label) && value.isNotBlank()) output += "$label: $value"
        }

        Regex("(?is)<dt\\b[^>]*>(.*?)</dt>\\s*<dd\\b[^>]*>(.*?)</dd>").findAll(html).forEach { pair ->
            val label = toText(pair.groupValues[1]).trim().trimEnd(':')
            val value = toText(pair.groupValues[2]).trim()
            if (isSettingsLabel(label) && value.isNotBlank()) output += "$label: $value"
        }
        return output.distinct()
    }
}
