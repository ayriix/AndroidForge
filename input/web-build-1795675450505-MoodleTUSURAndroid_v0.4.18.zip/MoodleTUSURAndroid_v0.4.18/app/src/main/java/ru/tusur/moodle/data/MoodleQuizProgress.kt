package ru.tusur.moodle.data

/** The student's state for a quiz, independent from the teacher's open/close schedule. */
enum class MoodleQuizProgressState {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED,
    UNKNOWN
}

data class MoodleQuizProgress(
    val state: MoodleQuizProgressState,
    /** Actual or derived completion time. Set only when a finished attempt is confirmed. */
    val completedAt: String? = null,
    /** Teacher-configured close time. Used only when the student has not started an attempt. */
    val deadlineAt: String? = null,
    val latestAttempt: MoodleQuizAttempt? = null
)

/**
 * Resolves progress for a single quiz.
 *
 * Important: the quiz opening date is never used to infer that a student completed a quiz when
 * there is no attempt row. A confirmed finished attempt may use its own start + elapsed time,
 * then the configured limit as a last resort. An unfinished attempt always wins over the old
 * finished attempt when it is the more recent attempt.
 */
fun resolveMoodleQuizProgress(
    quiz: MoodleQuiz,
    attempts: List<MoodleQuizAttempt>,
    teacherDeadline: String? = quiz.closeTimeText,
    attemptsLoaded: Boolean = true
): MoodleQuizProgress {
    val finished = attempts
        .filter(::isMoodleFinishedAttempt)
        .maxByOrNull(::moodleAttemptSortOrder)
    val inProgress = attempts
        .filter(::isMoodleInProgressAttempt)
        .maxByOrNull(::moodleAttemptSortOrder)

    val inProgressIsCurrent = inProgress != null &&
        (finished == null || moodleAttemptSortOrder(inProgress) >= moodleAttemptSortOrder(finished))

    if (inProgressIsCurrent || quiz.hasInProgressAttempt == 1) {
        return MoodleQuizProgress(
            state = MoodleQuizProgressState.IN_PROGRESS,
            latestAttempt = inProgress
        )
    }

    if (finished != null) {
        val completedAt = finished.completed?.takeIf { it.isNotBlank() }
            ?: deriveMoodleAttemptCompletedTime(
                started = finished.started,
                actualElapsed = finished.elapsed,
                recordedCompleted = finished.completed,
                configuredTimeLimit = quiz.timeLimit
            )
        return MoodleQuizProgress(
            state = MoodleQuizProgressState.COMPLETED,
            completedAt = completedAt,
            latestAttempt = finished
        )
    }

    // This is independent evidence from Moodle's mod_quiz_get_user_best_grade endpoint.
    // It may prove that a graded attempt exists even when the attempts table hides its link/row.
    // Never fabricate a completion timestamp from the course activity's opening time.
    if (quiz.hasApiBestGrade == true) {
        return MoodleQuizProgress(state = MoodleQuizProgressState.COMPLETED)
    }

    // Moodle may hide the attempt row while still displaying a grade. A successful HTTP/API
    // request by itself is not enough to infer "not started": the repository sets this flag only
    // after the overview page explicitly says that no attempts exist (or the complete-state API
    // confirms an empty history and the overview is readable).
    val explicitNotStartedRow = attempts.any(::isMoodleExplicitNotStartedAttempt)
    if (explicitNotStartedRow || (attempts.isEmpty() && attemptsLoaded && quiz.hasConfirmedNoAttempts == true)) {
        return MoodleQuizProgress(
            state = MoodleQuizProgressState.NOT_STARTED,
            deadlineAt = teacherDeadline?.takeIf { it.isNotBlank() }
        )
    }

    return MoodleQuizProgress(state = MoodleQuizProgressState.UNKNOWN)
}

internal fun isMoodleInProgressAttempt(attempt: MoodleQuizAttempt): Boolean {
    if (!attempt.completed.isNullOrBlank()) return false
    val status = attempt.status.orEmpty().lowercase().replace('ё', 'е')
    if (listOf("в процессе", "продолжается", "не заверш", "не отправ", "in progress", "incomplete", "not submitted", "not completed", "started")
            .any(status::contains)
    ) return true

    // A row with a start but no submission timestamp represents an unfinished attempt unless
    // Moodle explicitly marks it as finished.
    return !attempt.started.isNullOrBlank() && attempt.completed.isNullOrBlank() &&
        !isMoodleFinishedStatus(status)
}

internal fun isMoodleFinishedAttempt(attempt: MoodleQuizAttempt): Boolean {
    if (!attempt.completed.isNullOrBlank()) return true
    return isMoodleFinishedStatus(attempt.status.orEmpty().lowercase().replace('ё', 'е'))
}

private fun isMoodleExplicitNotStartedAttempt(attempt: MoodleQuizAttempt): Boolean {
    val status = attempt.status.orEmpty().lowercase().replace('ё', 'е').trim()
    return status in setOf("не начата", "не начат", "not_started", "not started", "notstarted")
}

private fun isMoodleFinishedStatus(status: String): Boolean {
    if (listOf("в процессе", "продолжается", "не заверш", "не отправ", "in progress", "incomplete", "not submitted", "not completed", "started")
            .any(status::contains)
    ) return false
    return listOf("заверш", "отправ", "finished", "submitted", "completed")
        .any(status::contains)
}
