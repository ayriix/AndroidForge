package ru.tusur.moodle.data

/**
 * Parses the previous-attempts table from Moodle's authenticated quiz overview page.
 * Moodle may omit both the attempt-number column and the review link (when review is forbidden).
 * A row is still a valid attempt when its status cell says Finished/Submitted or In progress.
 */
object MoodleQuizAttemptTableParser {
    data class Row(
        val attemptId: String,
        val attemptRow: String?,
        val status: String?,
        val reviewHref: String?,
        val started: String?,
        val completed: String?,
        val elapsed: String?,
        val score: String?,
        val maxScore: String?
    )

    private data class HtmlCell(val tag: String, val html: String, val text: String)

    fun extract(html: String, toText: (String) -> String): List<Row> {
        val output = mutableListOf<Row>()
        Regex("(?is)<table\\b[^>]*>(.*?)</table>").findAll(html).forEach { tableMatch ->
            val tableHtml = tableMatch.groupValues[1]
            val htmlRows = Regex("(?is)<tr\\b[^>]*>(.*?)</tr>").findAll(tableHtml)
                .map { it.groupValues[1] }.toList()
            val parsedRows = htmlRows.map { rowHtml ->
                Regex("(?is)<(th|td)\\b[^>]*>(.*?)</\\1>").findAll(rowHtml).map { cellMatch ->
                    val cellHtml = cellMatch.groupValues[2]
                    HtmlCell(
                        tag = cellMatch.groupValues[1].lowercase(),
                        html = cellHtml,
                        text = toText(cellHtml).replace(Regex("\\s+"), " ").trim()
                    )
                }.toList()
            }

            fun looksLikeHeader(row: List<HtmlCell>): Boolean {
                val labels = row.map { normalizeLabel(it.text) }
                val hasStatus = labels.any { it in setOf("состояние", "статус", "status", "state") }
                val hasAnotherAttemptColumn = labels.any {
                    it.contains("попытка") || it.contains("attempt") || it.contains("оценка") ||
                        it.contains("grade") || it.contains("просмотр") || it.contains("review")
                }
                return row.size >= 2 && hasStatus && hasAnotherAttemptColumn
            }

            // Moodle themes do not always use <thead> or <th> for column labels. Identify the
            // header semantically, and skip only that row. This also supports a table with
            // exactly these columns: "Состояние | Оценка / 18,00 | Просмотр".
            val explicitHeaderRowIndex = parsedRows.indexOfFirst(::looksLikeHeader)
            val allThHeaderIndex = if (explicitHeaderRowIndex < 0) {
                parsedRows.indexOfFirst { row -> row.size >= 2 && row.all { it.tag == "th" } }
            } else -1
            val headerRowIndex = when {
                explicitHeaderRowIndex >= 0 -> explicitHeaderRowIndex
                allThHeaderIndex >= 0 -> allThHeaderIndex
                else -> -1
            }
            val headerCells = parsedRows.getOrNull(headerRowIndex).orEmpty().map { it.text }
            val normalizedHeaders = headerCells.map(::normalizeLabel)

            fun headerIndex(vararg labels: String): Int = normalizedHeaders.indexOfFirst { header ->
                labels.any { label -> header.contains(normalizeLabel(label)) }
            }
            val statusColumn = headerIndex("состояние", "статус", "state", "status")
            val attemptColumn = headerIndex("попытка", "attempt")
            val gradeColumn = headerIndex("оценка", "результат", "grade", "marks")
            val gradeHeader = headerCells.getOrNull(gradeColumn).orEmpty()
            val maxFromGradeHeader = Regex("(?iu)(?:/|из|out of)\\s*(-?\\d+(?:[,.]\\d+)?)")
                .find(gradeHeader)?.groupValues?.getOrNull(1)?.replace(',', '.')

            parsedRows.forEachIndexed { rowIndex, cells ->
                if (cells.isEmpty() || rowIndex == headerRowIndex) return@forEachIndexed
                val cellTexts = cells.map { it.text }
                val rowHtml = htmlRows.getOrNull(rowIndex).orEmpty()

                fun cellAt(index: Int): String? = cellTexts.getOrNull(index)
                    ?.takeIf(String::isNotBlank)
                fun cellFor(vararg labels: String): String? {
                    val index = normalizedHeaders.indexOfFirst { header ->
                        labels.any { label -> header.contains(normalizeLabel(label)) }
                    }
                    return cellAt(index)
                }

                val attemptHrefId = Regex("(?is)[?&]attempt=(\\d+)")
                    .find(rowHtml)?.groupValues?.getOrNull(1)
                val attemptCell = if (attemptColumn >= 0) cellAt(attemptColumn).orEmpty()
                    else cellTexts.firstOrNull().orEmpty()
                val labelledAttemptNumber = Regex("(?iu)(?:попытка|attempt)\\s*#?\\s*(\\d+)")
                    .find(attemptCell)?.groupValues?.getOrNull(1)
                val plainAttemptNumber = attemptCell.trim().removePrefix("#")
                    .takeIf { it.matches(Regex("\\d{1,4}")) }
                val attemptNumber = labelledAttemptNumber ?: plainAttemptNumber

                val statusCell = if (statusColumn >= 0) cellAt(statusColumn) else null
                val rowText = cellTexts.joinToString(" ").replace(Regex("\\s+"), " ").trim()
                val statusSource = statusCell ?: rowText
                val normalizedStatusSource = statusSource.lowercase().replace('ё', 'е')
                val status = when {
                    listOf(
                        "в процессе", "продолжается", "не заверш", "не отправ", "in progress",
                        "incomplete", "not submitted", "not completed", "started", "overdue", "not started"
                    ).any(normalizedStatusSource::contains) -> "В процессе"
                    listOf("заверш", "finished", "submitted", "отправ", "completed", "abandoned")
                        .any(normalizedStatusSource::contains) -> "Завершена"
                    else -> null
                }

                val reviewHref = Regex("(?is)href\\s*=\\s*[\"']([^\"']*(?:review|attempt)\\.php[^\"']*)[\"']")
                    .find(rowHtml)?.groupValues?.getOrNull(1)?.replace("&amp;", "&")

                // Do not require an attempt number or attempt.php link. Moodle can suppress both
                // while leaving the attempt status, submitted timestamp and grade visible.
                // A recognized status is sufficient evidence that this row belongs to history.
                if (status == null && attemptHrefId == null && reviewHref == null) return@forEachIndexed

                val stableId = attemptHrefId ?: "row:${attemptNumber ?: rowIndex}"
                fun dateFrom(value: String?): String? = MoodleDateTimeParser.extract(value)
                val datesInCells = cellTexts.mapNotNull(::dateFrom).distinct()
                val submittedAt = MoodleDateTimeParser.extractSubmittedTimestamp(statusSource, cellTexts)
                val started = dateFrom(cellFor("начат", "начало", "started"))
                    ?: datesInCells.firstOrNull()?.takeIf { datesInCells.size > 1 }
                val completed = dateFrom(cellFor("завершено", "завершение", "отправлено", "completed", "submitted"))
                    ?: submittedAt
                    ?: datesInCells.lastOrNull()?.takeIf { datesInCells.size > 1 }
                    ?: datesInCells.singleOrNull()?.takeIf { status == "Завершена" }
                val elapsed = cleanMoodleElapsed(cellFor("время выполнения", "затраченное время", "time taken", "duration"))
                    ?: deriveMoodleElapsed(started, completed)

                val gradeRaw = if (gradeColumn >= 0) cellAt(gradeColumn) else cellFor("оценка", "результат", "grade", "marks")
                val gradeSource = gradeRaw ?: rowText
                val fraction = Regex("(-?\\d+(?:[,.]\\d+)?)\\s*(?:/|из)\\s*(-?\\d+(?:[,.]\\d+)?)")
                    .find(gradeSource)
                    ?: Regex("(-?\\d+(?:[,.]\\d+)?)\\s*(?:/|из)\\s*(-?\\d+(?:[,.]\\d+)?)").find(rowText)
                val standaloneScore = if (fraction == null && gradeRaw != null) {
                    Regex("-?\\d+(?:[,.]\\d+)?").find(gradeRaw)?.value
                } else null

                output += Row(
                    attemptId = stableId,
                    attemptRow = attemptCell.takeIf { attemptColumn >= 0 && it.isNotBlank() } ?: attemptNumber,
                    status = status,
                    reviewHref = reviewHref,
                    started = started,
                    completed = completed,
                    elapsed = elapsed,
                    score = fraction?.groupValues?.get(1)?.replace(',', '.') ?: standaloneScore?.replace(',', '.'),
                    maxScore = fraction?.groupValues?.get(2)?.replace(',', '.') ?: maxFromGradeHeader
                )
            }
        }
        return output.distinctBy { it.attemptId }
    }

    private fun normalizeLabel(value: String): String = value
        .lowercase()
        .replace('ё', 'е')
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()
}
