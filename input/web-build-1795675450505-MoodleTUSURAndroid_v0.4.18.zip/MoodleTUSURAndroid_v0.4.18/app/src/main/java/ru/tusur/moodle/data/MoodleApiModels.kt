package ru.tusur.moodle.data

import com.google.gson.annotations.SerializedName

/** Common envelope returned by list endpoints. */
data class ApiListResponse<T>(
    val data: List<T> = emptyList(),
    val meta: ApiPageMeta? = null
)

data class ApiDataResponse<T>(val data: T)

data class ApiPageMeta(
    val total: Int? = null,
    val limit: Int? = null,
    val offset: Int? = null
)

data class MoodleHealth(
    val ok: Boolean = false,
    val service: String? = null,
    @SerializedName("schema_version") val schemaVersion: Int? = null,
    val account: MoodleAccount? = null,
    val counts: Map<String, Int> = emptyMap()
)

data class MoodleAccount(
    @SerializedName("account_id") val accountId: String? = null,
    val site: String? = null,
    @SerializedName("identity_included") val identityIncluded: Int? = null,
    @SerializedName("created_at") val createdAt: String? = null
)

data class MoodleCourse(
    @SerializedName("account_id") val accountId: String? = null,
    @SerializedName("course_id") val courseId: String,
    val site: String? = null,
    val name: String,
    val shortname: String? = null,
    val url: String? = null,
    val source: String? = null,
    @SerializedName("page_title") val pageTitle: String? = null,
    @SerializedName("page_error") val pageError: String? = null,
    @SerializedName("section_count") val sectionCount: Int? = null,
    @SerializedName("module_count") val moduleCount: Int? = null,
    @SerializedName("uservisible_count") val userVisibleCount: Int? = null,
    @SerializedName("accessvisible_count") val accessVisibleCount: Int? = null,
    @SerializedName("activity_card_count") val activityCardCount: Int? = null,
    @SerializedName("detail_pages_read") val detailPagesRead: Int? = null,
    @SerializedName("section_count_actual") val sectionCountActual: Int? = null,
    @SerializedName("module_count_actual") val moduleCountActual: Int? = null,
    @SerializedName("quiz_count") val quizCount: Int? = null,
    @SerializedName("grade_count") val gradeCount: Int? = null,
    val counts: MoodleCourseCounts? = null
)

data class MoodleCourseCounts(
    val sections: Int? = null,
    val modules: Int? = null,
    val quizzes: Int? = null,
    val grades: Int? = null,
    val attempts: Int? = null
)

data class MoodleSection(
    @SerializedName("account_id") val accountId: String? = null,
    @SerializedName("course_id") val courseId: String,
    @SerializedName("section_id") val sectionId: String,
    val number: Int? = null,
    val name: String? = null,
    val visible: Int? = null,
    @SerializedName("has_restrictions") val hasRestrictions: Int? = null,
    val collapsed: Int? = null,
    val url: String? = null,
    @SerializedName("course_name") val courseName: String? = null,
    @SerializedName("module_count") val moduleCount: Int? = null
)

data class MoodleModule(
    @SerializedName("account_id") val accountId: String? = null,
    @SerializedName("course_id") val courseId: String,
    val cmid: String,
    @SerializedName("section_id") val sectionId: String? = null,
    @SerializedName("section_number") val sectionNumber: Int? = null,
    val name: String,
    val type: String? = null,
    val modname: String? = null,
    val url: String? = null,
    val visible: Int? = null,
    val uservisible: Int? = null,
    val accessvisible: Int? = null,
    @SerializedName("has_restrictions") val hasRestrictions: Int? = null,
    @SerializedName("completion_state") val completionState: Int? = null,
    @SerializedName("course_card_text") val courseCardText: String? = null,
    @SerializedName("details_text") val detailsText: String? = null,
    @SerializedName("details_url") val detailsUrl: String? = null,
    @SerializedName("file_links_json") val fileLinksJson: String? = null,
    @SerializedName("course_name") val courseName: String? = null
) {
    val isVisibleToUser: Boolean get() = uservisible == 1
    val isAccessVisible: Boolean get() = accessvisible == 1
}

data class MoodleQuiz(
    @SerializedName("account_id") val accountId: String? = null,
    @SerializedName("course_id") val courseId: String,
    val cmid: String? = null,
    @SerializedName("quiz_id") val quizId: String? = null,
    @SerializedName("quiz_name") val quizName: String,
    @SerializedName("section_id") val sectionId: String? = null,
    @SerializedName("section_number") val sectionNumber: Int? = null,
    val url: String? = null,
    val visible: Int? = null,
    val status: String? = null,
    @SerializedName("completed_review_links") val completedReviewLinks: Int? = null,
    @SerializedName("has_attempt_history") val hasAttemptHistory: Int? = null,
    @SerializedName("has_in_progress_attempt") val hasInProgressAttempt: Int? = null,
    @SerializedName("review_denied_text_present") val reviewDeniedTextPresent: Int? = null,
    val uservisible: Int? = null,
    val accessvisible: Int? = null,
    @SerializedName("time_limit") val timeLimit: String? = null,
    @SerializedName("allowed_attempts") val allowedAttempts: String? = null,
    @SerializedName("open_time_text") val openTimeText: String? = null,
    @SerializedName("close_time_text") val closeTimeText: String? = null,
    @SerializedName("details_loaded") val detailsLoaded: Boolean = false,
    @SerializedName("details_parser_version") val detailsParserVersion: Int = 0,
    @SerializedName("details_error") val detailsError: String? = null,
    @SerializedName("grade_score") val gradeScore: String? = null,
    @SerializedName("grade_max") val gradeMax: String? = null,
    @SerializedName("grade_percent") val gradePercent: String? = null,
    /** True only when mod_quiz_get_user_best_grade explicitly confirms a visible grade. */
    @SerializedName("has_api_best_grade") val hasApiBestGrade: Boolean? = null,
    /** True only after a successful Moodle history read explicitly confirms no attempt rows. */
    @SerializedName("has_confirmed_no_attempts") val hasConfirmedNoAttempts: Boolean? = null,
    /** Per-user capabilities returned by mod_quiz_get_quiz_access_information. */
    @SerializedName("access_info_loaded") val accessInfoLoaded: Boolean = false,
    @SerializedName("can_attempt") val canAttempt: Boolean? = null,
    @SerializedName("can_review_my_attempts") val canReviewMyAttempts: Boolean? = null,
    @SerializedName("quiz_access_reasons") val quizAccessReasons: List<String> = emptyList()
)

data class MoodleGradeItem(
    val id: Int,
    @SerializedName("account_id") val accountId: String? = null,
    @SerializedName("course_id") val courseId: String,
    val name: String,
    val score: String? = null,
    @SerializedName("max_score") val maxScore: String? = null,
    val percent: String? = null
)

data class MoodleGradeSummary(
    val items: Int = 0,
    @SerializedName("graded_items") val gradedItems: Int = 0,
    @SerializedName("earned_points") val earnedPoints: Double = 0.0,
    @SerializedName("max_points") val maxPoints: Double = 0.0,
    @SerializedName("is_final_course_grade") val isFinalCourseGrade: Boolean? = null
)

data class MoodleGradesResponse(
    val data: List<MoodleGradeItem> = emptyList(),
    @SerializedName("summary_by_course") val summaryByCourse: Map<String, MoodleGradeSummary> = emptyMap()
)

data class MoodleQuizAttempt(
    @SerializedName("account_id") val accountId: String? = null,
    @SerializedName("course_id") val courseId: String,
    @SerializedName("attempt_id") val attemptId: String,
    val cmid: String? = null,
    @SerializedName("quiz_name") val quizName: String? = null,
    @SerializedName("attempt_row") val attemptRow: String? = null,
    val status: String? = null,
    @SerializedName("page_title") val pageTitle: String? = null,
    @SerializedName("review_url") val reviewUrl: String? = null,
    val started: String? = null,
    val completed: String? = null,
    val elapsed: String? = null,
    val score: String? = null,
    @SerializedName("max_score") val maxScore: String? = null,
    @SerializedName("question_count") val questionCount: Int? = null,
    @SerializedName("current_page") val currentPage: Int? = null
)


/** Normalizes Moodle 4.5+ mod_quiz attempt state names for the app's progress model. */
fun normalizeMoodleApiAttemptStatus(state: String?): String? = when (state?.trim()?.lowercase()) {
    "inprogress", "overdue" -> "В процессе"
    "not_started", "notstarted" -> "Не начата"
    "finished", "submitted", "abandoned", "completed" -> "Завершена"
    else -> state?.trim()?.takeIf { it.isNotBlank() }
}

/** Sort by the visible Moodle attempt number when no review link exposes an internal ID. */
fun moodleAttemptSortOrder(attempt: MoodleQuizAttempt): Long {
    val visibleNumber = Regex("(?iu)(?:попытка|attempt)?\\s*#?\\s*(\\d+)")
        .find(attempt.attemptRow.orEmpty())?.groupValues?.getOrNull(1)?.toLongOrNull()
    val syntheticNumber = attempt.attemptId.removePrefix("row:").toLongOrNull()
    return visibleNumber ?: syntheticNumber ?: attempt.attemptId.toLongOrNull() ?: 0L
}

/** Merge fresh Moodle attempt rows with cached details without dropping fields Moodle did not return this time. */
fun mergeMoodleQuizAttempts(
    primary: List<MoodleQuizAttempt>,
    fallback: List<MoodleQuizAttempt>
): List<MoodleQuizAttempt> {
    fun sameQuiz(a: MoodleQuizAttempt, b: MoodleQuizAttempt): Boolean =
        (a.cmid != null && b.cmid != null && a.cmid == b.cmid) ||
            (a.cmid.isNullOrBlank() && b.cmid.isNullOrBlank() && a.quizName == b.quizName)

    fun sameAttempt(a: MoodleQuizAttempt, b: MoodleQuizAttempt): Boolean {
        if (!sameQuiz(a, b)) return false
        if (a.attemptId == b.attemptId) return true
        val aNumber = a.attemptRow?.trim()?.takeIf { it.isNotBlank() }
        val bNumber = b.attemptRow?.trim()?.takeIf { it.isNotBlank() }
        if (aNumber != null && bNumber != null && aNumber == bNumber) return true
        val aCompleted = a.completed?.trim()?.takeIf { it.isNotBlank() }
        val bCompleted = b.completed?.trim()?.takeIf { it.isNotBlank() }
        if (aCompleted != null && bCompleted != null && aCompleted == bCompleted) return true
        val aStarted = a.started?.trim()?.takeIf { it.isNotBlank() }
        val bStarted = b.started?.trim()?.takeIf { it.isNotBlank() }
        return aStarted != null && bStarted != null && aStarted == bStarted
    }

    val unusedFallback = fallback.toMutableList()
    val merged = primary.map { current ->
        val exactMatch = unusedFallback.indexOfFirst { sameAttempt(current, it) }
        val onlyPossibleMatch = if (exactMatch < 0) {
            val candidates = unusedFallback.indices.filter { sameQuiz(current, unusedFallback[it]) }
            candidates.singleOrNull() ?: -1
        } else -1
        val matchIndex = if (exactMatch >= 0) exactMatch else onlyPossibleMatch
        val previous = if (matchIndex >= 0) unusedFallback.removeAt(matchIndex) else null
        if (previous == null) return@map current
        current.copy(
            quizName = current.quizName ?: previous.quizName,
            attemptRow = current.attemptRow ?: previous.attemptRow,
            status = current.status ?: previous.status,
            pageTitle = current.pageTitle ?: previous.pageTitle,
            reviewUrl = current.reviewUrl ?: previous.reviewUrl,
            started = current.started ?: previous.started,
            completed = current.completed ?: previous.completed,
            elapsed = cleanMoodleElapsed(current.elapsed)
                ?: cleanMoodleElapsed(previous.elapsed)
                ?: deriveMoodleElapsed(current.started ?: previous.started, current.completed ?: previous.completed),
            score = current.score ?: previous.score,
            maxScore = current.maxScore ?: previous.maxScore,
            questionCount = current.questionCount ?: previous.questionCount,
            currentPage = current.currentPage ?: previous.currentPage
        )
    }
    return (merged + unusedFallback).distinctBy { attempt ->
        // Preserve separate attempts when only a quiz has no review/attempt links. Timestamp
        // and visible attempt number are safer identity fields than the generated row index.
        val number = attempt.attemptRow?.trim()?.takeIf { it.isNotBlank() }
        val timestamp = attempt.completed?.trim()?.takeIf { it.isNotBlank() }
            ?: attempt.started?.trim()?.takeIf { it.isNotBlank() }
        val identity = number ?: timestamp ?: attempt.attemptId
        "${attempt.cmid ?: attempt.quizName.orEmpty()}:$identity"
    }.sortedByDescending(::moodleAttemptSortOrder)
}

/** Rejects Moodle table labels such as "Просмотр" when a theme changes cell order. */
fun cleanMoodleElapsed(raw: String?): String? {
    val value = raw?.replace(Regex("\\s+"), " ")?.trim()?.trimEnd('.', ';', ':') ?: return null
    if (value.isBlank() || value.contains("просмотр", true) || value.contains("review", true) ||
        value.contains("не доступ", true) || value.equals("-", true)) return null
    // Do not put a Unicode word-boundary after Cyrillic units: Java's default
    // boundary handling can reject values such as "15 мин." on Android.
    val match = Regex(
        "(?iu)(?:\\b\\d+\\s*(?:дн(?:я|ей)?|сут(?:ки|ок)?|час(?:а|ов)?|ч|мин(?:ута|уты|ут)?|сек(?:унда|унды|унд)?|days?|hours?|mins?|minutes?|secs?|seconds?)(?=\\s|$|[.,;])|\\b\\d{1,3}:\\d{2}(?::\\d{2})?\\b)"
    ).find(value) ?: return null
    return value.substring(match.range.first).trim()
}

/** Derive a reliable duration from Moodle's localized start and submission timestamps. */
fun deriveMoodleElapsed(started: String?, completed: String?): String? {
    val start = parseMoodleLocalDateTime(started) ?: return null
    val end = parseMoodleLocalDateTime(completed) ?: return null
    val seconds = java.time.Duration.between(start, end).seconds
    if (seconds < 0) return null
    val minutes = seconds / 60
    val remainingSeconds = seconds % 60
    val hours = minutes / 60
    val remainingMinutes = minutes % 60
    return when {
        hours > 0 -> if (remainingMinutes > 0) "$hours ч $remainingMinutes мин" else "$hours ч"
        minutes > 0 -> "$minutes мин"
        else -> "$remainingSeconds сек"
    }
}

/** Returns true when a quiz is outside its explicitly configured Moodle opening window. */
fun isMoodleDateWindowClosed(
    openText: String?,
    closeText: String?,
    now: java.time.LocalDateTime = java.time.LocalDateTime.now()
): Boolean {
    val opensAt = parseMoodleLocalDateTime(openText)
    val closesAt = parseMoodleLocalDateTime(closeText)
    return (opensAt != null && now.isBefore(opensAt)) ||
        (closesAt != null && !now.isBefore(closesAt))
}

private fun parseMoodleLocalDateTime(raw: String?): java.time.LocalDateTime? =
    MoodleDateTimeParser.parseLocalDateTime(raw)

/** Derives an attempt's submission timestamp only from its recorded start and elapsed duration. */
fun deriveMoodleCompletedTime(started: String?, elapsed: String?): String? {
    val start = MoodleDateTimeParser.parseLocalDateTime(started) ?: return null
    val seconds = parseMoodleDurationSeconds(elapsed) ?: return null
    if (seconds < 0L || seconds > 7L * 24L * 60L * 60L) return null
    return start.plusSeconds(seconds).format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"))
}

/**
 * Estimates a completed quiz attempt only when Moodle did not provide its submission time.
 * The actual elapsed duration wins; if it is absent, the duration between recorded timestamps
 * wins; the configured quiz limit is the final fallback. The caller supplies the recorded
 * attempt start when available and may explicitly supply the quiz opening time as a last resort.
 */
fun deriveMoodleAttemptCompletedTime(
    started: String?,
    actualElapsed: String?,
    recordedCompleted: String?,
    configuredTimeLimit: String?
): String? {
    val duration = cleanMoodleElapsed(actualElapsed)
        ?: deriveMoodleElapsed(started, recordedCompleted)
        ?: cleanMoodleElapsed(configuredTimeLimit)
    return deriveMoodleCompletedTime(started, duration)
}

private fun parseMoodleDurationSeconds(raw: String?): Long? {
    val value = raw?.trim()?.replace(Regex("\\s+"), " ")?.takeIf { it.isNotBlank() } ?: return null
    runCatching { java.time.Duration.parse(value).seconds }.getOrNull()?.let { return it }

    Regex("(?iu)(?<!\\d)(\\d{1,3}):(\\d{2})(?::(\\d{2}))?(?!\\d)").find(value)?.let { match ->
        val first = match.groupValues[1].toLongOrNull() ?: return null
        val second = match.groupValues[2].toLongOrNull() ?: return null
        val third = match.groupValues[3].toLongOrNull()
        return if (third != null) first * 3600L + second * 60L + third else first * 60L + second
    }

    val unitPattern = Regex("(?iu)(\\d+)\\s*(дн(?:я|ей)?|день|сут(?:ки|ок)?|days?|d|час(?:а|ов)?|час|hours?|hrs?|hr|h|ч|мин(?:ута|уты|ут)?[.]?|minutes?|mins?|min|м|сек(?:унда|унды|унд)?[.]?|seconds?|secs?|sec|с)")
    var seconds = 0L
    var found = false
    unitPattern.findAll(value).forEach { match ->
        val amount = match.groupValues[1].toLongOrNull() ?: return@forEach
        val unit = match.groupValues[2].lowercase(java.util.Locale.ROOT).trimEnd('.')
        val multiplier = when {
            unit.startsWith("дн") || unit.startsWith("день") || unit.startsWith("сут") || unit == "d" || unit.startsWith("day") -> 86400L
            unit.startsWith("час") || unit.startsWith("ч") || unit == "h" || unit.startsWith("hr") || unit.startsWith("hour") -> 3600L
            unit.startsWith("мин") || unit == "м" || unit == "m" || unit.startsWith("min") -> 60L
            unit.startsWith("сек") || unit == "с" || unit == "s" || unit.startsWith("sec") -> 1L
            else -> return@forEach
        }
        seconds += amount * multiplier
        found = true
    }
    return seconds.takeIf { found }
}


data class MoodleAttemptDetail(
    @SerializedName("account_id") val accountId: String? = null,
    @SerializedName("course_id") val courseId: String,
    @SerializedName("attempt_id") val attemptId: String,
    val cmid: String? = null,
    @SerializedName("quiz_name") val quizName: String? = null,
    @SerializedName("attempt_row") val attemptRow: String? = null,
    @SerializedName("page_title") val pageTitle: String? = null,
    @SerializedName("review_url") val reviewUrl: String? = null,
    val started: String? = null,
    val completed: String? = null,
    val elapsed: String? = null,
    val score: String? = null,
    @SerializedName("question_count") val questionCount: Int? = null,
    val questions: List<MoodleQuestion> = emptyList()
)

data class MoodleQuestion(
    val id: Int,
    @SerializedName("account_id") val accountId: String? = null,
    @SerializedName("course_id") val courseId: String,
    @SerializedName("attempt_id") val attemptId: String,
    val idx: Int? = null,
    @SerializedName("question_id") val questionId: String? = null,
    val slot: Int? = null,
    @SerializedName("question_type") val questionType: String? = null,
    val state: String? = null,
    val grade: String? = null,
    @SerializedName("prompt_text") val promptText: String? = null,
    @SerializedName("prompt_html") val promptHtml: String? = null,
    @SerializedName("response_text") val responseText: String? = null,
    @SerializedName("response_html") val responseHtml: String? = null,
    @SerializedName("right_answer_text") val rightAnswerText: String? = null,
    @SerializedName("right_answer_html") val rightAnswerHtml: String? = null,
    @SerializedName("specific_feedback_text") val specificFeedbackText: String? = null,
    @SerializedName("specific_feedback_html") val specificFeedbackHtml: String? = null,
    @SerializedName("general_feedback_text") val generalFeedbackText: String? = null,
    @SerializedName("general_feedback_html") val generalFeedbackHtml: String? = null,
    @SerializedName("outcome_text") val outcomeText: String? = null,
    @SerializedName("outcome_html") val outcomeHtml: String? = null,
    @SerializedName("answer_values") val answerValues: List<MoodleAnswerValue> = emptyList(),
    @SerializedName("math_expressions") val mathExpressions: List<MoodleMathExpression> = emptyList()
)

data class MoodleAnswerValue(
    val field: String? = null,
    @SerializedName("row") val rowIndex: Int? = null,
    @SerializedName("column") val columnIndex: Int? = null,
    val value: String? = null
)

data class MoodleMathExpression(
    val format: String? = null,
    val source: String? = null
)

data class MoodleCalendarEvent(
    @SerializedName("account_id") val accountId: String? = null,
    @SerializedName("event_id") val eventId: String,
    @SerializedName("course_id") val courseId: String? = null,
    val name: String,
    val eventtype: String? = null,
    val timestart: Long? = null,
    @SerializedName("formattedtime") val formattedTime: String? = null,
    val description: String? = null,
    @SerializedName("timeduration") val timeDuration: Long? = null,
    @SerializedName("action_name") val actionName: String? = null,
    @SerializedName("action_item_type") val actionItemType: String? = null,
    val actionable: Boolean? = null,
    val overdue: Boolean? = null,
    val url: String? = null,
    @SerializedName("activity_url") val activityUrl: String? = null
)

data class MoodleSearchResponse(
    val query: String? = null,
    val modules: List<MoodleSearchModule> = emptyList(),
    val grades: List<MoodleSearchGrade> = emptyList()
)

data class MoodleSearchModule(
    @SerializedName("course_id") val courseId: String,
    @SerializedName("course_name") val courseName: String? = null,
    val cmid: String,
    val name: String,
    /** Canonical Moodle module component, e.g. resource, quiz, url. */
    val type: String? = null,
    val modname: String? = null,
    @SerializedName("section_id") val sectionId: String? = null,
    @SerializedName("section_number") val sectionNumber: Int? = null,
    val url: String? = null,
    val visible: Int? = null,
    val uservisible: Int? = null,
    val accessvisible: Int? = null,
    @SerializedName("details_url") val detailsUrl: String? = null,
    @SerializedName("file_links_json") val fileLinksJson: String? = null
)

data class MoodleSearchGrade(
    @SerializedName("course_id") val courseId: String,
    val name: String,
    val score: String? = null,
    @SerializedName("max_score") val maxScore: String? = null,
    val percent: String? = null
)

data class MoodleCourseSnapshot(
    val course: MoodleCourse,
    val sections: List<MoodleSection>,
    val modules: List<MoodleModule>,
    val quizzes: List<MoodleQuiz>,
    val grades: MoodleGradesResponse,
    val attempts: List<MoodleQuizAttempt>,
    val calendar: List<MoodleCalendarEvent>,
    /** True only after a complete attempt-history request returned successfully. */
    val attemptsLoaded: Boolean = false
)
