package ru.tusur.study

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import java.io.File
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.widget.Toast
import ru.tusur.moodle.data.normalizeMoodleFileName

/** Download a Moodle resource directly into the public Downloads folder without opening its HTML wrapper. */
fun downloadMoodleResource(context: Context, rawUrl: String, userAgent: String? = null, contentDisposition: String? = null, mimeType: String? = null) {
    try {
        val uri = Uri.parse(rawUrl)
        require(uri.scheme.equals("https", true) && uri.host.equals(MOODLE_HOST, true)) {
            "Разрешены загрузки только с Moodle"
        }
        val filename = normalizeMoodleFileName(URLUtil.guessFileName(rawUrl, contentDisposition, mimeType))
        val destinationName = uniqueDownloadName(context, filename)
        val request = DownloadManager.Request(uri).apply {
            setTitle(filename)
            setDescription("Загрузка учебного файла")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, destinationName)
            userAgent?.takeIf(String::isNotBlank)?.let { addRequestHeader("User-Agent", it) }
            CookieManager.getInstance().getCookie(rawUrl)?.takeIf(String::isNotBlank)?.let {
                addRequestHeader("Cookie", it)
            }
        }
        val manager = context.getSystemService(DownloadManager::class.java)
            ?: error("Сервис загрузок Android недоступен")
        manager.enqueue(request)
        Toast.makeText(context, "Файл загружается в Downloads: $filename", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Не удалось начать загрузку: ${e.localizedMessage ?: "ошибка"}", Toast.LENGTH_LONG).show()
    }
}

private fun uniqueDownloadName(context: Context, name: String): String {
    val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    if (!File(downloads, name).exists()) return name
    val base = name.substringBeforeLast('.', name)
    val extension = name.substringAfterLast('.', "").takeIf { it.isNotBlank() }?.let { ".$it" }.orEmpty()
    var index = 2
    while (File(downloads, "$base ($index)$extension").exists()) index++
    return "$base ($index)$extension"
}
