package ru.tusur.moodle.data

import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Parses the localized date/time strings returned by Moodle pages and attempt tables.
 * Russian month names are often abbreviated in narrow tables ("нояб."), and themes may
 * insert non-breaking or narrow spaces, so normalize those before matching.
 */
object MoodleDateTimeParser {
    private const val WEEKDAY = "(?:понедельник|вторник|среда|четверг|пятница|суббота|воскресенье|пн|вт|ср|чт|пт|сб|вс|monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)"
    private const val RU_MONTH = "(?:января|янв\\.?|февраля|февр?\\.?|марта|мар\\.?|апреля|апр\\.?|мая|июня|июн\\.?|июля|июл\\.?|августа|авг\\.?|сентября|сент\\.?|октября|окт\\.?|ноября|нояб\\.?|декабря|дек\\.?)"
    private const val EN_MONTH = "(?:january|jan\\.?|february|febr?\\.?|march|mar\\.?|april|apr\\.?|may|june|jun\\.?|july|jul\\.?|august|aug\\.?|september|sept?\\.?|october|oct\\.?|november|nov\\.?|december|dec\\.?)"

    private val isoDateTime = Regex(
        "(?iu)\\d{4}-\\d{2}-\\d{2}[T ]\\d{1,2}:\\d{2}(?::\\d{2})?(?:Z|[+-]\\d{2}:?\\d{2})?"
    )
    private val dayFirstDateTime = Regex(
        "(?iu)(?:(?:$WEEKDAY)\\.?\\s*,?\\s*)?\\d{1,2}\\s+(?:$RU_MONTH|$EN_MONTH)\\s+\\d{4}(?:\\s*г\\.?)?(?:\\s*(?:,\\s*|\\s+в\\s+|\\s+at\\s+|\\s+)?\\d{1,2}:\\d{2}(?::\\d{2})?(?:\\s*(?:am|pm))?)?"
    )
    private val monthFirstDateTime = Regex(
        "(?iu)(?:(?:$WEEKDAY)\\.?\\s*,?\\s*)?(?:$EN_MONTH)\\s+\\d{1,2},?\\s+\\d{4}(?:\\s*,?\\s*\\d{1,2}:\\d{2}(?::\\d{2})?(?:\\s*(?:am|pm))?)?"
    )
    private val numericDateTime = Regex(
        "(?iu)\\d{1,2}[./]\\d{1,2}[./]\\d{4}(?:\\s*(?:,\\s*|\\s+в\\s+|\\s+)?\\d{1,2}:\\d{2}(?::\\d{2})?)?"
    )

    private val monthNumbers = mapOf(
        "января" to 1, "янв" to 1,
        "февраля" to 2, "февр" to 2, "фев" to 2,
        "марта" to 3, "мар" to 3,
        "апреля" to 4, "апр" to 4,
        "мая" to 5,
        "июня" to 6, "июн" to 6,
        "июля" to 7, "июл" to 7,
        "августа" to 8, "авг" to 8,
        "сентября" to 9, "сент" to 9, "сен" to 9,
        "октября" to 10, "окт" to 10,
        "ноября" to 11, "нояб" to 11, "ноя" to 11,
        "декабря" to 12, "дек" to 12,
        "january" to 1, "jan" to 1,
        "february" to 2, "feb" to 2, "febr" to 2,
        "march" to 3, "mar" to 3,
        "april" to 4, "apr" to 4,
        "may" to 5,
        "june" to 6, "jun" to 6,
        "july" to 7, "jul" to 7,
        "august" to 8, "aug" to 8,
        "september" to 9, "sept" to 9, "sep" to 9,
        "october" to 10, "oct" to 10,
        "november" to 11, "nov" to 11,
        "december" to 12, "dec" to 12
    )

    /** Returns the first recognizable Moodle date/time in [raw], preserving its display form. */
    fun extract(raw: String?): String? {
        val value = normalize(raw) ?: return null
        return listOf(isoDateTime, dayFirstDateTime, monthFirstDateTime, numericDateTime)
            .firstNotNullOfOrNull { pattern -> pattern.find(value)?.value?.trim()?.takeIf(String::isNotEmpty) }
    }

    /** Extracts the submitted-at timestamp from Moodle's localized attempt status cell. */
    fun extractSubmittedTimestamp(statusText: String?, rowCells: List<String>): String? {
        val status = statusText.orEmpty()
        val isFinished = Regex("(?iu)(?:заверш|отправлено|finished|submitted|completed)").containsMatchIn(status)
        if (!isFinished) return null
        return extract(status) ?: rowCells.asSequence().mapNotNull(::extract).distinct().lastOrNull()
    }

    /** Converts a recognized Moodle timestamp into local wall-clock time without changing its displayed zone. */
    fun parseLocalDateTime(raw: String?): LocalDateTime? {
        val value = extract(raw)?.trim() ?: return null

        isoDateTime.find(value)?.value?.let { iso ->
            runCatching { return LocalDateTime.parse(iso, DateTimeFormatter.ISO_LOCAL_DATE_TIME) }
            runCatching { return OffsetDateTime.parse(iso, DateTimeFormatter.ISO_OFFSET_DATE_TIME).atZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime() }
            runCatching { return java.time.Instant.parse(iso).atZone(ZoneId.systemDefault()).toLocalDateTime() }
        }

        val withoutWeekday = value.replaceFirst(
            Regex("(?iu)^(?:$WEEKDAY)\\.?\\s*,?\\s*"), ""
        ).trim()

        Regex("(?iu)^(\\d{1,2})\\s+([\\p{L}]+\\.?)\\s+(\\d{4})(?:\\s*г\\.?)?\\s*(?:,\\s*|в\\s+|at\\s+|\\s+)?(\\d{1,2}):(\\d{2})(?::(\\d{2}))?(?:\\s*(am|pm))?$")
            .find(withoutWeekday)?.let { match ->
                val day = match.groupValues[1].toIntOrNull() ?: return null
                val month = monthNumbers[match.groupValues[2].lowercase(Locale.ROOT).trimEnd('.')] ?: return null
                val year = match.groupValues[3].toIntOrNull() ?: return null
                var hour = match.groupValues[4].toIntOrNull() ?: return null
                val minute = match.groupValues[5].toIntOrNull() ?: return null
                val second = match.groupValues[6].toIntOrNull() ?: 0
                when (match.groupValues[7].lowercase(Locale.ROOT)) {
                    "am" -> if (hour == 12) hour = 0
                    "pm" -> if (hour in 1..11) hour += 12
                }
                return runCatching { LocalDateTime.of(year, month, day, hour, minute, second) }.getOrNull()
            }

        Regex("(?iu)^([a-z]+\\.?)\\s+(\\d{1,2}),?\\s+(\\d{4})\\s*,?\\s*(\\d{1,2}):(\\d{2})(?::(\\d{2}))?(?:\\s*(am|pm))?$")
            .find(withoutWeekday)?.let { match ->
                val month = monthNumbers[match.groupValues[1].lowercase(Locale.ROOT).trimEnd('.')] ?: return null
                val day = match.groupValues[2].toIntOrNull() ?: return null
                val year = match.groupValues[3].toIntOrNull() ?: return null
                var hour = match.groupValues[4].toIntOrNull() ?: return null
                val minute = match.groupValues[5].toIntOrNull() ?: return null
                val second = match.groupValues[6].toIntOrNull() ?: 0
                when (match.groupValues[7].lowercase(Locale.ROOT)) {
                    "am" -> if (hour == 12) hour = 0
                    "pm" -> if (hour in 1..11) hour += 12
                }
                return runCatching { LocalDateTime.of(year, month, day, hour, minute, second) }.getOrNull()
            }

        Regex("(?iu)^(\\d{1,2})[./](\\d{1,2})[./](\\d{4})\\s+(\\d{1,2}):(\\d{2})(?::(\\d{2}))?$")
            .find(withoutWeekday)?.let { match ->
                val day = match.groupValues[1].toIntOrNull() ?: return null
                val month = match.groupValues[2].toIntOrNull() ?: return null
                val year = match.groupValues[3].toIntOrNull() ?: return null
                val hour = match.groupValues[4].toIntOrNull() ?: return null
                val minute = match.groupValues[5].toIntOrNull() ?: return null
                val second = match.groupValues[6].toIntOrNull() ?: 0
                return runCatching { LocalDateTime.of(year, month, day, hour, minute, second) }.getOrNull()
            }
        return null
    }

    private fun normalize(raw: String?): String? = raw
        ?.replace(Regex("[\\u00A0\\u1680\\u2000-\\u200A\\u202F\\u205F\\u3000]"), " ")
        ?.replace(Regex("[\\u200B-\\u200F\\uFEFF]"), "")
        ?.replace(Regex("[\\t ]+"), " ")
        ?.replace(Regex("\\s+"), " ")
        ?.trim()
        ?.takeIf { it.isNotEmpty() }
}
