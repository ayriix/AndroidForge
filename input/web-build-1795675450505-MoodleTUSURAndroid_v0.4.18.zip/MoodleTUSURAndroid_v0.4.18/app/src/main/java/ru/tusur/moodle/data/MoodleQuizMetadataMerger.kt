package ru.tusur.moodle.data

/**
 * Preserves quiz settings while Moodle refreshes the course state.
 * Moodle's course-format response can omit the activity id or rich quiz fields on a later
 * request, so matching by cmid alone is not sufficient.
 */
object MoodleQuizMetadataMerger {
    fun merge(oldQuizzes: List<MoodleQuiz>, freshQuizzes: List<MoodleQuiz>): List<MoodleQuiz> {
        if (freshQuizzes.isEmpty()) return oldQuizzes
        if (oldQuizzes.isEmpty()) return freshQuizzes

        val oldByCmid = oldQuizzes.mapNotNull { quiz ->
            quiz.cmid?.takeIf { it.isNotBlank() }?.let { it to quiz }
        }.toMap()
        val oldByUrlId = oldQuizzes.mapNotNull { quiz ->
            extractModuleId(quiz.url)?.let { it to quiz }
        }.toMap()
        val oldByName = oldQuizzes
            .groupBy { normalizeMoodleDisplayName(it.quizName).lowercase() }
            .filterKeys { it.isNotBlank() }

        return freshQuizzes.map { fresh ->
            val freshId = fresh.cmid?.takeIf { it.isNotBlank() }
            val freshUrlId = extractModuleId(fresh.url)
            val nameKey = normalizeMoodleDisplayName(fresh.quizName).lowercase()
            val previous = freshId?.let(oldByCmid::get)
                ?: freshUrlId?.let(oldByUrlId::get)
                ?: oldByName[nameKey]?.singleOrNull()
            if (previous == null) fresh else mergeOne(previous, fresh)
        }
    }

    private fun mergeOne(old: MoodleQuiz, fresh: MoodleQuiz): MoodleQuiz {
        val oldIsCurrent = old.detailsParserVersion >= MoodleQuizPageSettingsParser.VERSION
        val freshIsCurrent = fresh.detailsParserVersion >= MoodleQuizPageSettingsParser.VERSION
        // A fresh result from the current parser is authoritative even when it is incomplete.
        // Do not let an older cached `detailsLoaded=true` suppress the next HTML/API retry.
        val detailsLoaded = when {
            freshIsCurrent -> fresh.detailsLoaded
            oldIsCurrent -> old.detailsLoaded
            else -> fresh.detailsLoaded || old.detailsLoaded
        }
        // Technical parser/network diagnostics are intentionally not persisted into quiz cards.
        // Missing values remain null and the UI renders them as an em dash.
        return fresh.copy(
            quizId = fresh.quizId ?: old.quizId,
            completedReviewLinks = fresh.completedReviewLinks ?: old.completedReviewLinks,
            hasAttemptHistory = fresh.hasAttemptHistory ?: old.hasAttemptHistory,
            hasInProgressAttempt = fresh.hasInProgressAttempt ?: old.hasInProgressAttempt,
            reviewDeniedTextPresent = fresh.reviewDeniedTextPresent ?: old.reviewDeniedTextPresent,
            timeLimit = useful(fresh.timeLimit) ?: old.timeLimit,
            allowedAttempts = useful(fresh.allowedAttempts) ?: old.allowedAttempts,
            openTimeText = useful(fresh.openTimeText) ?: old.openTimeText,
            closeTimeText = useful(fresh.closeTimeText) ?: old.closeTimeText,
            detailsLoaded = detailsLoaded,
            detailsParserVersion = maxOf(fresh.detailsParserVersion, old.detailsParserVersion),
            detailsError = null,
            // A false hasgrade means the API did not expose a current best grade; it does not
            // prove that no submitted attempt exists. Keep cached values for offline recovery,
            // while the UI must gate their display on current positive evidence or a visible
            // score parsed from a Moodle attempt row.
            gradeScore = fresh.gradeScore ?: old.gradeScore,
            gradeMax = fresh.gradeMax ?: old.gradeMax,
            gradePercent = fresh.gradePercent ?: old.gradePercent,
            hasApiBestGrade = fresh.hasApiBestGrade ?: old.hasApiBestGrade,
            hasConfirmedNoAttempts = fresh.hasConfirmedNoAttempts ?: old.hasConfirmedNoAttempts
        )
    }

    private fun useful(value: String?): String? {
        val normalized = value?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        val lower = normalized.lowercase()
        return normalized.takeUnless {
            lower in setOf("—", "-", "не указано", "не указана", "не удалось получить данные") ||
                lower.startsWith("не удалось получить")
        }
    }

    private fun extractModuleId(url: String?): String? = url?.let {
        Regex("[?&]id=(\\d+)(?:&|$)").find(it)?.groupValues?.getOrNull(1)
    }
}
