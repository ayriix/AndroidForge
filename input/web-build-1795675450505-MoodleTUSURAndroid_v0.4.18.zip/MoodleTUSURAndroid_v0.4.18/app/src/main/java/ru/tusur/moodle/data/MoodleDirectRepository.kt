package ru.tusur.moodle.data

import android.text.Html
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import ru.tusur.study.MoodleBrowserSession
import java.net.URLEncoder
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

private const val QUIZ_DETAILS_PARSER_VERSION = MoodleQuizPageSettingsParser.VERSION

private const val MOODLE_PAGE_USER_AGENT =
    "Mozilla/5.0 (Linux; Android 15; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

/**
 * Direct Android-to-Moodle client. It uses the encrypted native login session (cookies + sesskey)
 * for Moodle's same-origin AJAX/pages and, when enabled on the account, the official
 * moodle_mobile_app Web Service token for quiz metadata and attempt operations.
 */
class MoodleDirectRepository(private val session: MoodleBrowserSession) {
    private val gson = Gson()
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .callTimeout(90, TimeUnit.SECONDS)
        // Never let a manually supplied Moodle Cookie header follow a redirect to another host.
        .followRedirects(false)
        .followSslRedirects(false)
        .retryOnConnectionFailure(true)
        .build()

    private data class AjaxCall(val index: Int, val methodname: String, val args: JsonObject)

    fun getCourses(): List<MoodleCourse> {
        val result = mutableListOf<MoodleCourse>()
        var offset = 0
        repeat(20) {
            val args = JsonObject().apply {
                addProperty("classification", "all")
                addProperty("limit", 100)
                addProperty("offset", offset)
                addProperty("sort", "fullname")
            }
            val data = call("core_course_get_enrolled_courses_by_timeline_classification", args)
            val courses = data.asJsonObject.getAsJsonArray("courses") ?: JsonArray()
            courses.forEach { item ->
                val obj = item.asJsonObject
                val id = obj.get("id")?.asString ?: return@forEach
                result += MoodleCourse(
                    courseId = id,
                    site = session.baseUrl,
                    name = obj.get("fullname")?.asString?.takeIf(String::isNotBlank) ?: "Курс $id",
                    shortname = obj.get("shortname")?.asString,
                    url = "${session.baseUrl}course/view.php?id=$id",
                    source = "moodle_session_ajax"
                )
            }
            val next = data.asJsonObject.get("nextoffset")?.takeIf { it.isJsonPrimitive }?.asInt
            if (courses.size() == 0 || next == null || next <= offset) return result.distinctBy { it.courseId }
            offset = next
        }
        return result.distinctBy { it.courseId }
    }

    fun loadCourseSnapshot(
        course: MoodleCourse,
        cachedSnapshot: MoodleCourseSnapshot? = null,
        forceRefreshCards: Boolean = false
    ): MoodleCourseSnapshot {
        // Prime Moodle course context in the same way as the successful browser collector.
        getPage(course.url ?: "${session.baseUrl}course/view.php?id=${course.courseId}")
        val stateArgs = JsonObject().apply { addProperty("courseid", course.courseId.toInt()) }
        val rawState = call("core_courseformat_get_state", stateArgs)
        val state = if (rawState.isJsonPrimitive && rawState.asJsonPrimitive.isString) {
            runCatching { JsonParser.parseString(rawState.asString) }.getOrElse { JsonObject() }
        } else rawState
        val root = state.takeIf { it.isJsonObject }?.asJsonObject ?: JsonObject()
        val rawSections = root.getAsJsonArray("section") ?: JsonArray()
        val rawModules = root.getAsJsonArray("cm") ?: JsonArray()

        val sections = rawSections.mapNotNull { el ->
            if (!el.isJsonObject) return@mapNotNull null
            val s = el.asJsonObject
            val id = s.string("id") ?: return@mapNotNull null
            MoodleSection(
                courseId = course.courseId,
                sectionId = id,
                number = s.int("number"),
                name = s.string("title"),
                visible = s.intOrBool("visible"),
                hasRestrictions = s.intOrBool("hasrestrictions"),
                collapsed = if (s.bool("contentcollapsed")) 1 else 0,
                url = s.string("sectionurl"),
                courseName = course.name,
                moduleCount = s.getAsJsonArray("cmlist")?.size()
            )
        }

        val moduleSeeds = rawModules.mapNotNull { el ->
            if (!el.isJsonObject) return@mapNotNull null
            val m = el.asJsonObject
            val id = m.string("id") ?: return@mapNotNull null
            ModuleSeed(
                id = id,
                sectionId = m.string("sectionid"),
                sectionNumber = m.int("sectionnumber"),
                name = m.string("name") ?: "Материал $id",
                // Moodle exposes a canonical module component (e.g. "quiz") and a
                // localized label (e.g. "Тест"). Keep them separate: filters must use
                // the canonical component, while the UI may show the localized label.
                module = m.string("module"),
                displayName = m.string("modname"),
                visible = m.intOrBool("visible"),
                userVisible = m.intOrBool("uservisible"),
                accessVisible = m.intOrBool("accessvisible"),
                restrictions = m.intOrBool("hascmrestrictions"),
                completion = m.int("completionstate"),
                url = m.string("url")
            )
        }

        // On repeat opens, reuse cached card text and file links. Only new modules need
        // the heavier card-renderer requests. An explicit manual refresh can force them.
        val cachedModules = cachedSnapshot?.modules?.associateBy { it.cmid }.orEmpty()
        val modulesNeedingCards = moduleSeeds.filter { forceRefreshCards || it.id !in cachedModules }
        val cardHtml = mutableMapOf<String, String>()
        modulesNeedingCards.chunked(15).forEach { chunk ->
            val calls = chunk.mapIndexed { index, module ->
                val args = JsonObject().apply { addProperty("id", module.id.toInt()) }
                AjaxCall(index, "core_course_get_module", args)
            }
            val replies = callBatch(calls)
            chunk.forEachIndexed { index, module ->
                val data = replies.getOrNull(index)?.get("data") ?: return@forEachIndexed
                cardHtml[module.id] = if (data.isJsonPrimitive) data.asString else data.toString()
            }
        }

        val modules = moduleSeeds.map { seed ->
            val html = cardHtml[seed.id].orEmpty()
            val previous = cachedModules[seed.id]
            val fileLinksJson = if (html.isNotBlank()) gson.toJson(pluginFileLinks(html))
                else previous?.fileLinksJson ?: "[]"
            val cardText = if (html.isNotBlank()) htmlToText(html)
                else previous?.courseCardText.orEmpty()
            MoodleModule(
                courseId = course.courseId,
                cmid = seed.id,
                sectionId = seed.sectionId,
                sectionNumber = seed.sectionNumber,
                name = seed.name,
                type = seed.module ?: seed.displayName,
                modname = seed.displayName,
                url = seed.url,
                visible = seed.visible,
                uservisible = seed.userVisible,
                accessvisible = seed.accessVisible,
                hasRestrictions = seed.restrictions,
                completionState = seed.completion,
                courseCardText = cardText,
                detailsText = previous?.detailsText,
                detailsUrl = seed.url ?: previous?.detailsUrl,
                fileLinksJson = fileLinksJson,
                courseName = course.name
            )
        }

        val quizzes = moduleSeeds.filter { it.module.equals("quiz", true) }.map { seed ->
            MoodleQuiz(
                courseId = course.courseId,
                cmid = seed.id,
                quizName = seed.name,
                sectionId = seed.sectionId,
                sectionNumber = seed.sectionNumber,
                url = seed.url ?: "${session.baseUrl}mod/quiz/view.php?id=${seed.id}",
                visible = seed.visible,
                status = null,
                uservisible = seed.userVisible,
                accessvisible = seed.accessVisible,
                timeLimit = extractQuizTimeLimit(cardHtml[seed.id].orEmpty()),
                allowedAttempts = extractQuizAttemptsLimit(cardHtml[seed.id].orEmpty()),
                openTimeText = extractQuizDateText(cardHtml[seed.id].orEmpty(), "откры"),
                closeTimeText = extractQuizDateText(cardHtml[seed.id].orEmpty(), "закры")
            )
        }

        val grades = loadGrades(course)
        val calendar = loadCalendar(course.courseId)
        // Do not request every quiz overview page during background sync: opening an activity
        // can register a view/completion event in some Moodle course configurations.
        return MoodleCourseSnapshot(
            course = course.copy(
                sectionCount = sections.size,
                moduleCount = modules.size,
                userVisibleCount = modules.count { it.uservisible == 1 },
                accessVisibleCount = modules.count { it.accessvisible == 1 },
                quizCount = quizzes.size
            ),
            sections = sections,
            modules = modules,
            quizzes = quizzes,
            grades = grades,
            attempts = cachedSnapshot?.attempts.orEmpty(),
            calendar = calendar,
            attemptsLoaded = cachedSnapshot?.attemptsLoaded ?: false
        )
    }

    fun syncAll(
        onProgress: (String) -> Unit = {},
        cachedSnapshot: (MoodleCourse) -> MoodleCourseSnapshot? = { null }
    ): Pair<List<MoodleCourse>, List<MoodleCourseSnapshot>> {
        val courses = getCourses()
        val snapshots = mutableListOf<MoodleCourseSnapshot>()
        courses.forEachIndexed { index, course ->
            onProgress("Обновление ${index + 1}/${courses.size}: ${course.name}")
            // Reuse already downloaded card text and file links. The course state, grades and
            // calendar are refreshed, while old module-card HTML is not fetched again unless
            // the user explicitly requests a full card refresh in the foreground.
            snapshots += loadCourseSnapshot(
                course = course,
                cachedSnapshot = cachedSnapshot(course),
                forceRefreshCards = false
            )
        }
        return courses to snapshots
    }

    private fun loadGrades(course: MoodleCourse): MoodleGradesResponse {
        val url = "${session.baseUrl}grade/report/user/index.php?id=${course.courseId}"
        val html = getPage(url)
        val rows = Regex("(?is)<tr\\b[^>]*>(.*?)</tr>").findAll(html).toList()
        val items = mutableListOf<MoodleGradeItem>()
        var gradeColumn: Int? = null
        var rangeColumn: Int? = null
        var percentColumn: Int? = null

        rows.forEach { match ->
            val cells = Regex("(?is)<t[dh]\\b[^>]*>(.*?)</t[dh]>")
                .findAll(match.groupValues[1]).map { htmlToText(it.groupValues[1]) }.toList()
            if (cells.isEmpty()) return@forEach
            val normalized = cells.map { it.lowercase(Locale.ROOT).replace('ё', 'е').trim() }
            if (normalized.any { it.contains("элемент оценивания") || it == "элемент оценки" }) {
                gradeColumn = normalized.indexOfFirst { it == "оценка" || it.startsWith("оценка ") }.takeIf { it >= 0 }
                rangeColumn = normalized.indexOfFirst { it.startsWith("диапазон") }.takeIf { it >= 0 }
                percentColumn = normalized.indexOfFirst { it.startsWith("процент") }.takeIf { it >= 0 }
                return@forEach
            }
            if (cells.size < 2) return@forEach

            val name = cells.first().trim()
                .replace(Regex("^(?:Тест|Задание|Файл|Ссылка)(?=[А-ЯЁ])"), "")
                .trim()
            val normalizedName = name.lowercase(Locale.ROOT).replace('ё', 'е')
            if (name.length < 2 || normalizedName in setOf("итого", "общий итог", "курс") ||
                normalizedName.contains("элемент оценивания") || normalizedName.contains("рассчитанный вес")) return@forEach

            val gradeText = gradeColumn?.let(cells::getOrNull).orEmpty()
            val rangeText = rangeColumn?.let(cells::getOrNull).orEmpty()
            val percentText = percentColumn?.let(cells::getOrNull).orEmpty()
            val rowText = cells.drop(1).joinToString(" · ")
            val percent = Regex("([0-9]+(?:[,.][0-9]+)?)\\s*%")
                .find(percentText.ifBlank { rowText })?.groupValues?.get(1)?.replace(',', '.')

            val rangeMatch = Regex("(-?[0-9]+(?:[,.][0-9]+)?)\\s*[-–]\\s*(-?[0-9]+(?:[,.][0-9]+)?)")
                .find(rangeText.ifBlank { rowText })
            val fractionMatch = Regex("(-?[0-9]+(?:[,.][0-9]+)?)\\s*(?:/|из)\\s*(-?[0-9]+(?:[,.][0-9]+)?)")
                .find(gradeText.ifBlank { rowText })

            val score = fractionMatch?.groupValues?.get(1)?.replace(',', '.')
                ?: Regex("-?[0-9]+(?:[,.][0-9]+)?")
                    .find(gradeText.takeIf { it.isNotBlank() && it != "-" } ?: "")?.value?.replace(',', '.')
                ?: rangeMatch?.let {
                    val candidate = Regex("-?[0-9]+(?:[,.][0-9]+)?")
                        .find(rowText.substringBefore(it.value))?.value
                    candidate?.replace(',', '.')
                }
            val maxScore = fractionMatch?.groupValues?.get(2)?.replace(',', '.')
                ?: rangeMatch?.groupValues?.get(2)?.replace(',', '.')

            if (score == null && percent == null) return@forEach
            items += MoodleGradeItem(
                id = items.size + 1,
                courseId = course.courseId,
                name = name.take(300),
                score = score,
                maxScore = maxScore,
                percent = percent
            )
        }
        return MoodleGradesResponse(data = items.distinctBy { it.name })
    }

    /**
     * Reads attempts from each quiz overview page. Values are resolved by table headings,
     * not by fixed td positions: Moodle themes and language packs can change column order.
     */
    fun loadQuizAttempts(course: MoodleCourse, quizzes: List<MoodleQuiz>): List<MoodleQuizAttempt> {
        // Prefer the Moodle 4.5+ endpoint because it returns all attempt states, including
        // NOT_STARTED. The legacy endpoint maps SUBMITTED to FINISHED and omits NOT_STARTED;
        // a legacy empty array therefore cannot prove that a test has never been started.
        val apiResult = if (!session.webServiceToken.isNullOrBlank()) {
            runCatching {
                val metadata = loadQuizWebServiceMetadata(course.courseId)
                val expectedCmids = quizzes.mapNotNull(::resolveQuizCmid).toSet()
                if (metadata.isEmpty() || !metadata.keys.containsAll(expectedCmids)) {
                    throw MoodleSessionException("Mobile Web Services вернул неполный список тестов курса.")
                }
                loadQuizAttemptsFromWebService(course, quizzes, metadata)
            }
        } else null

        // Always read the authenticated quiz overview as an independent source as well. This
        // protects against incomplete WS responses, server-side service/version differences,
        // and Moodle themes that expose grade/submission rows even when a WS function omits them.
        val htmlResult = runCatching { loadQuizAttemptsFromOverviewPages(course, quizzes) }
        if (htmlResult.isFailure && apiResult?.isSuccess != true) {
            throw htmlResult.exceptionOrNull() ?: MoodleSessionException("Не удалось загрузить историю попыток Moodle")
        }
        if (apiResult?.isFailure == true && htmlResult.isFailure) {
            throw apiResult.exceptionOrNull() ?: MoodleSessionException("Не удалось получить историю попыток через Web Services Moodle")
        }
        val apiAttempts = apiResult?.getOrNull().orEmpty()
        // An empty API response alone is not enough to say "not started" when the
        // independent Moodle overview page could not be read. Leave attemptsLoaded=false
        // in the ViewModel by failing this refresh; the UI will show a dash/unknown state.
        if (MoodleQuizAttemptSourcePolicy.mustRejectEmptyApiWhenOverviewUnavailable(
                apiAttemptCount = apiAttempts.size,
                overviewReadSuccessfully = htmlResult.isSuccess
            )
        ) {
            throw htmlResult.exceptionOrNull()
                ?: MoodleSessionException("Moodle не подтвердил отсутствие попыток.")
        }
        val htmlAttempts = htmlResult.getOrNull().orEmpty()
        // The page can expose only the overall grade while the API returns the real attempt rows.
        // Do not merge that aggregate grade into an arbitrary attempt when there are several.
        val safeHtmlAttempts = htmlAttempts.filterNot { pageSummary ->
            pageSummary.attemptId.startsWith("summary:") && apiAttempts.any { it.cmid == pageSummary.cmid }
        }

        // Merge by Moodle attempt ID first, then attempt number, then timestamps. The API and
        // overview table can identify the same attempt differently (numeric ID vs row:1).
        return mergeMoodleQuizAttempts(apiAttempts, safeHtmlAttempts)
    }

    private fun resolveQuizCmid(quiz: MoodleQuiz): String? =
        quiz.cmid?.takeIf { it.isNotBlank() }
            ?: Regex("[?&]id=(\\d+)").find(quiz.url.orEmpty())?.groupValues?.get(1)

    private fun loadQuizAttemptsFromOverviewPages(
        course: MoodleCourse,
        quizzes: List<MoodleQuiz>
    ): List<MoodleQuizAttempt> {
        val attempts = mutableListOf<MoodleQuizAttempt>()
        var requestedPages = 0
        var loadedPages = 0
        var unresolvedPages = 0
        var lastPageError: Exception? = null
        quizzes.forEach quizLoop@ { quiz ->
            val cmid = resolveQuizCmid(quiz) ?: run {
                unresolvedPages += 1
                return@quizLoop
            }
            requestedPages += 1
            val page = try {
                val overviewUrl = normalizeMoodlePageUrl("${session.baseUrl.trimEnd('/')}/mod/quiz/view.php?id=$cmid")
                    ?: throw MoodleSessionException("Некорректная ссылка на страницу теста Moodle (ID $cmid)")
                getPage(overviewUrl).also { html ->
                    if (!isQuizOverviewHtml(html, quiz.quizName)) {
                        throw MoodleSessionException("Moodle вернул не страницу теста «${quiz.quizName}».")
                    }
                    loadedPages += 1
                }
            } catch (expired: MoodleSessionExpiredException) {
                throw expired
            } catch (error: Exception) {
                lastPageError = error
                return@quizLoop
            }

            // Read the full overview text separately from htmlToText(), which intentionally
            // truncates long fragments for compact UI metadata. The final grade block can appear
            // below the attempt table and must not be lost on a long quiz page.
            val fullPageText = Html.fromHtml(page, Html.FROM_HTML_MODE_COMPACT).toString()
                .replace('\u00A0', ' ')
                .replace(Regex("[\\t ]+"), " ")
            val summary = MoodleQuizOverviewSummaryParser.parse(fullPageText)
            val parsedRows = MoodleQuizAttemptTableParser.extract(page, ::htmlToText)
            val pageAttempts = parsedRows.map { row ->
                val reviewUrl = row.reviewHref?.let { href ->
                    val candidate = when {
                        href.startsWith("https://", true) -> href
                        href.startsWith("/") -> session.baseUrl.trimEnd('/') + href
                        else -> session.baseUrl + href
                    }
                    val parsed = candidate.toHttpUrlOrNull()
                    candidate.takeIf { parsed != null && parsed.isHttps && parsed.host == "moodle.math.tusur.ru" }
                }
                MoodleQuizAttempt(
                    courseId = course.courseId,
                    attemptId = row.attemptId,
                    cmid = cmid,
                    quizName = quiz.quizName,
                    attemptRow = row.attemptRow,
                    status = row.status,
                    reviewUrl = reviewUrl,
                    started = row.started,
                    completed = row.completed,
                    elapsed = row.elapsed,
                    score = row.score,
                    maxScore = row.maxScore
                )
            }.toMutableList()

            val finishedIndexes = pageAttempts.indices.filter { index ->
                isMoodleFinishedAttempt(pageAttempts[index])
            }
            if (summary.hasFinalGrade && finishedIndexes.size == 1) {
                val index = finishedIndexes.single()
                val existing = pageAttempts[index]
                pageAttempts[index] = existing.copy(
                    completed = existing.completed ?: summary.submittedAt,
                    score = existing.score ?: summary.score,
                    maxScore = existing.maxScore ?: summary.maxScore
                )
            } else if (summary.hasFinalGrade && finishedIndexes.isEmpty() &&
                pageAttempts.none(::isMoodleInProgressAttempt)
            ) {
                // Moodle may hide the attempt table/review links while still showing the final
                // grade summary. This summary is valid evidence of a submitted attempt, but it
                // is not assigned to an existing attempt unless the page identifies exactly one.
                pageAttempts += MoodleQuizAttempt(
                    courseId = course.courseId,
                    attemptId = "summary:$cmid",
                    cmid = cmid,
                    quizName = quiz.quizName,
                    status = "Завершена",
                    completed = summary.submittedAt,
                    score = summary.score,
                    maxScore = summary.maxScore
                )
            }

            val plainPage = fullPageText.lowercase(Locale.ROOT).replace('ё', 'е')
            val hasHistoryTable = Regex("(?is)<table\\b[^>]*(?:quizattemptsummary|generaltable)").containsMatchIn(page) &&
                Regex("(?iu)(?:состояние|статус|state|status)").containsMatchIn(plainPage)
            val explicitlyNoAttempts = MoodleQuizOverviewHistorySignal.explicitlyConfirmsNoAttempts(plainPage)
            val visibleAttemptEvidence = Regex("(?iu)(?:завершен|отправлено|в\\s+процессе|submitted|finished|in\\s+progress)")
                .containsMatchIn(plainPage)
            // A generic table containing the word "status" is not proof of an empty history.
            // If we cannot parse an attempt, only Moodle's explicit no-attempt message or a
            // final-grade summary can make an empty result authoritative.
            if (pageAttempts.isEmpty() && !explicitlyNoAttempts && !summary.hasFinalGrade) {
                val reason = when {
                    visibleAttemptEvidence || hasHistoryTable -> "Moodle показал историю попыток, но её строки не удалось распознать."
                    else -> "Страница теста не подтвердила отсутствие попыток."
                }
                throw MoodleSessionException(reason)
            }
            attempts += pageAttempts
        }
        if (unresolvedPages > 0) {
            throw MoodleSessionException("Не удалось определить ID для $unresolvedPages тестов. История попыток не считается загруженной.")
        }
        if (requestedPages == 0 && quizzes.isNotEmpty()) {
            throw MoodleSessionException("В Moodle не удалось определить ни одной страницы теста для чтения истории попыток.")
        }
        if (requestedPages > 0 && loadedPages < requestedPages) {
            throw lastPageError ?: MoodleSessionException("История попыток загружена не полностью: $loadedPages из $requestedPages тестов.")
        }

        val uniqueAttempts = attempts.distinctBy { "${it.cmid}:${it.attemptId}" }
            .sortedByDescending(::moodleAttemptSortOrder)

        // The overview table often contains only the submission timestamp and score.
        // A review page can add start time and duration when Moodle allows review.
        return uniqueAttempts.map { attempt ->
            val needsDetails = attempt.started.isNullOrBlank() || attempt.completed.isNullOrBlank() ||
                attempt.elapsed.isNullOrBlank() || attempt.maxScore.isNullOrBlank()
            val reviewUrl = attempt.reviewUrl
            if (!needsDetails || reviewUrl.isNullOrBlank()) return@map attempt
            try {
                val reviewHtml = getPage(reviewUrl)
                val details = extractAttemptReviewDetails(reviewHtml)
                attempt.copy(
                    started = details.started ?: attempt.started,
                    completed = details.completed ?: attempt.completed,
                    elapsed = cleanMoodleElapsed(details.elapsed)
                        ?: cleanMoodleElapsed(attempt.elapsed)
                        ?: deriveMoodleElapsed(details.started ?: attempt.started, details.completed ?: attempt.completed),
                    score = details.score ?: attempt.score,
                    maxScore = details.maxScore ?: attempt.maxScore
                )
            } catch (expired: MoodleSessionExpiredException) {
                throw expired
            } catch (_: Exception) {
                attempt
            }
        }
    }

    private data class AttemptReviewDetails(
        val started: String? = null,
        val completed: String? = null,
        val elapsed: String? = null,
        val score: String? = null,
        val maxScore: String? = null
    )

    private fun extractAttemptReviewDetails(html: String): AttemptReviewDetails {
        val pairs = mutableListOf<Pair<String, String>>()
        Regex("(?is)<tr\\b[^>]*>(.*?)</tr>").findAll(html).forEach { row ->
            val fragment = row.groupValues[1]
            val headerCell = Regex("(?is)<th\\b[^>]*>(.*?)</th>").find(fragment)?.groupValues?.get(1)
            val dataCells = Regex("(?is)<td\\b[^>]*>(.*?)</td>").findAll(fragment).map { it.groupValues[1] }.toList()
            val label = headerCell ?: dataCells.getOrNull(0)
            val value = dataCells.firstOrNull()
                ?.takeIf { headerCell != null } ?: dataCells.getOrNull(1)
            val labelText = htmlToText(label.orEmpty())
            val valueText = htmlToText(value.orEmpty())
            if (labelText.isNotBlank() && valueText.isNotBlank()) pairs += labelText to valueText
        }
        Regex("(?is)<dt\\b[^>]*>(.*?)</dt>\\s*<dd\\b[^>]*>(.*?)</dd>")
            .findAll(html).forEach { match ->
                val label = htmlToText(match.groupValues[1])
                val value = htmlToText(match.groupValues[2])
                if (label.isNotBlank() && value.isNotBlank()) pairs += label to value
            }

        fun valueFor(vararg labels: String): String? = pairs.firstNotNullOfOrNull { pair: Pair<String, String> ->
            val normalized: String = normalizeTableLabel(pair.first)
            val value: String = pair.second
            value.takeIf { normalized.isNotBlank() && labels.any { candidate: String -> normalized.contains(candidate) } }
        }
        val body = htmlToText(html)
        fun inlineValue(pattern: Regex): String? = pattern.find(body)?.groupValues?.getOrNull(1)
            ?.trim()?.takeIf { it.isNotBlank() }?.take(160)

        val startedRaw = valueFor("started on", "time started", "начало попытки", "время начала", "начало", "начата", "начат")
            ?: inlineValue(Regex("(?iu)(?:started on|time started|начало попытки|время начала|начало|начата|начат)\\s*:?\\s*([^\\n]{3,160})"))
        val completedRaw = valueFor("completed on", "time completed", "submitted", "отправлено", "время завершения", "завершение попытки", "завершение", "завершено", "окончание")
            ?: inlineValue(Regex("(?iu)(?:completed on|time completed|submitted|отправлено|время завершения|завершение попытки|завершение|завершено|окончание)\\s*:?\\s*([^\\n]{3,160})"))
        val started = MoodleDateTimeParser.extract(startedRaw)
        val completed = MoodleDateTimeParser.extract(completedRaw)
        val elapsedRaw = valueFor("time taken", "elapsed time", "duration", "затраченное время", "время выполнения")
            ?: inlineValue(Regex("(?iu)(?:time taken|elapsed time|duration|затраченное время|время выполнения)\\s*:?\\s*([^\\n]{2,100})"))
        val elapsed = cleanMoodleElapsed(elapsedRaw)
        val gradeRaw = valueFor("grade", "marks", "оценка", "результат")
        val gradeFraction = gradeRaw?.let {
            Regex("(-?\\d+(?:[,.]\\d+)?)\\s*(?:/|из|out of)\\s*(-?\\d+(?:[,.]\\d+)?)", RegexOption.IGNORE_CASE).find(it)
        }
        val gradeStandalone = gradeRaw?.let { Regex("-?\\d+(?:[,.]\\d+)?").find(it)?.value }
        return AttemptReviewDetails(
            started = started,
            completed = completed,
            elapsed = elapsed,
            score = gradeFraction?.groupValues?.get(1)?.replace(',', '.') ?: gradeStandalone?.replace(',', '.'),
            maxScore = gradeFraction?.groupValues?.get(2)?.replace(',', '.')
        )
    }

    private data class QuizWebServiceMeta(
        val quizId: String,
        val cmid: String,
        val name: String?,
        val openTime: String?,
        val closeTime: String?,
        val timeLimit: String?,
        val attemptsAllowed: String?,
        val maxScore: String?,
        val rawMaxScore: String?
    ) {
        // A field omitted by Moodle is unknown, not an unlimited setting. Explicit zero values
        // are normalized to the corresponding "no restriction" text before this check.
        val hasCompleteSettings: Boolean
            get() = listOf(openTime, closeTime, timeLimit, attemptsAllowed).all { !it.isNullOrBlank() }
    }

    /**
     * Uses the official Moodle Mobile Web Services API, not lib/ajax/service.php.
     * Quiz instance id (quiz.id) and course-module id (quiz.coursemodule) are distinct values.
     */
    private fun loadQuizWebServiceMetadata(courseId: String): Map<String, QuizWebServiceMeta> {
        if (session.webServiceToken.isNullOrBlank()) return emptyMap()
        val response = callMobileWebService(
            "mod_quiz_get_quizzes_by_courses",
            mapOf("courseids[0]" to courseId)
        )
        val quizzes = response.asJsonObject.getAsJsonArray("quizzes") ?: JsonArray()
        return quizzes.mapNotNull { element ->
            if (!element.isJsonObject) return@mapNotNull null
            val quiz = element.asJsonObject
            val quizId = quiz.string("id") ?: return@mapNotNull null
            val cmid = quiz.string("coursemodule") ?: return@mapNotNull null
            QuizWebServiceMeta(
                quizId = quizId,
                cmid = cmid,
                name = quiz.string("name"),
                // Moodle uses 0 to mean that a date restriction is not configured. A missing
                // field is different: some sites omit restricted fields for a given user.
                openTime = formatMoodleDateRestriction(quiz.long("timeopen")),
                closeTime = formatMoodleDateRestriction(quiz.long("timeclose")),
                timeLimit = formatMoodleTimeLimit(quiz.long("timelimit")),
                attemptsAllowed = quiz.int("attempts")?.let { if (it <= 0) "Неограниченно" else it.toString() },
                // Moodle scales the raw sum of question marks (sumgrades) to the quiz grade.
                // The value shown to students is quiz.grade, not necessarily sumgrades.
                maxScore = quiz.get("grade")?.takeIf { !it.isJsonNull }?.asStringOrNumber()
                    ?: quiz.get("sumgrades")?.takeIf { !it.isJsonNull }?.asStringOrNumber(),
                rawMaxScore = quiz.get("sumgrades")?.takeIf { !it.isJsonNull }?.asStringOrNumber()
            )
        }.associateBy { it.cmid }
    }

    private fun formatMoodleDateRestriction(epochSeconds: Long?): String? = when {
        epochSeconds == null -> null
        epochSeconds <= 0L -> "Без ограничения по дате"
        else -> formatMoodleEpoch(epochSeconds)
    }

    private fun formatMoodleEpoch(epochSeconds: Long?): String? {
        if (epochSeconds == null || epochSeconds <= 0L) return null
        val formatter = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy, HH:mm", Locale("ru", "RU"))
        return runCatching {
            Instant.ofEpochSecond(epochSeconds).atZone(ZoneId.systemDefault()).format(formatter)
        }.getOrNull()
    }

    private fun formatMoodleTimeLimit(seconds: Long?): String? {
        if (seconds == null) return null
        if (seconds <= 0L) return "Без ограничения времени"
        val totalMinutes = (seconds + 59L) / 60L
        val hours = totalMinutes / 60L
        val minutes = totalMinutes % 60L
        return when {
            hours > 0L && minutes > 0L -> "$hours ч $minutes мин."
            hours > 0L -> "$hours ч."
            else -> "$totalMinutes мин."
        }
    }

    private fun JsonElement.asStringOrNumber(): String? = runCatching {
        asJsonPrimitive.let { primitive ->
            if (primitive.isNumber) primitive.asBigDecimal.stripTrailingZeros().toPlainString()
            else primitive.asString
        }
    }.getOrNull()

    private fun scaleMoodleQuizGrade(rawScore: String?, rawMaximum: String?, displayedMaximum: String?): String? {
        val score = rawScore?.replace(',', '.')?.toBigDecimalOrNull() ?: return null
        val rawMax = rawMaximum?.replace(',', '.')?.toBigDecimalOrNull()
        val gradeMax = displayedMaximum?.replace(',', '.')?.toBigDecimalOrNull()
        if (rawMax == null || gradeMax == null || rawMax.signum() <= 0) {
            return score.stripTrailingZeros().toPlainString()
        }
        return score.multiply(gradeMax).divide(rawMax, 2, java.math.RoundingMode.HALF_UP)
            .stripTrailingZeros().toPlainString()
    }

    private data class ApiBestGrade(
        val hasGrade: Boolean,
        val score: String?,
        val maximum: String?,
        val percent: String?
    )

    /**
     * Uses Moodle's official mod_quiz_get_user_best_grade function. Moodle applies the same
     * review permissions as the web UI: hasgrade=false can mean marks are hidden, not no attempt.
     */
    private fun loadQuizBestGrade(quizId: String, maximum: String?): ApiBestGrade {
        val result = callMobileWebService(
            "mod_quiz_get_user_best_grade",
            mapOf("quizid" to quizId, "userid" to "0")
        ).asJsonObject
        val hasGradeElement = result.get("hasgrade")
            ?: throw MoodleSessionException("Moodle не вернул признак hasgrade для теста $quizId.")
        val hasGrade = MoodleApiBoolean.parse(
            runCatching { hasGradeElement.asString }.getOrNull()
        ) ?: throw MoodleSessionException("Moodle вернул неизвестный формат hasgrade для теста $quizId.")
        val score = if (hasGrade) result.get("grade")?.takeIf { !it.isJsonNull }?.asStringOrNumber() else null
        val max = maximum?.takeIf { it.isNotBlank() }
        val percent = if (hasGrade && score != null && max != null) {
            val raw = score.toBigDecimalOrNull()
            val limit = max.toBigDecimalOrNull()
            if (raw != null && limit != null && limit.signum() > 0) {
                raw.multiply(java.math.BigDecimal("100"))
                    .divide(limit, 2, java.math.RoundingMode.HALF_UP)
                    .stripTrailingZeros().toPlainString()
            } else null
        } else null
        return ApiBestGrade(hasGrade, score, max, percent)
    }

    private fun applyApiBestGrade(quiz: MoodleQuiz, quizId: String, maximum: String?): MoodleQuiz {
        val grade = runCatching { loadQuizBestGrade(quizId, maximum) }.getOrNull() ?: return quiz
        return quiz.copy(
            gradeScore = grade.score,
            gradeMax = grade.maximum,
            gradePercent = grade.percent,
            hasApiBestGrade = grade.hasGrade
        )
    }

    /** Calls functions assigned by Moodle to the official moodle_mobile_app service. */
    private fun callMobileWebService(function: String, parameters: Map<String, String>): JsonElement {
        val token = session.webServiceToken?.takeIf { it.isNotBlank() }
            ?: throw MoodleSessionException("Для нативного API Moodle требуется токен Mobile Web Services.")
        val body = FormBody.Builder().apply {
            add("wstoken", token)
            add("wsfunction", function)
            add("moodlewsrestformat", "json")
            parameters.forEach { (name, value) -> add(name, value) }
        }.build()
        val endpoint = "${session.baseUrl.trimEnd('/')}/webservice/rest/server.php"
        val request = Request.Builder().url(endpoint)
            .header("Accept", "application/json")
            .header("User-Agent", MOODLE_PAGE_USER_AGENT)
            .post(body).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw MoodleSessionException("Moodle Web Service вернул HTTP ${response.code}.")
            val json = runCatching { JsonParser.parseString(raw) }.getOrElse {
                throw MoodleSessionException("Moodle Web Service вернул не JSON. Проверьте Mobile Web Services на сервере.")
            }
            if (json.isJsonObject) {
                val root = json.asJsonObject
                if (root.has("exception") || root.has("errorcode")) {
                    val message = root.get("message")?.takeIf { !it.isJsonNull }?.asString
                        ?: root.get("error")?.takeIf { !it.isJsonNull }?.asString
                        ?: root.get("errorcode")?.takeIf { !it.isJsonNull }?.asString
                        ?: "Moodle отклонил вызов $function"
                    val errorCode = root.get("errorcode")?.takeIf { !it.isJsonNull }
                        ?.let { runCatching { it.asString }.getOrNull() }
                    throw MoodleWebServiceException(message, errorCode, function)
                }
            }
            return json
        }
    }

    private fun isWebServiceFunctionUnavailable(error: MoodleSessionException): Boolean {
        val webServiceError = error as? MoodleWebServiceException
        val code = webServiceError?.errorCode.orEmpty().lowercase(Locale.ROOT)
        if (code in setOf("functionnotavailable", "invalidfunction", "unknownfunction")) return true
        return Regex(
            "(?iu)(?:function\\s+[^ ]+\\s+(?:does not exist|is not available|was not found)|unknown\\s+function|функц(?:ия|ии)\\s+[^.]*не\\s+(?:существует|доступна|найдена))"
        ).containsMatchIn(error.message.orEmpty())
    }

    private fun loadQuizAttemptsFromWebService(
        course: MoodleCourse,
        quizzes: List<MoodleQuiz>,
        metadataByCmid: Map<String, QuizWebServiceMeta>
    ): List<MoodleQuizAttempt> {
        val output = mutableListOf<MoodleQuizAttempt>()
        quizzes.forEach { quiz ->
            val cmid = resolveQuizCmid(quiz) ?: return@forEach
            val meta = metadataByCmid[cmid] ?: return@forEach
            val commonParams = mapOf(
                "quizid" to meta.quizId,
                "userid" to "0",
                "status" to "all",
                "includepreviews" to "0"
            )
            val (result, completeStateEndpoint) = try {
                // Moodle 4.5+ API returns true states, including NOT_STARTED and SUBMITTED.
                callMobileWebService("mod_quiz_get_user_quiz_attempts", commonParams) to true
            } catch (newFunctionError: MoodleSessionException) {
                if (!isWebServiceFunctionUnavailable(newFunctionError)) throw newFunctionError
                val legacy = runCatching {
                    callMobileWebService("mod_quiz_get_user_attempts", commonParams)
                }.getOrElse { throw newFunctionError }
                legacy to false
            }
            val rows = result.asJsonObject.get("attempts")
                ?.takeIf { it.isJsonArray }
                ?.asJsonArray
                ?: throw MoodleSessionException("Moodle Web Service не вернул массив attempts для теста «${quiz.quizName}».")
            if (rows.size() == 0 && !completeStateEndpoint) {
                throw MoodleSessionException(
                    "Старый API Moodle вернул пустой список. Он не позволяет подтвердить отсутствие попыток в этом тесте."
                )
            }
            rows.forEach { rowElement ->
                if (!rowElement.isJsonObject) return@forEach
                val row = rowElement.asJsonObject
                val id = row.string("id") ?: return@forEach
                val status = normalizeMoodleApiAttemptStatus(row.string("state"))
                val started = formatMoodleEpoch(row.long("timestart"))
                val completed = formatMoodleEpoch(row.long("timefinish"))
                val rawScore = row.get("sumgrades")?.takeIf { !it.isJsonNull }?.asStringOrNumber()
                val score = scaleMoodleQuizGrade(rawScore, meta.rawMaxScore, meta.maxScore)
                output += MoodleQuizAttempt(
                    courseId = course.courseId,
                    attemptId = id,
                    cmid = cmid,
                    quizName = quiz.quizName,
                    attemptRow = row.int("attempt")?.toString(),
                    status = status,
                    started = started,
                    completed = completed,
                    elapsed = deriveMoodleElapsed(started, completed),
                    score = score,
                    maxScore = meta.maxScore,
                    currentPage = row.int("currentpage")
                )
            }
        }
        return output.sortedByDescending(::moodleAttemptSortOrder)
    }

    /** Effective per-user access rights and Moodle access-rule messages for a quiz. */
    fun getQuizAccessInformation(quizId: String): JsonObject = callMobileWebService(
        "mod_quiz_get_quiz_access_information",
        // This function accepts quizid only. Unlike get_user_quiz_attempts and
        // get_user_best_grade, it always evaluates the currently authenticated user.
        mapOf("quizid" to quizId)
    ).asJsonObject

    /** Effective access to an existing attempt; attemptid=0 asks Moodle for the latest one. */
    fun getAttemptAccessInformation(quizId: String, attemptId: String = "0"): JsonObject = callMobileWebService(
        "mod_quiz_get_attempt_access_information",
        mapOf("quizid" to quizId, "attemptid" to attemptId)
    ).asJsonObject

    /** Moodle quiz instance id differs from the course-module id used in course navigation. */
    fun resolveQuizInstanceId(quiz: MoodleQuiz): String? {
        quiz.quizId?.takeIf { it.isNotBlank() }?.let { return it }
        val cmid = resolveQuizCmid(quiz) ?: return null
        return loadQuizWebServiceMetadata(quiz.courseId)[cmid]?.quizId
    }

    /** Starts an attempt through Mobile Web Services. Password/preflight data is passed only in memory. */
    fun startQuizAttempt(
        quizId: String,
        forcenew: Boolean = false,
        preflightData: List<Pair<String, String>> = emptyList()
    ): JsonObject = callMobileWebService(
        "mod_quiz_start_attempt",
        buildMap {
            put("quizid", quizId)
            put("forcenew", if (forcenew) "1" else "0")
            preflightData.forEachIndexed { index, pair ->
                put("preflightdata[$index][name]", pair.first)
                put("preflightdata[$index][value]", pair.second)
            }
        }
    ).asJsonObject

    fun getQuizAttemptData(attemptId: String, page: Int): JsonObject =
        callMobileWebService("mod_quiz_get_attempt_data", mapOf("attemptid" to attemptId, "page" to page.toString())).asJsonObject

    fun getQuizAttemptSummary(attemptId: String): JsonObject =
        callMobileWebService("mod_quiz_get_attempt_summary", mapOf("attemptid" to attemptId)).asJsonObject

    fun getQuizAttemptReview(attemptId: String, page: Int = -1): JsonObject =
        callMobileWebService("mod_quiz_get_attempt_review", mapOf("attemptid" to attemptId, "page" to page.toString())).asJsonObject

    fun saveQuizAttempt(attemptId: String, data: List<Pair<String, String>>) {
        callMobileWebService("mod_quiz_save_attempt", buildQuizResponseParameters(attemptId, data))
    }

    fun processQuizAttempt(
        attemptId: String,
        data: List<Pair<String, String>>,
        finish: Boolean,
        timeUp: Boolean = false
    ): JsonObject = callMobileWebService(
        "mod_quiz_process_attempt",
        buildQuizResponseParameters(attemptId, data) + mapOf(
            "finishattempt" to if (finish) "1" else "0",
            "timeup" to if (timeUp) "1" else "0"
        )
    ).asJsonObject

    private fun applyQuizAccessInformation(quiz: MoodleQuiz, quizId: String): MoodleQuiz {
        val info = runCatching { getQuizAccessInformation(quizId) }.getOrNull() ?: return quiz
        fun bool(source: JsonObject, key: String): Boolean? = source.get(key)?.takeIf { !it.isJsonNull }?.let { element ->
            runCatching {
                when {
                    element.asJsonPrimitive.isBoolean -> element.asBoolean
                    element.asJsonPrimitive.isNumber -> element.asInt != 0
                    else -> element.asString.lowercase(Locale.ROOT) in setOf("1", "true", "yes")
                }
            }.getOrNull()
        }
        fun stringArray(source: JsonObject, key: String): List<String> =
            source.get(key)?.takeIf { it.isJsonArray }?.asJsonArray
                ?.mapNotNull { item -> runCatching { item.asString }.getOrNull()?.takeIf(String::isNotBlank) }
                .orEmpty()

        // preventaccessreasons / preventnewattemptreasons are localized user-facing messages.
        // activerulenames contains plugin identifiers and is not suitable for the UI.
        val accessReasons = stringArray(info, "preventaccessreasons")
        val attemptInfo = runCatching { getAttemptAccessInformation(quizId) }.getOrNull()
        val newAttemptReasons = attemptInfo?.let { stringArray(it, "preventnewattemptreasons") }.orEmpty()
        val attemptsExhausted = attemptInfo?.let { bool(it, "isfinished") } == true
        val capability = bool(info, "canattempt")
        val reasons = (accessReasons + newAttemptReasons).distinct().toMutableList()
        if (attemptsExhausted && reasons.isEmpty()) {
            reasons += "Доступные попытки исчерпаны."
        }

        return quiz.copy(
            accessInfoLoaded = true,
            // canattempt is only a role capability. Effective permission also depends on active
            // access rules and Moodle's separate new-attempt calculation (limits/delays).
            canAttempt = if (attemptInfo == null) null else capability?.let {
                it && accessReasons.isEmpty() && newAttemptReasons.isEmpty() && !attemptsExhausted
            },
            canReviewMyAttempts = bool(info, "canreviewmyattempts"),
            quizAccessReasons = reasons
        )
    }

    private fun buildQuizResponseParameters(attemptId: String, data: List<Pair<String, String>>): Map<String, String> =
        buildMap {
            put("attemptid", attemptId)
            data.forEachIndexed { index, pair ->
                put("data[$index][name]", pair.first)
                put("data[$index][value]", pair.second)
            }
        }

    /**
     * Loads per-user quiz settings from the official Mobile Web Service when available,
     * with the authenticated quiz overview page as a read-only fallback.
     */
    fun loadQuizDetails(quizzes: List<MoodleQuiz>): List<MoodleQuiz> {
        val apiByCmid = if (!session.webServiceToken.isNullOrBlank()) {
            runCatching {
                val courseId = quizzes.firstOrNull()?.courseId ?: return@runCatching emptyMap()
                loadQuizWebServiceMetadata(courseId)
            }.getOrNull().orEmpty()
        } else emptyMap()

        return quizzes.map { quiz ->
            val cmid = resolveQuizCmid(quiz)
            val apiMeta = cmid?.let(apiByCmid::get)
            val knownQuizId = apiMeta?.quizId ?: quiz.quizId?.takeIf { it.isNotBlank() }
            val apiSettingsComplete = apiMeta?.hasCompleteSettings == true

            // Merge only current API fields into the visible values. Keep cached values as a
            // display fallback, but never let them make the current details load look complete.
            val apiEnrichedQuiz = quiz.copy(
                quizId = knownQuizId ?: quiz.quizId,
                openTimeText = apiMeta?.openTime ?: quiz.openTimeText,
                closeTimeText = apiMeta?.closeTime ?: quiz.closeTimeText,
                timeLimit = apiMeta?.timeLimit ?: quiz.timeLimit,
                allowedAttempts = apiMeta?.attemptsAllowed ?: quiz.allowedAttempts,
                gradeMax = apiMeta?.maxScore ?: quiz.gradeMax,
                detailsLoaded = apiSettingsComplete,
                detailsParserVersion = QUIZ_DETAILS_PARSER_VERSION,
                detailsError = null
            )

            fun withBestGrade(value: MoodleQuiz): MoodleQuiz {
                if (session.webServiceToken.isNullOrBlank() || knownQuizId.isNullOrBlank()) return value
                val withAccess = applyQuizAccessInformation(value, knownQuizId)
                return applyApiBestGrade(withAccess, knownQuizId, apiMeta?.maxScore ?: value.gradeMax)
            }

            // API settings are accepted only when Moodle actually returned all four fields.
            // In particular, a cached detailsLoaded flag cannot short-circuit this check.
            if (apiSettingsComplete) {
                return@map withBestGrade(apiEnrichedQuiz.copy(status = null))
            }

            if (cmid.isNullOrBlank()) {
                return@map withBestGrade(apiEnrichedQuiz.copy(detailsLoaded = false))
            }

            try {
                // API metadata can omit timelimit/attempts for restricted quizzes. Read the
                // authenticated overview page independently instead of treating those fields
                // as zero or returning early because an older cache says detailsLoaded=true.
                val suppliedUrl = quiz.url
                    ?.takeIf { it.isNotBlank() }
                    ?.let(::normalizeMoodlePageUrl)
                    ?.takeIf { it.contains("/mod/quiz/", ignoreCase = true) }
                val canonicalUrl = normalizeMoodlePageUrl(
                    "${session.baseUrl.trimEnd('/')}/mod/quiz/view.php?id=$cmid"
                )
                val candidates: List<String> = listOfNotNull(canonicalUrl, suppliedUrl).distinct()
                var combined: MoodleQuizPageSettingsParser.Result? = null
                var recognizedPage = false
                var lastPageTitle = ""
                var lastError: Exception? = null

                for (candidate in candidates) {
                    try {
                        val html = getPage(candidate)
                        val isOverview = isQuizOverviewHtml(html, quiz.quizName)
                        if (!isOverview) {
                            lastPageTitle = Regex("(?is)<title\\b[^>]*>(.*?)</title>")
                                .find(html)?.groupValues?.get(1)?.let(::htmlToText).orEmpty()
                            continue
                        }
                        recognizedPage = true
                        val parsed = extractQuizPageSettings(html, isConfirmedQuizPage = true)
                        val previous = combined
                        combined = MoodleQuizPageSettingsParser.Result(
                            openTime = parsed.openTime ?: previous?.openTime,
                            closeTime = parsed.closeTime ?: previous?.closeTime,
                            timeLimit = parsed.timeLimit ?: previous?.timeLimit,
                            allowedAttempts = parsed.allowedAttempts ?: previous?.allowedAttempts,
                            isComplete = listOf(
                                parsed.openTime ?: previous?.openTime,
                                parsed.closeTime ?: previous?.closeTime,
                                parsed.timeLimit ?: previous?.timeLimit,
                                parsed.allowedAttempts ?: previous?.allowedAttempts
                            ).all { !it.isNullOrBlank() },
                            missingFields = listOf(
                                "дата открытия" to (parsed.openTime ?: previous?.openTime),
                                "дата закрытия" to (parsed.closeTime ?: previous?.closeTime),
                                "ограничение времени" to (parsed.timeLimit ?: previous?.timeLimit),
                                "количество попыток" to (parsed.allowedAttempts ?: previous?.allowedAttempts)
                            ).filter { it.second.isNullOrBlank() }.map { it.first }
                        )
                        if (combined?.isComplete == true) break
                    } catch (expired: MoodleSessionExpiredException) {
                        throw expired
                    } catch (error: Exception) {
                        lastError = error
                    }
                }

                val pageSettings = combined
                if (!recognizedPage || pageSettings == null) {
                    throw lastError ?: MoodleSessionException(
                        "Не удалось открыть страницу настроек теста Moodle (ID $cmid${lastPageTitle.takeIf { it.isNotBlank() }?.let { ", заголовок: ${it.take(70)}" } ?: ""})"
                    )
                }

                // Completeness is based on freshly returned API/page fields, not on old cached
                // values. Cached values remain visible but cannot prevent another refresh.
                val currentOpen = apiMeta?.openTime ?: pageSettings.openTime
                val currentClose = apiMeta?.closeTime ?: pageSettings.closeTime
                val currentLimit = apiMeta?.timeLimit ?: pageSettings.timeLimit
                val currentAttempts = apiMeta?.attemptsAllowed ?: pageSettings.allowedAttempts
                val complete = listOf(currentOpen, currentClose, currentLimit, currentAttempts)
                    .all { !it.isNullOrBlank() }
                val updated = apiEnrichedQuiz.copy(
                    openTimeText = currentOpen ?: apiEnrichedQuiz.openTimeText,
                    closeTimeText = currentClose ?: apiEnrichedQuiz.closeTimeText,
                    timeLimit = currentLimit ?: apiEnrichedQuiz.timeLimit,
                    allowedAttempts = currentAttempts ?: apiEnrichedQuiz.allowedAttempts,
                    detailsLoaded = complete,
                    detailsParserVersion = QUIZ_DETAILS_PARSER_VERSION,
                    detailsError = null,
                    status = null
                )
                withBestGrade(updated)
            } catch (expired: MoodleSessionExpiredException) {
                throw expired
            } catch (_: Exception) {
                // Preserve last-known settings for offline display, but mark this attempt as
                // incomplete so the next open can retry the authenticated HTML fallback.
                withBestGrade(apiEnrichedQuiz.copy(detailsLoaded = false))
            }
        }
    }

    private fun isQuizOverviewHtml(html: String, quizName: String): Boolean {
        val hasQuizBodyClass = Regex("(?is)<body\\b[^>]*class=[\"'][^\"']*path-mod-quiz").containsMatchIn(html)
        val hasQuizPageId = Regex("(?is)id=[\"']page-mod-quiz-view[\"']").containsMatchIn(html)
        val hasQuizMarkers = listOf(
            "Результаты ваших предыдущих попыток", "Разрешено попыток", "Ограничение по времени",
            "Открыто с", "Закрыто с", "Your previous attempts", "Attempts allowed", "Time limit"
        ).any { html.contains(it, ignoreCase = true) }
        val title = Regex("(?is)<title\\b[^>]*>(.*?)</title>").find(html)?.groupValues?.get(1)?.let(::htmlToText).orEmpty()
        val heading = htmlToText(Regex("(?is)<h1\\b[^>]*>(.*?)</h1>").find(html)?.groupValues?.get(1).orEmpty())
        val matchingTitle = quizName.isNotBlank() &&
            (title.contains(quizName, ignoreCase = true) || heading.contains(quizName, ignoreCase = true))
        return hasQuizBodyClass || hasQuizPageId || hasQuizMarkers || matchingTitle
    }

    private fun extractQuizPageSettings(
        html: String,
        isConfirmedQuizPage: Boolean
    ): MoodleQuizPageSettingsParser.Result {
        val visibleHtml = html
            .replace(Regex("(?is)<(script|style|noscript)\\b[^>]*>.*?</\\1>"), " ")
            .replace(Regex("(?is)<br\\s*/?>"), "\n")
        val text = Html.fromHtml(visibleHtml, Html.FROM_HTML_MODE_LEGACY).toString()
        val structuredRows = MoodleQuizSettingsHtmlRowsParser.extract(visibleHtml, ::htmlToText)
        // Table/dl extraction retains label-value association even when a Moodle theme renders
        // cells without a line break. The visible page text remains a fallback for div/list layouts.
        val parserText = (structuredRows + text).filter { it.isNotBlank() }.joinToString("\n")
        val hasSettingsContainer = Regex(
            "(?is)<(?:div|section|table)\\b[^>]*class=[\"'][^\"']*\\b(?:quizinfo|quizdates|quizattempt)\\b"
        ).containsMatchIn(html) ||
            Regex("(?is)id=[\"']page-mod-quiz-view[\"']").containsMatchIn(html)
        return MoodleQuizPageSettingsParser.parseText(
            rawText = parserText,
            hasQuizInfoBlock = isConfirmedQuizPage && hasSettingsContainer
        )
    }

    private fun normalizeMoodlePageUrl(raw: String): String? {
        val candidate = when {
            raw.startsWith("https://", true) -> raw
            raw.startsWith("/") -> session.baseUrl.trimEnd('/') + raw
            else -> session.baseUrl.trimEnd('/') + "/" + raw.trimStart('/')
        }
        val parsed = candidate.toHttpUrlOrNull() ?: return null
        return candidate.takeIf { parsed.isHttps && parsed.host == "moodle.math.tusur.ru" }
    }

    private fun loadCalendar(courseId: String): List<MoodleCalendarEvent> {
        val now = Instant.now().epochSecond
        val collected = mutableListOf<JsonElement>()
        var afterEventId = 0L
        var pageNumber = 0
        while (pageNumber < 20) {
            val args = JsonObject().apply {
                addProperty("timesortfrom", now)
                addProperty("timesortto", now + 180L * 86400L)
                addProperty("aftereventid", afterEventId)
                addProperty("limitnum", 50)
                addProperty("limittononsuspendedevents", true)
            }
            val payload = call("core_calendar_get_action_events_by_timesort", args)
            val events = when {
                payload.isJsonArray -> payload.asJsonArray.toList()
                payload.isJsonObject -> {
                    val obj = payload.asJsonObject
                    val named = listOf("events", "actionevents", "action_events", "items")
                        .mapNotNull { key -> obj.get(key)?.takeIf { it.isJsonArray }?.asJsonArray?.toList() }
                        .firstOrNull()
                    named ?: obj.entrySet().mapNotNull { (_, value) ->
                        value.takeIf { it.isJsonObject && (it.asJsonObject.has("id") || it.asJsonObject.has("name")) }
                    }
                }
                else -> emptyList()
            }
            if (events.isEmpty()) break
            collected += events
            val maxId = events.asSequence()
                .filter { it.isJsonObject }
                .mapNotNull { it.asJsonObject.string("id")?.toLongOrNull() }
                .maxOrNull()
            pageNumber += 1
            if (events.size < 50 || maxId == null || maxId <= afterEventId) break
            afterEventId = maxId
        }
        return collected.distinctBy { element ->
            if (element.isJsonObject) element.asJsonObject.string("id") ?: element.toString() else element.toString()
        }.mapNotNull { el ->
            if (!el.isJsonObject) return@mapNotNull null
            val e = el.asJsonObject
            val eventCourseId = e.getAsJsonObject("course")?.get("id")?.asString
            if (eventCourseId != null && eventCourseId != courseId) return@mapNotNull null
            val id = e.string("id") ?: return@mapNotNull null
            val action = e.get("action")?.takeIf { it.isJsonObject }?.asJsonObject
            MoodleCalendarEvent(
                eventId = id,
                courseId = eventCourseId,
                name = e.string("name") ?: "Событие Moodle",
                eventtype = e.string("eventtype"),
                timestart = e.long("timestart"),
                formattedTime = e.string("formattedtime"),
                description = e.string("description"),
                timeDuration = e.long("timeduration"),
                actionName = action?.string("name"),
                actionItemType = action?.string("itemtype"),
                actionable = action?.get("actionable")?.let { runCatching { it.asBoolean }.getOrNull() },
                overdue = action?.get("overdue")?.let { runCatching { it.asBoolean }.getOrNull() },
                url = e.string("url"),
                activityUrl = action?.string("url")
            )
        }
    }

    private fun call(method: String, args: JsonObject): JsonElement {
        val response = callBatch(listOf(AjaxCall(0, method, args)))
        return response.firstOrNull()?.get("data")
            ?: throw MoodleSessionException("Moodle не вернул данные для $method")
    }

    private fun callBatch(calls: List<AjaxCall>): List<JsonObject> {
        if (calls.isEmpty()) return emptyList()
        val payload = JsonArray()
        calls.forEach { call ->
            payload.add(JsonObject().apply {
                addProperty("index", call.index)
                addProperty("methodname", call.methodname)
                add("args", call.args)
            })
        }
        val sesskey = URLEncoder.encode(session.sesskey, Charsets.UTF_8.name())
        val request = Request.Builder()
            .url("${session.baseUrl}lib/ajax/service.php?sesskey=$sesskey")
            .header("Cookie", session.cookieHeader)
            .header("Accept", "application/json")
            .header("Origin", session.baseUrl.trimEnd('/'))
            .header("Referer", "${session.baseUrl}my/")
            .header("X-Requested-With", "XMLHttpRequest")
            .post(gson.toJson(payload).toRequestBody(jsonMedia))
            .build()
        client.newCall(request).execute().use { response ->
            if (response.code in 300..399) {
                val target = response.header("Location")?.let { response.request.url.resolve(it) }
                if (target?.host != "moodle.math.tusur.ru" || !target.isHttps) {
                    throw MoodleSessionException("Moodle перенаправил запрос на другой сайт; cookies туда не переданы.")
                }
                if (target.encodedPath.contains("/login/", true)) {
                    throw MoodleSessionExpiredException("Сессия Moodle завершилась. Войдите в Moodle повторно.")
                }
                throw MoodleSessionException("Moodle перенаправил AJAX-запрос. Повторите вход и попробуйте снова.")
            }
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw MoodleSessionException("Moodle вернул HTTP ${response.code}")
            if (looksLikeLoginPage(body)) {
                throw MoodleSessionExpiredException("Сессия Moodle завершилась. Войдите в Moodle повторно.")
            }
            val parsed = runCatching { JsonParser.parseString(body) }.getOrElse {
                throw MoodleSessionException("Moodle вернул неожиданный ответ. Возможно, требуется повторный вход.")
            }
            if (!parsed.isJsonArray) throw MoodleSessionException("Неожиданный формат ответа Moodle AJAX")
            return parsed.asJsonArray.map { item ->
                val obj = item.asJsonObject
                if (obj.get("error")?.asBoolean == true) {
                    val exception = obj.getAsJsonObject("exception")
                    val message = exception?.get("message")?.asString
                        ?: exception?.get("errorcode")?.asString
                        ?: "Moodle отклонил запрос"
                    if (message.contains("sesskey", true) || message.contains("session", true)) {
                        throw MoodleSessionExpiredException(message)
                    }
                    throw MoodleSessionException(message)
                }
                obj
            }
        }
    }

    /**
     * Resolve a Moodle resource module to its actual pluginfile URL. This avoids opening
     * mod/resource/view.php first and then requiring a second tap on the file link.
     */
    fun resolveDirectResourceFileUrl(module: MoodleModule): String? {
        val cachedLinks = runCatching {
            gson.fromJson<List<String>>(module.fileLinksJson ?: "[]", object : com.google.gson.reflect.TypeToken<List<String>>() {}.type)
        }.getOrNull().orEmpty()
        cachedLinks.firstOrNull { isTrustedMoodleFileUrl(it) }?.let { return it }

        val startUrl = module.url?.takeIf { it.isNotBlank() } ?: return null
        var current = normalizeMoodlePageUrl(startUrl)?.toHttpUrlOrNull() ?: return null
        for (hop in 0 until 5) {
            val request = Request.Builder()
                .url(current)
                .header("Cookie", session.cookieHeader)
                .header("User-Agent", MOODLE_PAGE_USER_AGENT)
                .header("Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7")
                .header("Referer", "${session.baseUrl}course/view.php?id=${module.courseId}")
                .header("Accept", "text/html,application/xhtml+xml,application/pdf,*/*")
                .get()
                .build()
            var nextUrl: okhttp3.HttpUrl? = null
            var directUrl: String? = null
            var shouldStop = false
            client.newCall(request).execute().use { response ->
                if (response.code in 300..399) {
                    val location = response.header("Location")
                    val next = location?.let { response.request.url.resolve(it) }
                    if (next == null || !next.isHttps || next.host != "moodle.math.tusur.ru") {
                        shouldStop = true
                    } else if (next.encodedPath.contains("pluginfile.php", true)) {
                        directUrl = next.toString()
                    } else {
                        nextUrl = next
                    }
                } else if (!response.isSuccessful) {
                    shouldStop = true
                } else {
                    val contentType = response.header("Content-Type").orEmpty()
                    if (!contentType.contains("text/html", true) && !contentType.contains("application/xhtml", true)) {
                        directUrl = current.toString()
                    } else {
                        val html = response.body?.string().orEmpty()
                        directUrl = pluginFileLinks(html).firstOrNull { isTrustedMoodleFileUrl(it) }
                        if (directUrl == null) {
                            // Some Moodle themes put the direct file URL in a plain anchor.
                            val href = Regex("""(?is)<a\b[^>]*href\s*=\s*["']([^"']*pluginfile\.php[^"']*)["']""")
                                .find(html)?.groupValues?.get(1)?.replace("&amp;", "&")
                            if (!href.isNullOrBlank()) {
                                val resolved = response.request.url.resolve(href)
                                if (resolved != null && resolved.isHttps && resolved.host == "moodle.math.tusur.ru") {
                                    directUrl = resolved.toString()
                                }
                            }
                        }
                        if (directUrl == null) shouldStop = true
                    }
                }
            }
            if (directUrl != null) return directUrl
            if (shouldStop || nextUrl == null) return null
            current = nextUrl!!
        }
        return null
    }

    private fun isTrustedMoodleFileUrl(raw: String): Boolean {
        val parsed = raw.toHttpUrlOrNull() ?: return false
        return parsed.isHttps && parsed.host == "moodle.math.tusur.ru" &&
            parsed.encodedPath.contains("pluginfile.php", ignoreCase = true)
    }

    private fun getPage(
        url: String,
        redirectsRemaining: Int = 4,
        referer: String = "${session.baseUrl}my/"
    ): String {
        val parsed = url.toHttpUrlOrNull()
        require(parsed != null && parsed.isHttps && parsed.host == "moodle.math.tusur.ru") { "Разрешены только HTTPS-страницы основного Moodle ТУСУР" }
        val request = Request.Builder().url(url).header("Cookie", session.cookieHeader)
            .header("User-Agent", MOODLE_PAGE_USER_AGENT)
            .header("Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7")
            .header("Referer", referer)
            .header("Cache-Control", "no-cache")
            .header("Pragma", "no-cache")
            .header("Accept", "text/html,application/xhtml+xml")
            .get().build()
        client.newCall(request).execute().use { response ->
            if (response.code in 300..399) {
                val target = response.header("Location")?.let { response.request.url.resolve(it) }
                if (target?.host != "moodle.math.tusur.ru" || !target.isHttps) {
                    throw MoodleSessionException("Moodle попытался перенаправить страницу на другой сайт; переход остановлен для защиты cookies.")
                }
                if (target.encodedPath.contains("/login/", true)) {
                    throw MoodleSessionExpiredException("Сессия Moodle завершилась. Войдите в Moodle повторно.")
                }
                if (redirectsRemaining <= 0) throw MoodleSessionException("Слишком много перенаправлений внутри Moodle.")
                return getPage(target.toString(), redirectsRemaining - 1, referer)
            }
            if (response.code == 401 || response.request.url.encodedPath.contains("/login/")) {
                throw MoodleSessionExpiredException("Сессия Moodle завершилась. Войдите в Moodle повторно.")
            }
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw MoodleSessionException("Не удалось загрузить страницу Moodle: HTTP ${response.code}")
            if (looksLikeLoginPage(body)) {
                throw MoodleSessionExpiredException("Сессия Moodle завершилась. Войдите в Moodle повторно.")
            }
            return body
        }
    }


    private fun looksLikeLoginPage(body: String): Boolean {
        val explicitLoginForm = Regex(
            """(?is)<form\b[^>]*(?:id=["']login["']|action=["'][^"']*login/index\.php)"""
        ).containsMatchIn(body)
        val usernameAndPassword = Regex("""(?is)<input\b[^>]*name=["']username["']""").containsMatchIn(body) &&
            Regex("""(?is)<input\b[^>]*name=["']password["']""").containsMatchIn(body)
        return explicitLoginForm || usernameAndPassword
    }

    private fun pluginFileLinks(html: String): List<String> {
        val pattern = Regex("""(?is)(?:href|src)\s*=\s*['"]([^'"]*pluginfile\.php[^'"]*)['"]""")
        return pattern.findAll(html).map { it.groupValues[1].replace("&amp;", "&") }
            .map { raw -> if (raw.startsWith("/")) session.baseUrl.trimEnd('/') + raw else raw }
            .filter { it.startsWith(session.baseUrl, true) }
            .distinct().take(20).toList()
    }

    /** Normalize localized Moodle table headings before matching their semantic columns. */
    private fun normalizeTableLabel(value: String): String = value
        .lowercase(Locale.ROOT)
        .replace('ё', 'е')
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()

    private fun htmlToText(value: String): String = Html.fromHtml(value, Html.FROM_HTML_MODE_COMPACT)
        .toString()
        .replace('\uFFFC', ' ')
        .replace('\u00A0', ' ')
        .replace(Regex("(?i)\\bOBJ\\b"), " ")
        .replace(Regex("[ \t]+"), " ")
        .replace(Regex("\n{3,}"), "\n\n")
        .trim()
        .take(5000)

    private fun extractQuizTimeLimit(html: String): String? {
        val text = htmlToText(html)
        val match = Regex("""(?iu)(?:ограничение\s+по\s+времени|ограничение времени|время выполнения|time limit)\s*:?\s*([^.;]{1,80})""").find(text)
        return match?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }
    }

    private fun extractQuizAttemptsLimit(html: String): String? {
        val text = htmlToText(html)
        val match = Regex("""(?i)(?:разрешено попыток|количество попыток|attempts allowed)\s*:?\s*(\d+|неограниченно)""").find(text)
        return match?.groupValues?.get(1)?.trim()
    }

    private fun extractQuizDateText(html: String, keyword: String): String? {
        val text = htmlToText(html)
        val match = Regex("""(?i)(?:${keyword}тие|${keyword}тие|${keyword}ание|${keyword}ение|${keyword}тия)\s*:?\s*([^.;]{1,100})""").find(text)
        return match?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }
    }

    private data class ModuleSeed(
        val id: String,
        val sectionId: String?,
        val sectionNumber: Int?,
        val name: String,
        val module: String?,
        val displayName: String?,
        val visible: Int?,
        val userVisible: Int?,
        val accessVisible: Int?,
        val restrictions: Int?,
        val completion: Int?,
        val url: String?
    )

    private fun JsonObject.string(key: String): String? = get(key)?.takeIf { !it.isJsonNull }?.let { runCatching { it.asString }.getOrNull() }
    private fun JsonObject.int(key: String): Int? = get(key)?.takeIf { !it.isJsonNull }?.let { runCatching { it.asInt }.getOrNull() }
    private fun JsonObject.intOrBool(key: String): Int? = get(key)?.takeIf { !it.isJsonNull }?.let { element ->
        runCatching {
            val primitive = element.asJsonPrimitive
            if (primitive.isBoolean) if (primitive.asBoolean) 1 else 0 else primitive.asInt
        }.getOrNull()
    }
    private fun JsonObject.long(key: String): Long? = get(key)?.takeIf { !it.isJsonNull }?.let { runCatching { it.asLong }.getOrNull() }
    private fun JsonObject.bool(key: String): Boolean = get(key)?.let { runCatching { it.asBoolean }.getOrDefault(false) } ?: false
}

open class MoodleSessionException(message: String) : Exception(message)
class MoodleWebServiceException(
    message: String,
    val errorCode: String? = null,
    val functionName: String? = null
) : MoodleSessionException(message)
class MoodleSessionExpiredException(message: String) : MoodleSessionException(message)
