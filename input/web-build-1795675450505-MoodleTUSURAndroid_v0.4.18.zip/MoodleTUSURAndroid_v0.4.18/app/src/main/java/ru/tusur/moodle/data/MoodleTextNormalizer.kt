package ru.tusur.moodle.data

/** Normalizes common Moodle upload conventions without changing file extensions. */
fun normalizeMoodleDisplayName(raw: String?): String {
    var value = raw.orEmpty()
        .replace('\u00A0', ' ')
        .replace(Regex("(?<!\\d)(\\d{2})_(\\d{2})_(\\d{4})(?!\\d)"), "$1.$2.$3")
        .replace(Regex("(?<!\\d)(\\d{2})_(\\d{2})_(\\d{2})(?!\\d)"), "$1.$2.$3")
        .replace(Regex("(?<!\\d)(\\d{3,4})_(\\d{1,2})(?!\\d)"), "$1-$2")
        .replace(Regex("_+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
    // Moodle file names sometimes include punctuation separators around words.
    value = value.replace(Regex("\\s+([,;])"), "$1")
        .replace(Regex("([,;])(?=\\S)"), "$1 ")
        .trim()
    return value
}

/** Safe, readable file name for DownloadManager destinations. */
fun normalizeMoodleFileName(raw: String?): String {
    val normalized = normalizeMoodleDisplayName(raw)
        .replace(Regex("[\\\\/:*?\"<>|]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim().trim('.', ' ')
        .take(150)
    return normalized.ifBlank { "moodle-material" }
}
