package ru.tusur.moodle.data

/** Parses Moodle's external API booleans, which may arrive as JSON booleans, 0/1 or strings. */
object MoodleApiBoolean {
    fun parse(raw: String?): Boolean? = when (raw?.trim()?.lowercase()) {
        "true", "1", "yes" -> true
        "false", "0", "no" -> false
        else -> null
    }
}
