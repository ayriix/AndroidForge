package ru.tusur.moodle.data

/** A failed independent history read cannot turn an empty API result into "not started". */
object MoodleQuizAttemptSourcePolicy {
    fun mustRejectEmptyApiWhenOverviewUnavailable(apiAttemptCount: Int, overviewReadSuccessfully: Boolean): Boolean =
        apiAttemptCount == 0 && !overviewReadSuccessfully
}
