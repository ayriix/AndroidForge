package ru.tusur.study

import android.app.DownloadManager
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.widget.Toast
import kotlinx.coroutines.delay
import ru.tusur.moodle.data.normalizeMoodleDisplayName
import java.util.Date
import java.text.SimpleDateFormat
import java.util.Locale

private data class MoodleDownloadItem(
    val id: Long,
    val title: String,
    val status: Int,
    val sizeBytes: Long,
    val modifiedAt: Long,
    val localUri: Uri?,
    val mimeType: String?
)

@Composable
fun DownloadsScreen() {
    val context = LocalContext.current
    var files by remember { mutableStateOf<List<MoodleDownloadItem>>(emptyList()) }
    var removingIds by remember { mutableStateOf<Set<Long>>(emptySet()) }

    fun reload() {
        files = queryMoodleDownloads(context)
    }

    LaunchedEffect(Unit) { reload() }
    LaunchedEffect(removingIds) {
        if (removingIds.isNotEmpty()) {
            delay(360)
            files = files.filterNot { it.id in removingIds }
            removingIds = emptySet()
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Файлов: ${files.count { it.status == DownloadManager.STATUS_SUCCESSFUL }}",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            IconButton(onClick = ::reload) {
                Icon(Icons.Outlined.Refresh, contentDescription = "Обновить список файлов")
            }
        }
        Spacer(Modifier.height(8.dp))
        if (files.isEmpty()) {
            Text(
                "Нет загруженных файлов",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 16.dp)
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(files, key = { it.id }) { item ->
                    AnimatedVisibility(
                        visible = item.id !in removingIds,
                        exit = fadeOut(animationSpec = tween(320)) + shrinkVertically(animationSpec = tween(320))
                    ) {
                        Box(Modifier.fillMaxWidth()) {
                        Card(Modifier.fillMaxWidth()) {
                            Column(
                                Modifier.fillMaxWidth().padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Decorative file type marker; it no longer competes with the title.
                                Icon(
                                    Icons.Outlined.Description,
                                    contentDescription = null,
                                    modifier = Modifier.align(Alignment.Start),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    normalizeMoodleDisplayName(displayDownloadTitle(item.title)),
                                    modifier = Modifier.fillMaxWidth(),
                                    fontWeight = FontWeight.Medium
                                )
                                val metadata = buildList {
                                    if (item.sizeBytes > 0L) add(formatBytes(item.sizeBytes))
                                    if (item.modifiedAt > 0L) add(
                                        SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
                                            .format(Date(item.modifiedAt))
                                    )
                                    if (item.status != DownloadManager.STATUS_SUCCESSFUL) add(downloadStatus(item.status))
                                }.joinToString(" · ")
                                if (metadata.isNotBlank()) {
                                    Text(
                                        metadata,
                                        modifier = Modifier.fillMaxWidth(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (item.status == DownloadManager.STATUS_SUCCESSFUL) {
                                        Button(onClick = { openDownloadedItem(context, item) }) { Text("Открыть") }
                                    } else {
                                        Text(downloadStatus(item.status), style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(onClick = {
                                        val removed = runCatching {
                                            context.getSystemService(DownloadManager::class.java)?.remove(item.id) ?: 0
                                        }.getOrDefault(0)
                                        if (removed > 0) {
                                            removingIds = removingIds + item.id
                                        } else {
                                            Toast.makeText(context, "Не удалось удалить файл из папки Download.", Toast.LENGTH_SHORT).show()
                                            reload()
                                        }
                                    }) {
                                        Icon(
                                            Icons.Outlined.DeleteOutline,
                                            contentDescription = "Удалить файл",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                        if (item.id in removingIds) ParticleDissolveOverlay(item.id)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ParticleDissolveOverlay(seed: Long) {
    val progress = remember(seed) { Animatable(0f) }
    LaunchedEffect(seed) { progress.animateTo(1f, animationSpec = tween(320)) }
    val p = progress.value
    val particles = remember(seed) {
        val random = java.util.Random(seed)
        List(38) { Triple(random.nextFloat(), random.nextFloat(), random.nextFloat() * 2f + 1.5f) }
    }
    Canvas(Modifier.fillMaxSize()) {
        particles.forEachIndexed { index, particle ->
            val x0 = particle.first * size.width
            val y0 = particle.second * size.height
            val angle = (index * 0.618f) * (Math.PI.toFloat() * 2f)
            val travel = 26f + particle.third * 8f
            val x = x0 + kotlin.math.cos(angle) * travel * p
            val y = y0 - 14f * p + kotlin.math.sin(angle) * travel * p
            val alpha = (1f - p).coerceIn(0f, 1f)
            val tint = if (index % 3 == 0) Color(0xFF4053A0) else Color(0xFFB9B5C6)
            drawCircle(tint.copy(alpha = alpha), radius = particle.third * (1f - p * .55f), center = androidx.compose.ui.geometry.Offset(x, y))
        }
    }
}

private fun queryMoodleDownloads(context: Context): List<MoodleDownloadItem> {
    val manager = context.getSystemService(DownloadManager::class.java) ?: return emptyList()
    val cursor = runCatching { manager.query(DownloadManager.Query()) }.getOrNull() ?: return emptyList()
    return cursor.use { c ->
        val idCol = c.getColumnIndex(DownloadManager.COLUMN_ID)
        val uriCol = c.getColumnIndex(DownloadManager.COLUMN_URI)
        val titleCol = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
        val statusCol = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
        val sizeCol = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
        val modifiedCol = c.getColumnIndex(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)
        val localCol = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
        val mimeCol = c.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE)
        buildList {
            while (c.moveToNext()) {
                val remote = if (uriCol >= 0) c.getString(uriCol).orEmpty() else ""
                val remoteUri = runCatching { Uri.parse(remote) }.getOrNull()
                val host = remoteUri?.host.orEmpty().lowercase(Locale.ROOT)
                if (host != MOODLE_HOST && !host.endsWith(".tusur.ru")) continue
                val id = if (idCol >= 0) c.getLong(idCol) else continue
                val status = if (statusCol >= 0) c.getInt(statusCol) else DownloadManager.STATUS_FAILED
                val title = if (titleCol >= 0) c.getString(titleCol).orEmpty() else "Файл Moodle"
                val local = if (localCol >= 0) c.getString(localCol)?.let(Uri::parse) else null
                add(
                    MoodleDownloadItem(
                        id = id,
                        title = title,
                        status = status,
                        sizeBytes = if (sizeCol >= 0) c.getLong(sizeCol).coerceAtLeast(0L) else 0L,
                        modifiedAt = if (modifiedCol >= 0) c.getLong(modifiedCol) else 0L,
                        localUri = local,
                        mimeType = if (mimeCol >= 0) c.getString(mimeCol) else null
                    )
                )
            }
        }.sortedByDescending { it.modifiedAt }
    }
}

private fun openDownloadedItem(context: Context, item: MoodleDownloadItem) {
    try {
        val manager = context.getSystemService(DownloadManager::class.java)
            ?: throw IllegalStateException("Сервис загрузок Android недоступен")
        val uri = manager.getUriForDownloadedFile(item.id) ?: item.localUri
            ?: throw IllegalStateException("Файл ещё не готов к открытию")
        val name = displayDownloadTitle(item.title)
        val extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val mime = item.mimeType?.takeIf { it.isNotBlank() }
            ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            ?: "application/octet-stream"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            clipData = ClipData.newUri(context.contentResolver, name, uri)
        }
        context.startActivity(intent)
    } catch (_: android.content.ActivityNotFoundException) {
        Toast.makeText(context, "Не найдено приложение для открытия этого типа файла.", Toast.LENGTH_LONG).show()
    } catch (error: Exception) {
        Toast.makeText(context, "Не удалось открыть файл: ${error.localizedMessage ?: "ошибка"}", Toast.LENGTH_LONG).show()
    }
}

private fun displayDownloadTitle(name: String): String = name
    .substringAfterLast('/')
    .replaceFirst(Regex("^[0-9]{10,}_"), "")
    .replace(Regex("(?i)^Moodle_"), "")

private fun downloadStatus(status: Int): String = when (status) {
    DownloadManager.STATUS_PENDING -> "Ожидает загрузки"
    DownloadManager.STATUS_RUNNING -> "Загрузка…"
    DownloadManager.STATUS_PAUSED -> "Приостановлено"
    DownloadManager.STATUS_FAILED -> "Ошибка загрузки"
    else -> "Неизвестный статус"
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024L -> String.format(Locale.getDefault(), "%.1f МБ", bytes / (1024.0 * 1024.0))
    bytes >= 1024L -> String.format(Locale.getDefault(), "%.0f КБ", bytes / 1024.0)
    else -> "$bytes Б"
}
