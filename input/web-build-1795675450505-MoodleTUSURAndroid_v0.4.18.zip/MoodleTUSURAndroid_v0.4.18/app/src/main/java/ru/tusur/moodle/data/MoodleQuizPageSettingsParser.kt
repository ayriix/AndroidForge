package ru.tusur.moodle.data

/**
 * Parses the settings block shown on Moodle's authenticated mod/quiz/view.php page.
 * The parser is deliberately pure Kotlin so its behaviour can be tested without Android.
 */
object MoodleQuizPageSettingsParser {
    // Bump this whenever parsing semantics change: persisted cards with an older version retry.
    const val VERSION: Int = 10

    data class Result(
        val openTime: String?,
        val closeTime: String?,
        val timeLimit: String?,
        val allowedAttempts: String?,
        val isComplete: Boolean,
        val missingFields: List<String>
    )

    private const val OPEN_LABEL = "(?:открыто\\s+с|открыт(?:а|о)?\\s+с|открывается|дата\\s+открытия|дата\\s+начала|начало\\s+теста|доступно\\s+с|открытие|opens(?:\\s+at)?|open\\s+the\\s+quiz|available\\s+from)"
    private const val CLOSE_LABEL = "(?:закрыто\\s+с|закрыт(?:а|о)?\\s+с|закрывается|дата\\s+закрытия|дата\\s+окончания|окончание\\s+теста|срок\\s+окончания|доступно\\s+до|закрытие|closes?(?:\\s+at)?|close\\s+the\\s+quiz|available\\s+until)"
    private const val TIME_LABEL = "(?:ограничение\\s+по\\s+времени|ограничение\\s+времени|время\\s+выполнения|время\\s+на\\s+выполнение|лимит\\s+времени|временное\\s+ограничение|time\\s+limit)"
    private const val ATTEMPTS_LABEL = "(?:разрешено\\s+попыток|количество\\s+(?:разрешенных\\s+)?попыток|число\\s+попыток|максимальное\\s+количество\\s+попыток|attempts\\s+allowed|number\\s+of\\s+attempts)"

    private val allLabels = "(?:$OPEN_LABEL|$CLOSE_LABEL|$TIME_LABEL|$ATTEMPTS_LABEL)"
    private val labelBoundary = Regex("(?iu)(?:^|[\\s:])$allLabels\\s*:?")
    private val timeValuePattern = Regex(
        "(?iu)(?:без\\s+ограничения\\s+времени|неограниченное\\s+время|без\\s+лимита|no\\s+time\\s+limit|unlimited|" +
            "\\d+\\s*(?:дн(?:я|ей)?|день|сут(?:ки|ок)?|days?|час(?:а|ов)?|час|hours?|hrs?|h|ч|мин(?:ута|уты|ут)?[.]?|minutes?|mins?|сек(?:унда|унды|унд)?[.]?|seconds?|secs?)(?:\\s+\\d+\\s*(?:дн(?:я|ей)?|день|сут(?:ки|ок)?|days?|час(?:а|ов)?|час|hours?|hrs?|h|ч|мин(?:ута|уты|ут)?[.]?|minutes?|mins?|сек(?:унда|унды|унд)?[.]?|seconds?|secs?))*)"
    )
    private val attemptsValuePattern = Regex("(?iu)(?:неограниченно|не\\s+ограничено|unlimited|\\d{1,3})")

    /**
     * [hasQuizInfoBlock] may only be true after the caller confirms the authenticated quiz
     * overview page. Moodle omits rows for disabled restrictions; absence can mean no
     * restriction only when at least one actual settings row was successfully recognized.
     */
    fun parseText(rawText: String, hasQuizInfoBlock: Boolean): Result {
        val text = normalize(rawText)
        val openLabel = findLabel(text, OPEN_LABEL)
        val closeLabel = findLabel(text, CLOSE_LABEL)
        val timeLabel = findLabel(text, TIME_LABEL)
        val attemptsLabel = findLabel(text, ATTEMPTS_LABEL)

        fun valueAfter(labelMatch: MatchResult?, maxLength: Int = 360, candidateParser: (String) -> String?): String? {
            labelMatch ?: return null
            val start = labelMatch.range.last + 1
            if (start >= text.length) return null
            val tail = text.substring(start)
            val next = labelBoundary.find(tail)?.range?.first
            val candidate = (if (next == null) tail else tail.substring(0, next)).take(maxLength)
            return candidateParser(candidate)?.trim()?.takeIf { it.isNotBlank() }
        }

        val parsedOpen = valueAfter(openLabel) { candidate ->
            DATE_OR_NO_LIMIT_PATTERN.find(candidate)?.value ?: MoodleDateTimeParser.extract(candidate)
        }
        val parsedClose = valueAfter(closeLabel) { candidate ->
            DATE_OR_NO_LIMIT_PATTERN.find(candidate)?.value ?: MoodleDateTimeParser.extract(candidate)
        }
        val parsedTime = valueAfter(timeLabel) { candidate -> timeValuePattern.find(candidate)?.value }
        val parsedAttempts = valueAfter(attemptsLabel) { candidate -> attemptsValuePattern.find(candidate)?.value }

        val hasRecognizedSettingsRow = listOf(openLabel, closeLabel, timeLabel, attemptsLabel).any { it != null }
        val canInferOmittedRows = hasQuizInfoBlock && hasRecognizedSettingsRow
        val open = parsedOpen?.let(::normalizeDateRestriction)
            ?: if (canInferOmittedRows && openLabel == null) "Без ограничения по дате" else null
        val close = parsedClose?.let(::normalizeDateRestriction)
            ?: if (canInferOmittedRows && closeLabel == null) "Без ограничения по дате" else null
        val time = parsedTime?.let(::normalizeTime)
            ?: if (canInferOmittedRows && timeLabel == null) "Без ограничения времени" else null
        val attempts = parsedAttempts?.let(::normalizeAttempts)
            ?: if (canInferOmittedRows && attemptsLabel == null) "Неограниченно" else null

        val missing = buildList {
            if (open == null) add("дата открытия")
            if (close == null) add("дата закрытия")
            if (time == null) add("ограничение времени")
            if (attempts == null) add("количество попыток")
        }
        return Result(
            openTime = open,
            closeTime = close,
            timeLimit = time,
            allowedAttempts = attempts,
            isComplete = missing.isEmpty(),
            missingFields = missing
        )
    }

    private val DATE_OR_NO_LIMIT_PATTERN = Regex(
        "(?iu)(?:без\\s+ограничения\\s+по\\s+дате|без\\s+ограничений\\s+по\\s+дате|не\\s+ограничено|not\\s+set|no\\s+restriction)"
    )

    private fun findLabel(text: String, label: String): MatchResult? =
        Regex("(?iu)(?:^|[\\s:])(?:$label)\\s*:?\\s*").find(text)

    private fun normalize(raw: String): String = raw
        .replace('\u00A0', ' ')
        .replace('\u200B', ' ')
        .replace('\uFEFF', ' ')
        .replace('ё', 'е')
        .replace('Ё', 'Е')
        .replace(Regex("[\\t ]+"), " ")
        .replace(Regex(" *\\n *"), "\n")
        .replace(Regex("\\n{2,}"), "\n")
        .trim()

    private fun normalizeDateRestriction(value: String): String =
        if (value.contains("не огранич", true) || value.contains("без огранич", true) ||
            value.contains("not set", true) || value.contains("no restriction", true)
        ) "Без ограничения по дате" else MoodleDateTimeParser.extract(value) ?: value

    private fun normalizeTime(value: String): String =
        if (value.contains("без огранич", true) || value.contains("неогранич", true) ||
            value.contains("без лимита", true) || value.contains("no time", true) || value.contains("unlimited", true)
        ) "Без ограничения времени" else value

    private fun normalizeAttempts(value: String): String =
        if (value.contains("неогранич", true) || value.contains("не огранич", true) || value.contains("unlimited", true)) {
            "Неограниченно"
        } else Regex("\\d+").find(value)?.value ?: value
}
