package ru.tusur.study

import android.content.Context
import android.graphics.Color
import android.webkit.WebView
import android.webkit.WebViewClient
import android.text.Html
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.ExperimentalActivityApi
import androidx.activity.compose.PredictiveBackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Grade
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import androidx.compose.ui.Alignment
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import ru.tusur.moodle.data.MoodleCalendarEvent
import ru.tusur.moodle.data.MoodleCourse
import ru.tusur.moodle.data.MoodleCourseSnapshot
import ru.tusur.moodle.data.MoodleGradeItem
import ru.tusur.moodle.data.MoodleModule
import ru.tusur.moodle.data.MoodleQuiz
import ru.tusur.moodle.data.MoodleQuizAttempt
import com.google.gson.JsonParser
import ru.tusur.moodle.data.MoodleQuizProgressState
import ru.tusur.moodle.data.resolveMoodleQuizProgress
import ru.tusur.moodle.data.MoodleSearchModule
import ru.tusur.moodle.data.normalizeMoodleDisplayName
import ru.tusur.moodle.data.cleanMoodleElapsed
import ru.tusur.moodle.data.deriveMoodleElapsed
import ru.tusur.moodle.data.deriveMoodleAttemptCompletedTime
import ru.tusur.moodle.data.moodleAttemptSortOrder
import ru.tusur.moodle.data.isMoodleDateWindowClosed
import ru.tusur.moodle.data.isMoodleFinishedAttempt
import ru.tusur.study.ui.CourseTab
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val viewModel: MoodleViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MoodleSyncScheduler.cancel(this)
        setContent {
            val state by viewModel.state.collectAsState()
            TUSURTheme {
                TUSURStudyApp(state = state, viewModel = viewModel, appContext = this@MainActivity)
            }
        }
    }
}

private enum class MainTab(val title: String) {
    HOME("Курсы"), COURSES("Курсы"), SEARCH("Поиск"), SETTINGS("Настройки")
}

@OptIn(ExperimentalActivityApi::class)
@Composable
private fun TUSURStudyApp(state: MoodleAppState, viewModel: MoodleViewModel, appContext: Context) {
    var selectedTab by rememberSaveable { mutableStateOf(MainTab.COURSES) }
    var courseTab by rememberSaveable { mutableStateOf(CourseTab.MATERIALS) }
    var returnCourseTab by rememberSaveable { mutableStateOf(CourseTab.MATERIALS) }
    var onlineUrl by rememberSaveable { mutableStateOf<String?>(null) }
    val searchScrollState = rememberScrollState()
    var searchQuery by rememberSaveable { mutableStateOf("") }
    val openCourseMoodle: (String) -> Unit = { url ->
        returnCourseTab = courseTab
        onlineUrl = url
        courseTab = CourseTab.ONLINE
    }
    var browserUrl by rememberSaveable { mutableStateOf<String?>(null) }
    var nativeLoginScreen by rememberSaveable { mutableStateOf(false) }
    var showDownloads by rememberSaveable { mutableStateOf(false) }
    var selectedQuizKey by rememberSaveable { mutableStateOf<String?>(null) }
    val snapshot = state.courseSnapshot
    val selectedQuiz = snapshot?.quizzes?.firstOrNull { quiz ->
        quiz.cmid == selectedQuizKey || (selectedQuizKey == "name:${quiz.quizName}")
    }
    // When a WebView route is visible, its own PredictiveBackHandler is the sole owner of
    // edge gestures: it first navigates WebView history and only then closes the in-app page.
    // This root handler is limited to native-only routes to avoid competing dispatcher callbacks.
    val webViewRouteVisible = browserUrl != null ||
        (snapshot != null && courseTab == CourseTab.ONLINE)
    PredictiveBackHandler(enabled = !webViewRouteVisible && (state.quizRunner != null || nativeLoginScreen || showDownloads || selectedQuiz != null || snapshot != null)) { progress ->
        progress.collect { /* native screens do not need a transition preview */ }
        when {
            state.quizRunner != null -> viewModel.closeQuizRunner()
            nativeLoginScreen -> nativeLoginScreen = false
            showDownloads -> showDownloads = false
            selectedQuiz != null -> selectedQuizKey = null
            snapshot != null -> {
                selectedQuizKey = null
                viewModel.closeCourse()
            }
        }
    }
    LaunchedEffect(snapshot?.course?.courseId, snapshot?.quizzes?.size, courseTab) {
        if (snapshot != null && courseTab == CourseTab.QUIZZES && snapshot.quizzes.isNotEmpty()) {
            viewModel.loadQuizDetails(snapshot.course.courseId)
            viewModel.loadAttempts(snapshot.course.courseId, forceRefresh = true)
        } else if (snapshot != null && courseTab == CourseTab.ATTEMPTS) {
            viewModel.loadAttempts(snapshot.course.courseId, forceRefresh = true)
        }
    }
    val showNavigation = state.quizRunner == null && !nativeLoginScreen && !showDownloads && browserUrl == null && snapshot == null
    val bottomStatus = when {
        !state.message.isNullOrBlank() -> state.message
        !state.notice.isNullOrBlank() -> state.notice
        state.isConnecting || state.isLoadingCourse || state.isSearching || state.isLoadingAttempts || state.isLoadingQuizDetails ->
            state.syncProgress ?: when {
                state.isLoadingAttempts -> "Загрузка истории попыток…"
                state.isLoadingQuizDetails -> "Загрузка параметров тестов…"
                state.isLoadingCourse -> "Загрузка курса…"
                state.isSearching -> "Поиск…"
                else -> "Обновление данных…"
            }
        else -> null
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Column {
                if (!bottomStatus.isNullOrBlank()) {
                    BottomStatusStrip(
                        text = bottomStatus,
                        isError = !state.message.isNullOrBlank() && !state.isConnecting && !state.isLoadingCourse && !state.isSearching && !state.isLoadingAttempts,
                        showProgress = state.isConnecting || state.isLoadingCourse || state.isSearching || state.isLoadingAttempts || state.isLoadingQuizDetails,
                        onDismiss = viewModel::clearMessage
                    )
                }
                if (showNavigation) {
                    NavigationBar {
                        MainTab.entries.filter { it != MainTab.HOME }.forEach { tab ->
                            val icon = when (tab) {
                                MainTab.HOME -> Icons.Outlined.School
                                MainTab.COURSES -> Icons.Outlined.School
                                MainTab.SEARCH -> Icons.Outlined.Search
                                MainTab.SETTINGS -> Icons.Outlined.Settings
                            }
                            NavigationBarItem(
                                selected = selectedTab == tab,
                                onClick = {
                                    viewModel.closeCourse()
                                    selectedQuizKey = null
                                    courseTab = CourseTab.MATERIALS
                                    onlineUrl = null
                                    selectedTab = tab
                                },
                                icon = { androidx.compose.material3.Icon(icon, contentDescription = null) },
                                label = { Text(tab.title) }
                            )
                        }
                    }
                }
            }
        }
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
        ) {
            if (state.quizRunner != null) {
                val runner = state.quizRunner
                HeaderBar(
                    title = normalizeMoodleDisplayName(runner.quizName),
                    titleMaxLines = 2,
                    showBack = true,
                    onBack = viewModel::closeQuizRunner,
                    onRefresh = {},
                    isRefreshing = runner.isLoading || runner.isSubmitting,
                    showRefresh = false
                )
                QuizRunnerScreen(
                    runner = runner,
                    moodleBaseUrl = state.moodleBaseUrl,
                    onAdvance = viewModel::advanceNativeQuiz,
                    onSave = viewModel::saveNativeQuizResponses,
                    onReturnToQuestions = viewModel::returnToNativeQuizQuestions,
                    onFinish = viewModel::finishNativeQuiz,
                    onClose = viewModel::closeQuizRunner
                )
            } else if (nativeLoginScreen) {
                HeaderBar(
                    title = "Вход в Moodle",
                    showBack = true,
                    onBack = { nativeLoginScreen = false },
                    onRefresh = {},
                    isRefreshing = state.isAuthenticating,
                    showRefresh = false
                )
                MoodleNativeLoginScreen(
                    isLoading = state.isAuthenticating,
                    onSubmit = { username, password ->
                        viewModel.loginWithCredentials(username, password) { nativeLoginScreen = false }
                    }
                )
            } else if (browserUrl != null) {
                MoodleWebViewScreen(
                    startUrl = browserUrl!!,
                    onClose = { browserUrl = null },
                    onSessionReady = viewModel::onMoodleSessionCaptured
                )
            } else if (showDownloads) {
                HeaderBar(
                    title = "Загруженные файлы",
                    showBack = true,
                    onBack = { showDownloads = false },
                    onRefresh = {},
                    isRefreshing = false,
                    showRefresh = false
                )
                DownloadsScreen()
            } else {
                if (!(snapshot != null && courseTab == CourseTab.ONLINE)) {
                    HeaderBar(
                        title = when {
                            selectedQuiz != null -> normalizeMoodleDisplayName(selectedQuiz.quizName)
                            snapshot == null -> "Moodle.TUSUR"
                            else -> normalizeMoodleDisplayName(snapshot.course.name)
                        },
                        subtitle = null,
                        titleMaxLines = if (snapshot != null) 2 else 1,
                        showBack = selectedQuiz != null || (snapshot != null && courseTab != CourseTab.ONLINE),
                        onBack = {
                            if (selectedQuiz != null) selectedQuizKey = null
                            else {
                                selectedQuizKey = null
                                viewModel.closeCourse()
                            }
                        },
                        onRefresh = {
                            if (snapshot != null && selectedQuiz != null) {
                                viewModel.loadQuizDetails(snapshot.course.courseId, forceRefresh = true)
                                viewModel.loadAttempts(snapshot.course.courseId, forceRefresh = true)
                            } else if (snapshot != null && courseTab == CourseTab.ATTEMPTS) {
                                viewModel.loadAttempts(snapshot.course.courseId, forceRefresh = true)
                            } else if (snapshot != null && courseTab == CourseTab.QUIZZES) {
                                viewModel.loadQuizDetails(snapshot.course.courseId, forceRefresh = true)
                                viewModel.loadAttempts(snapshot.course.courseId, forceRefresh = true)
                            } else if (snapshot != null) viewModel.openCourse(snapshot.course.courseId, forceRefreshCards = true)
                            else viewModel.refreshCourseList()
                        },
                        isRefreshing = state.isConnecting || state.isLoadingCourse || state.isLoadingAttempts || state.isLoadingQuizDetails,
                        showRefresh = courseTab != CourseTab.ONLINE
                    )
                }

                when {
                    snapshot != null && selectedQuiz != null && courseTab != CourseTab.ONLINE -> QuizActivityScreen(
                        quiz = selectedQuiz,
                        attempts = snapshot.attempts.filter { attempt ->
                            if (!selectedQuiz.cmid.isNullOrBlank()) attempt.cmid == selectedQuiz.cmid
                            else attempt.quizName.equals(selectedQuiz.quizName, ignoreCase = true)
                        },
                        calendarEvents = snapshot.calendar,
                        isLoadingAttempts = state.isLoadingAttempts,
                        isLoadingQuizDetails = state.isLoadingQuizDetails,
                        attemptsLoaded = snapshot.attemptsLoaded,
                        onStartQuiz = { viewModel.openNativeQuiz(selectedQuiz) },
                        onContinueAttempt = { id -> viewModel.openNativeQuiz(selectedQuiz, attemptId = id) },
                        onReviewAttempt = { id -> viewModel.openNativeQuiz(selectedQuiz, attemptId = id, review = true) }
                    )
                    snapshot != null -> CourseDetailScreen(
                        snapshot = snapshot,
                        selectedTab = courseTab,
                        onSelectTab = { tab ->
                            if (tab == CourseTab.ONLINE) returnCourseTab = courseTab
                            courseTab = tab
                        },
                        onOpenMoodle = openCourseMoodle,
                        onOpenQuiz = { quiz ->
                            selectedQuizKey = quiz.cmid?.takeIf { it.isNotBlank() } ?: "name:${quiz.quizName}"
                        },
                        onOpenModule = { module ->
                            if (module.type.equals("resource", true) || module.modname.equals("resource", true) || module.modname.equals("Файл", true)) {
                                viewModel.resolveResourceFileUrl(module) { url ->
                                    val target = resolveMoodleTarget(url, state.moodleBaseUrl, module.courseId)
                                    val targetUri = Uri.parse(target)
                                    if (targetUri.path?.contains("/pluginfile.php", true) == true || targetUri.getQueryParameter("forcedownload") == "1") {
                                        downloadMoodleResource(appContext, target)
                                    } else {
                                        // If resolution failed, open the Moodle resource wrapper; its eventual file link is intercepted.
                                        openCourseMoodle(target)
                                    }
                                }
                            } else {
                                val target = module.detailsUrl?.takeIf { it.isNotBlank() } ?: module.url.orEmpty()
                                openCourseMoodle(resolveMoodleTarget(target, state.moodleBaseUrl, module.courseId))
                            }
                        },
                        moodleBaseUrl = state.moodleBaseUrl,
                        onlineUrl = onlineUrl,
                        onClearOnlineUrl = { onlineUrl = null },
                        returnTab = returnCourseTab,
                        onSessionReady = viewModel::onMoodleSessionCaptured,
                        onQuizMetadata = { cmid, quizName, pageText, hasInfo ->
                            viewModel.saveQuizPageMetadata(snapshot.course.courseId, cmid, quizName, pageText, hasInfo)
                        },
                        isLoadingAttempts = state.isLoadingAttempts,
                        isLoadingQuizDetails = state.isLoadingQuizDetails
                    )
                    else -> when (selectedTab) {
                        MainTab.HOME, MainTab.COURSES -> CoursesScreen(state, onOpenCourse = {
                            selectedQuizKey = null
                            viewModel.openCourse(it)
                        })
                        MainTab.SEARCH -> SearchScreen(
                            state = state,
                            onSearch = viewModel::search,
                            onOpenModule = { item ->
                                val module = MoodleModule(
                                    courseId = item.courseId,
                                    cmid = item.cmid,
                                    name = item.name,
                                    type = item.type,
                                    modname = item.modname,
                                    url = item.url,
                                    visible = item.visible,
                                    uservisible = item.uservisible,
                                    accessvisible = item.accessvisible,
                                    detailsUrl = item.detailsUrl ?: item.url,
                                    fileLinksJson = item.fileLinksJson
                                )
                                if (module.type.equals("resource", true) || module.modname.equals("resource", true) || module.modname.equals("Файл", true)) {
                                    viewModel.resolveResourceFileUrl(module) { url ->
                                        browserUrl = resolveMoodleTarget(url, state.moodleBaseUrl, module.courseId)
                                    }
                                } else {
                                    browserUrl = resolveMoodleTarget(module.detailsUrl ?: module.url, state.moodleBaseUrl, module.courseId)
                                }
                            },
                            scrollState = searchScrollState,
                            query = searchQuery,
                            onQueryChange = { searchQuery = it; if (it.trim().length < 2) viewModel.search(it) }
                        )
                        MainTab.SETTINGS -> SettingsScreen(
                            state = state,
                            onLogin = { nativeLoginScreen = true },
                            onSync = viewModel::syncAllCourses,
                            onLogout = viewModel::logout,
                            onOpenDownloads = { showDownloads = true }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomStatusStrip(
    text: String,
    isError: Boolean,
    showProgress: Boolean,
    onDismiss: () -> Unit
) {
    val background = when {
        isError -> MaterialTheme.colorScheme.errorContainer
        showProgress -> MaterialTheme.colorScheme.surfaceVariant
        else -> MaterialTheme.colorScheme.inverseSurface
    }
    val foreground = when {
        isError -> MaterialTheme.colorScheme.onErrorContainer
        showProgress -> MaterialTheme.colorScheme.onSurfaceVariant
        else -> MaterialTheme.colorScheme.inverseOnSurface
    }
    Surface(color = background, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(42.dp).padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (showProgress) CircularProgressIndicator(modifier = Modifier.size(15.dp), strokeWidth = 2.dp)
            Text(text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelMedium, color = foreground)
            if (isError) IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                androidx.compose.material3.Icon(Icons.Outlined.Close, contentDescription = "Закрыть", tint = foreground)
            }
        }
    }
}

@Composable
private fun HeaderBar(
    title: String,
    subtitle: String? = null,
    titleMaxLines: Int = 1,
    showBack: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    isRefreshing: Boolean,
    showRefresh: Boolean = true
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showBack) {
            IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                androidx.compose.material3.Icon(Icons.Outlined.ChevronLeft, contentDescription = "Назад")
            }
        }
        Column(modifier = Modifier.weight(1f).padding(start = if (showBack) 2.dp else 10.dp, end = 4.dp)) {
            Text(
                title,
                style = if (titleMaxLines > 1) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                maxLines = titleMaxLines,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrBlank()) {
                Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (showRefresh) {
            IconButton(onClick = onRefresh, enabled = !isRefreshing, modifier = Modifier.size(44.dp)) {
                androidx.compose.material3.Icon(Icons.Outlined.Refresh, contentDescription = "Обновить")
            }
        }
    }
}

@Composable
private fun CoursesScreen(state: MoodleAppState, onOpenCourse: (String) -> Unit) {
    if (state.courses.isEmpty()) {
        EmptyState(Icons.Outlined.School, "Список курсов пуст", "Войдите в Moodle, чтобы получить список курсов.")
    } else {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(state.courses, key = { it.courseId }) { course -> CourseCard(course) { onOpenCourse(course.courseId) } }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CourseCard(course: MoodleCourse, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 15.dp)) {
            Text(normalizeMoodleDisplayName(course.name), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                maxLines = 3, overflow = TextOverflow.Ellipsis)
            val details = buildList {
                (course.moduleCountActual ?: course.moduleCount)?.let { add("Материалов: $it") }
                course.sectionCountActual?.takeIf { it > 0 }?.let { add("Разделов: $it") }
                course.quizCount?.let { add("Тестов: $it") }
                course.gradeCount?.let { add("Оценок: $it") }
                course.userVisibleCount?.let { add("Доступно: $it") }
            }
            if (details.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                if (details.size <= 3) {
                    // A small fixed set stays on one line and can be swiped horizontally.
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        details.forEach { detail -> CourseStatChip(detail) }
                    }
                } else {
                    // Future statistics wrap naturally instead of widening the course card.
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        details.forEach { detail -> CourseStatChip(detail) }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
                Text("Открыть")
            }
        }
    }
}

@Composable
private fun CourseStatChip(detail: String) {
    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(8.dp)) {
        Text(
            detail,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
    }
}

@Composable
private fun SearchScreen(
    state: MoodleAppState,
    onSearch: (String) -> Unit,
    onOpenModule: (MoodleSearchModule) -> Unit,
    scrollState: androidx.compose.foundation.ScrollState,
    query: String,
    onQueryChange: (String) -> Unit
) {
    LaunchedEffect(query) {
        if (query.trim().length >= 2) {
            delay(420)
            onSearch(query.trim())
        }
    }
    Column(modifier = Modifier.fillMaxSize().verticalScroll(scrollState).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Поиск", maxLines = 1) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )
        }
        val result = state.searchResults
        if (result != null) {
            Spacer(Modifier.height(18.dp))
            val searchMaterials = result.modules.filterNot { isSdoLink(it.url) || isSdoLink(it.name) || isQuizModule(it) }
            SectionHeading("Материалы", searchMaterials.size.toString())
            searchMaterials.forEach { item ->
                Card(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(normalizeMoodleDisplayName(item.name), fontWeight = FontWeight.SemiBold)
                        Text("${normalizeMoodleDisplayName(item.courseName ?: "Курс")} · ${friendlyModuleType(item.modname ?: item.type)}",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (item.visible == 0 || item.uservisible == 0 || item.accessvisible == 0 || item.url.isNullOrBlank()) {
                            UnavailableButton(Modifier.fillMaxWidth())
                        } else {
                            Button(onClick = { onOpenModule(item) }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (item.type.equals("resource", true) || item.modname.equals("resource", true) || item.modname.equals("Файл", true)) "Открыть файл" else "Открыть")
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            SectionHeading("Оценки", result.grades.size.toString())
            result.grades.forEach { grade ->
                GradeCard(
                    name = grade.name,
                    score = grade.score,
                    maxScore = grade.maxScore,
                    percent = grade.percent
                )
            }
            if (searchMaterials.isEmpty() && result.grades.isEmpty()) {
                EmptyState(Icons.Outlined.Search, "Ничего не найдено", "Попробуйте изменить поисковый запрос.")
            }
        }
    }
}

@Composable
private fun MoodleNativeLoginScreen(
    isLoading: Boolean,
    onSubmit: (String, String) -> Unit
) {
    var username by rememberSaveable { mutableStateOf("") }
    // Do not put the password into SavedStateHandle / process-restored UI state.
    var password by remember { mutableStateOf("") }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Учётная запись ТУСУР", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Вход выполняется напрямую на сервере Moodle по защищённому соединению. Пароль не сохраняется в приложении.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            enabled = !isLoading,
            label = { Text("Логин") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            enabled = !isLoading,
            label = { Text("Пароль") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                val submittedPassword = password
                password = ""
                onSubmit(username.trim(), submittedPassword)
            },
            enabled = !isLoading && username.isNotBlank() && password.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (isLoading) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            else Text("Войти")
        }
    }
}

@Composable
private fun SettingsScreen(
    state: MoodleAppState,
    onLogin: () -> Unit,
    onSync: () -> Unit,
    onLogout: () -> Unit,
    onOpenDownloads: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Icon(
                    if (state.isConnected) Icons.Outlined.CheckCircle else Icons.Outlined.CloudOff,
                    contentDescription = null,
                    tint = if (state.isConnected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (state.isConnected) "Moodle доступен" else if (state.hasSavedSession) "Сессия сохранена" else "Требуется вход",
                        fontWeight = FontWeight.SemiBold)
                    Text(state.moodleBaseUrl.removePrefix("https://").trimEnd('/'),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    state.cacheSavedAt?.let {
                        Text("Кэш обновлён ${formatTimestamp(it / 1000)}", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Button(onClick = onLogin, modifier = Modifier.fillMaxWidth()) {
            Text(if (state.hasSavedSession) "Переподключить Moodle" else "Войти в Moodle")
        }
        OutlinedButton(onClick = onSync, enabled = state.hasSavedSession && !state.isConnecting,
            modifier = Modifier.fillMaxWidth()) {
            Text(if (state.isConnecting) "Обновление…" else "Обновить данные")
        }
        OutlinedButton(onClick = onOpenDownloads, modifier = Modifier.fillMaxWidth()) {
            Text("Загруженные файлы")
        }
        if (state.hasSavedSession) {
            TextButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("Выйти из аккаунта") }
        }
    }
}

@Composable
private fun CourseDetailScreen(
    snapshot: MoodleCourseSnapshot,
    selectedTab: CourseTab,
    onSelectTab: (CourseTab) -> Unit,
    moodleBaseUrl: String,
    onlineUrl: String?,
    onClearOnlineUrl: () -> Unit,
    onOpenMoodle: (String) -> Unit,
    onOpenQuiz: (MoodleQuiz) -> Unit,
    onOpenModule: (MoodleModule) -> Unit,
    returnTab: CourseTab,
    onSessionReady: (String, String, String, String?) -> Unit,
    onQuizMetadata: (String, String?, String, Boolean) -> Unit,
    isLoadingAttempts: Boolean,
    isLoadingQuizDetails: Boolean
) {
    // Hoisted above the tab switch: the position survives opening a Moodle activity and returning.
    val materialsScrollState = rememberLazyListState()
    val practiceScrollState = rememberLazyListState()
    val quizzesScrollState = rememberLazyListState()
    val gradesScrollState = rememberLazyListState()
    val attemptsScrollState = rememberLazyListState()
    val calendarScrollState = rememberLazyListState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val sectionPrefs = remember(snapshot.course.courseId) {
        context.getSharedPreferences("collapsed_course_sections", android.content.Context.MODE_PRIVATE)
    }
    var collapsedSectionIds by remember(snapshot.course.courseId) {
        mutableStateOf(sectionPrefs.getStringSet(snapshot.course.courseId, emptySet())?.toSet() ?: emptySet())
    }
    Column(modifier = Modifier.fillMaxSize()) {
        if (selectedTab != CourseTab.ONLINE) {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CourseTab.entries.filter { it != CourseTab.ONLINE }.forEach { tab ->
                    AssistChip(
                        onClick = { onSelectTab(tab) },
                        label = { Text(tab.label) },
                        leadingIcon = if (selectedTab == tab) ({
                            androidx.compose.material3.Icon(Icons.Outlined.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        }) else null
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
        }
        when (selectedTab) {
            CourseTab.MATERIALS -> MaterialsScreen(
                snapshot = snapshot,
                moodleBaseUrl = moodleBaseUrl,
                onOpenMoodle = onOpenMoodle,
                onOpenModule = onOpenModule,
                scrollState = materialsScrollState,
                collapsedSections = collapsedSectionIds,
                onToggleSection = { sectionId ->
                    collapsedSectionIds = if (sectionId in collapsedSectionIds) collapsedSectionIds - sectionId
                    else collapsedSectionIds + sectionId
                    sectionPrefs.edit().putStringSet(snapshot.course.courseId, collapsedSectionIds).apply()
                }
            )
            CourseTab.PRACTICE -> PracticeScreen(
                snapshot = snapshot,
                moodleBaseUrl = moodleBaseUrl,
                onOpenMoodle = onOpenMoodle,
                onOpenModule = onOpenModule,
                scrollState = practiceScrollState,
                collapsedSections = collapsedSectionIds,
                onToggleSection = { sectionId ->
                    collapsedSectionIds = if (sectionId in collapsedSectionIds) collapsedSectionIds - sectionId
                    else collapsedSectionIds + sectionId
                    sectionPrefs.edit().putStringSet(snapshot.course.courseId, collapsedSectionIds).apply()
                }
            )
            CourseTab.QUIZZES -> QuizzesScreen(
                quizzes = snapshot.quizzes,
                calendarEvents = snapshot.calendar,
                attempts = snapshot.attempts,
                attemptsLoaded = snapshot.attemptsLoaded,
                onOpenQuiz = onOpenQuiz,
                scrollState = quizzesScrollState,
                isLoadingQuizDetails = isLoadingQuizDetails
            )
            CourseTab.GRADES -> GradesScreen(snapshot.grades.data, gradesScrollState)
            CourseTab.ATTEMPTS -> AttemptsScreen(snapshot.attempts, snapshot.quizzes, isLoadingAttempts, attemptsScrollState)
            CourseTab.CALENDAR -> CalendarScreen(
                events = snapshot.calendar,
                moodleBaseUrl = moodleBaseUrl,
                courseId = snapshot.course.courseId,
                onOpenMoodle = onOpenMoodle,
                scrollState = calendarScrollState
            )
            CourseTab.ONLINE -> MoodleWebViewScreen(
                startUrl = onlineUrl ?: buildCourseMoodleUrl(moodleBaseUrl, snapshot.course.courseId),
                onClose = {
                    // onlineUrl is state owned by TUSURStudyApp, not this composable's read-only parameter.
                    onClearOnlineUrl()
                    onSelectTab(returnTab)
                },
                onSessionReady = onSessionReady,
                onQuizMetadata = onQuizMetadata
            )
        }
    }
}

@Composable
private fun MaterialsScreen(
    snapshot: MoodleCourseSnapshot,
    moodleBaseUrl: String,
    onOpenMoodle: (String) -> Unit,
    onOpenModule: (MoodleModule) -> Unit,
    scrollState: androidx.compose.foundation.lazy.LazyListState,
    collapsedSections: Set<String>,
    onToggleSection: (String) -> Unit
) {
    val modules = snapshot.modules.filter { module ->
        !isQuizModule(module) && !isPracticeModule(module) &&
            !isSdoLink(module.url) && !isSdoLink(module.name) && !isSdoLink(module.courseCardText)
    }
    ModuleSectionsScreen(
        modules = modules,
        sections = snapshot.sections,
        emptyTitle = "Материалы не найдены",
        emptyDescription = "Здесь появятся лекции, файлы, ссылки и другие учебные материалы.",
        moodleBaseUrl = moodleBaseUrl,
        onOpenMoodle = onOpenMoodle,
        onOpenModule = onOpenModule,
        scrollState = scrollState,
        collapsedSections = collapsedSections,
        onToggleSection = onToggleSection
    )
}

@Composable
private fun PracticeScreen(
    snapshot: MoodleCourseSnapshot,
    moodleBaseUrl: String,
    onOpenMoodle: (String) -> Unit,
    onOpenModule: (MoodleModule) -> Unit,
    scrollState: androidx.compose.foundation.lazy.LazyListState,
    collapsedSections: Set<String>,
    onToggleSection: (String) -> Unit
) {
    val modules = snapshot.modules.filter { module ->
        isPracticeModule(module) && !isQuizModule(module) &&
            !isSdoLink(module.url) && !isSdoLink(module.name) && !isSdoLink(module.courseCardText)
    }
    ModuleSectionsScreen(
        modules = modules,
        sections = snapshot.sections,
        emptyTitle = "Практических заданий нет",
        emptyDescription = "Здесь собраны материалы с названиями «Практическое занятие» и «Практическое задание».",
        moodleBaseUrl = moodleBaseUrl,
        onOpenMoodle = onOpenMoodle,
        onOpenModule = onOpenModule,
        scrollState = scrollState,
        collapsedSections = collapsedSections,
        onToggleSection = onToggleSection
    )
}

@Composable
private fun ModuleSectionsScreen(
    modules: List<MoodleModule>,
    sections: List<ru.tusur.moodle.data.MoodleSection>,
    emptyTitle: String,
    emptyDescription: String,
    moodleBaseUrl: String,
    onOpenMoodle: (String) -> Unit,
    onOpenModule: (MoodleModule) -> Unit,
    scrollState: androidx.compose.foundation.lazy.LazyListState,
    collapsedSections: Set<String>,
    onToggleSection: (String) -> Unit
) {
    val grouped = modules.groupBy { it.sectionId ?: "_unassigned" }
    val orderedSections = sections.sortedBy { it.number ?: Int.MAX_VALUE }
    val knownIds = orderedSections.map { it.sectionId }.toSet()
    val extraKeys = grouped.keys.filter { it !in knownIds }
    if (modules.isEmpty()) {
        EmptyState(Icons.Outlined.MenuBook, emptyTitle, emptyDescription)
        return
    }
    LazyColumn(
        state = scrollState,
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        orderedSections.forEach { section ->
            val sectionModules = grouped[section.sectionId].orEmpty()
            if (sectionModules.isNotEmpty()) {
                val key = section.sectionId
                val collapsed = key in collapsedSections
                item(key = "section_$key") {
                    SectionGroupHeader(
                        title = normalizeMoodleDisplayName(sectionDisplayTitle(section)),
                        count = sectionModules.size,
                        collapsed = collapsed,
                        onToggle = { onToggleSection(key) }
                    )
                }
                if (!collapsed) {
                    items(sectionModules, key = { "module_${it.cmid}" }) { module ->
                        ModuleCard(module, moodleBaseUrl, onOpenMoodle, onOpenModule)
                    }
                }
            }
        }
        extraKeys.forEach { sectionKey ->
            val sectionModules = grouped[sectionKey].orEmpty()
            val collapsed = sectionKey in collapsedSections
            item(key = "extra_$sectionKey") {
                SectionGroupHeader("Другие материалы", sectionModules.size, collapsed) { onToggleSection(sectionKey) }
            }
            if (!collapsed) {
                items(sectionModules, key = { "module_${it.cmid}" }) { module ->
                    ModuleCard(module, moodleBaseUrl, onOpenMoodle, onOpenModule)
                }
            }
        }
    }
}

private fun isQuizTypeLabel(type: String?): Boolean =
    type.orEmpty().equals("quiz", true) || type.orEmpty().equals("Тест", true)

private fun isQuizModule(module: MoodleModule): Boolean =
    isQuizModuleFields(module.type, module.modname, module.url)

private fun isQuizModule(module: MoodleSearchModule): Boolean =
    isQuizModuleFields(module.type, module.modname, module.url)

private fun isQuizModuleFields(type: String?, modname: String?, url: String?): Boolean =
    isQuizTypeLabel(type) || isQuizTypeLabel(modname) ||
        url.orEmpty().contains("/mod/quiz/", ignoreCase = true)

private fun isPracticeModule(module: MoodleModule): Boolean {
    val name = normalizeMoodleDisplayName(module.name).lowercase(Locale.ROOT).replace('ё', 'е')
    return Regex("(?iu)практическ[а-яё]*\\s+(?:заняти[а-яё]*|задани[а-яё]*)|практикум").containsMatchIn(name)
}

@Composable
private fun SectionGroupHeader(title: String, count: Int, collapsed: Boolean, onToggle: () -> Unit) {
    val isDateHeading = Regex(
        "(?i)\\b\\d{1,2}\\s+(?:января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\\b"
    ).containsMatchIn(title)
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onToggle),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    title,
                    style = if (isDateHeading) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(if (count == 1) "1 материал" else "$count материалов",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onToggle) {
                androidx.compose.material3.Icon(
                    if (collapsed) Icons.Outlined.KeyboardArrowDown else Icons.Outlined.KeyboardArrowUp,
                    contentDescription = if (collapsed) "Развернуть раздел" else "Свернуть раздел"
                )
            }
        }
    }
}

private fun sectionDisplayTitle(section: ru.tusur.moodle.data.MoodleSection): String {
    val name = htmlToText(section.name).orEmpty().ifBlank { "Раздел" }
    val weekPrefix = Regex("(?i)^неделя\\s+\\d+\\s*[·:—-]\\s*")
    val dateOnly = name.replace(weekPrefix, "").trim()
    return dateOnly.ifBlank { name }
}

@Composable
private fun ModuleCard(
    module: MoodleModule,
    moodleBaseUrl: String,
    onOpenMoodle: (String) -> Unit,
    onOpenModule: (MoodleModule) -> Unit
) {
    val urls = remember(module.fileLinksJson) { extractUrls(module.fileLinksJson) }
    val activityUrl = module.detailsUrl?.takeIf { it.isNotBlank() } ?: module.url?.takeIf { it.isNotBlank() }
    val restricted = module.visible == 0 || module.uservisible == 0 || module.accessvisible == 0
    val isResource = module.type.equals("resource", true) || module.modname.equals("resource", true) || module.modname.equals("Файл", true)
    val hasNoTarget = activityUrl == null && !(isResource && urls.isNotEmpty())
    val typeLabel = friendlyModuleType(module.modname ?: module.type)
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(normalizeMoodleDisplayName(module.name), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(typeLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            when {
                restricted || hasNoTarget -> UnavailableButton(Modifier.fillMaxWidth())
                isResource && urls.isNotEmpty() -> urls.take(3).forEachIndexed { index, url ->
                    Button(
                        onClick = { onOpenMoodle(resolveMoodleTarget(url, moodleBaseUrl, module.courseId)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        androidx.compose.material3.Icon(Icons.Outlined.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (urls.size == 1) "Открыть файл" else "Открыть файл ${index + 1}")
                    }
                }
                isResource -> Button(onClick = { onOpenModule(module) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Открыть файл")
                }
                activityUrl != null -> Button(
                    onClick = { onOpenMoodle(resolveMoodleTarget(activityUrl, moodleBaseUrl, module.courseId)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Открыть") }
            }
        }
    }
}

@Composable
private fun UnavailableButton(modifier: Modifier = Modifier) {
    Button(
        onClick = {},
        enabled = false,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            disabledContainerColor = MaterialTheme.colorScheme.error,
            disabledContentColor = MaterialTheme.colorScheme.onError
        )
    ) { Text("Недоступен") }
}

private fun friendlyModuleType(raw: String?): String {
    val value = raw?.trim().orEmpty()
    return when (value.lowercase(Locale.ROOT)) {
        "quiz" -> "Тест"
        "resource" -> "Файл"
        "url" -> "Ссылка"
        "assign" -> "Задание"
        "forum" -> "Форум"
        "page" -> "Страница"
        "book" -> "Книга"
        "folder" -> "Папка"
        "bigbluebuttonbn" -> "Видеоконференция"
        "choice" -> "Опрос"
        "label" -> "Материал"
        else -> value.takeIf { it.isNotBlank() } ?: "Учебный материал"
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun QuizzesScreen(
    quizzes: List<MoodleQuiz>,
    calendarEvents: List<MoodleCalendarEvent>,
    attempts: List<MoodleQuizAttempt>,
    attemptsLoaded: Boolean,
    onOpenQuiz: (MoodleQuiz) -> Unit,
    scrollState: androidx.compose.foundation.lazy.LazyListState,
    isLoadingQuizDetails: Boolean
) {
    if (quizzes.isEmpty()) {
        EmptyState(Icons.Outlined.Description, "Тестов нет", "В этом курсе не найдено тестов.")
        return
    }
    LazyColumn(state = scrollState, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(quizzes, key = { "quiz_${it.cmid ?: it.quizName}" }) { quiz ->
            val schedule = quizScheduleTimes(quiz, calendarEvents)
            val quizAttempts = attempts.filter { attempt ->
                if (!quiz.cmid.isNullOrBlank()) attempt.cmid == quiz.cmid
                else attempt.quizName.equals(quiz.quizName, ignoreCase = true)
            }
            val progress = resolveMoodleQuizProgress(quiz, quizAttempts, schedule.closeTime, attemptsLoaded)
            val latestFinishedAttempt = quizAttempts.filter(::isMoodleFinishedAttempt)
                .maxByOrNull(::moodleAttemptSortOrder)
            val visibleGradeScore = quiz.gradeScore?.takeIf { quiz.hasApiBestGrade == true }
                ?: latestFinishedAttempt?.score
            val visibleGradeMax = quiz.gradeMax?.takeIf { quiz.hasApiBestGrade == true }
                ?: latestFinishedAttempt?.maxScore
            val visibleGradePercent = quiz.gradePercent?.takeIf { quiz.hasApiBestGrade == true }
            val timeLimit = quiz.timeLimit?.takeIf { it.isNotBlank() && !it.contains("не указан", true) }
            val allowedAttempts = quiz.allowedAttempts?.takeIf { it.isNotBlank() && it != "0" }
            val missingValue = if (isLoadingQuizDetails) "…" else "—"
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        normalizeMoodleDisplayName(quiz.quizName),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    when (progress.state) {
                        MoodleQuizProgressState.IN_PROGRESS -> QuizStateLine(
                            title = "В процессе",
                            detail = progress.latestAttempt?.started?.let { "Начато: ${cleanMoodleText(it)}" }
                                ?: "У вас есть незавершённая попытка",
                            state = progress.state
                        )
                        MoodleQuizProgressState.COMPLETED -> QuizStateLine(
                            title = "Завершён",
                            detail = progress.completedAt?.let { "Вы завершили: ${cleanMoodleText(it)}" }
                                ?: "—",
                            state = progress.state
                        )
                        MoodleQuizProgressState.NOT_STARTED -> QuizStateLine(
                            title = "Не начат",
                            detail = when {
                                !progress.deadlineAt.isNullOrBlank() -> "Срок закрытия: ${cleanMoodleText(progress.deadlineAt)}"
                                quiz.detailsLoaded -> "Без ограничения по дате"
                                else -> "—"
                            },
                            state = progress.state
                        )
                        MoodleQuizProgressState.UNKNOWN -> QuizStateLine("—", "—", progress.state)
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuizMetaChip("Время", timeLimit ?: missingValue)
                        QuizMetaChip("Попытки", allowedAttempts ?: missingValue)
                        schedule.openTime?.let { QuizMetaChip("Открытие", cleanMoodleText(it)) }
                    }

                    when {
                        !visibleGradeScore.isNullOrBlank() -> Text(
                            "Оценка: ${formatGradeNumber(visibleGradeScore)} из ${formatGradeNumber(visibleGradeMax ?: "—")} баллов",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                        !visibleGradePercent.isNullOrBlank() -> Text(
                            "Результат: ${formatGradeNumber(visibleGradePercent)}%",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Button(onClick = { onOpenQuiz(quiz) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Открыть")
                    }
                }
            }
        }
    }
}

@Composable
private fun QuizActivityScreen(
    quiz: MoodleQuiz,
    attempts: List<MoodleQuizAttempt>,
    calendarEvents: List<MoodleCalendarEvent>,
    isLoadingAttempts: Boolean,
    isLoadingQuizDetails: Boolean,
    attemptsLoaded: Boolean,
    onStartQuiz: () -> Unit,
    onContinueAttempt: (String) -> Unit,
    onReviewAttempt: (String) -> Unit
) {
    val schedule = quizScheduleTimes(quiz, calendarEvents)
    val progress = resolveMoodleQuizProgress(quiz, attempts, schedule.closeTime, attemptsLoaded)
    val latestAttempt = progress.latestAttempt
    val latestFinishedAttempt = attempts.filter(::isMoodleFinishedAttempt).maxByOrNull(::moodleAttemptSortOrder)
    val visibleGradeScore = quiz.gradeScore?.takeIf { quiz.hasApiBestGrade == true }
        ?: latestFinishedAttempt?.score
    val visibleGradeMax = quiz.gradeMax?.takeIf { quiz.hasApiBestGrade == true }
        ?: latestFinishedAttempt?.maxScore
    val visibleGradePercent = quiz.gradePercent?.takeIf { quiz.hasApiBestGrade == true }
    val canStartBySchedule = quiz.visible != 0 && quiz.uservisible != 0 && quiz.accessvisible != 0 &&
        !isMoodleDateWindowClosed(schedule.openTime ?: quiz.openTimeText, schedule.closeTime ?: quiz.closeTimeText)
    val canStart = if (quiz.accessInfoLoaded) quiz.canAttempt == true else canStartBySchedule
    val activeAttemptId = latestAttempt?.attemptId?.takeIf { it.toLongOrNull() != null }
    val reviewAttemptId = latestFinishedAttempt?.attemptId?.takeIf { it.toLongOrNull() != null }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        "УЧЕБНЫЙ ТЕСТ",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        normalizeMoodleDisplayName(quiz.quizName),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    when (progress.state) {
                        MoodleQuizProgressState.IN_PROGRESS -> QuizStateLine(
                            title = "В процессе",
                            detail = latestAttempt?.started?.let { "Начато: ${cleanMoodleText(it)}" }
                                ?: "Попытка ещё не завершена. Можно вернуться к ней позже.",
                            state = progress.state
                        )
                        MoodleQuizProgressState.COMPLETED -> QuizStateLine(
                            title = "Завершён",
                            detail = progress.completedAt?.let { "Вы завершили: ${cleanMoodleText(it)}" } ?: "—",
                            state = progress.state
                        )
                        MoodleQuizProgressState.NOT_STARTED -> QuizStateLine(
                            title = "Не начат",
                            detail = if (schedule.closeTime != null) {
                                "Открыто до: ${cleanMoodleText(schedule.closeTime)}"
                            } else if (quiz.detailsLoaded) {
                                "Срок закрытия не ограничен"
                            } else {
                                "—"
                            },
                            state = progress.state
                        )
                        MoodleQuizProgressState.UNKNOWN -> QuizStateLine("—", "—", progress.state)
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        QuizMetric(
                            title = "ВРЕМЯ НА ТЕСТ",
                            value = quiz.timeLimit?.takeIf { it.isNotBlank() } ?: "—",
                            modifier = Modifier.weight(1f)
                        )
                        QuizMetric(
                            title = "ПОПЫТКИ",
                            value = quiz.allowedAttempts?.takeIf { it.isNotBlank() && it != "0" } ?: "—",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    when {
                        !visibleGradeScore.isNullOrBlank() -> Text(
                            "Итоговая оценка: ${formatGradeNumber(visibleGradeScore)} из ${formatGradeNumber(visibleGradeMax ?: "—")} баллов",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        !visibleGradePercent.isNullOrBlank() -> Text(
                            "Результат: ${formatGradeNumber(visibleGradePercent)}%",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Условия теста", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        QuizInfoLine("Открытие", schedule.openTime?.takeIf { it.isNotBlank() } ?: quiz.openTimeText?.takeIf { it.isNotBlank() } ?: "—")
                        QuizInfoLine("Открыто до", schedule.closeTime?.takeIf { it.isNotBlank() } ?: quiz.closeTimeText?.takeIf { it.isNotBlank() } ?: if (quiz.detailsLoaded) "Без ограничения по дате" else "—")
                        QuizInfoLine("Разрешено попыток", quiz.allowedAttempts?.takeIf { it.isNotBlank() } ?: "—")
                        QuizInfoLine("Время на выполнение", quiz.timeLimit?.takeIf { it.isNotBlank() } ?: "—")
                        quiz.quizAccessReasons.firstOrNull()?.takeIf { quiz.accessInfoLoaded && quiz.canAttempt == false }?.let {
                            Text("Доступ: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                        if (isLoadingQuizDetails) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Text("Обновляем параметры…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Ваши попытки", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        when {
                            isLoadingAttempts -> Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Text("Загружаем историю прохождений…", style = MaterialTheme.typography.bodyMedium)
                            }
                            attempts.isEmpty() -> Text(
                                if (attemptsLoaded && quiz.hasConfirmedNoAttempts == true) "Попыток пока нет" else "—",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            else -> attempts.sortedByDescending(::moodleAttemptSortOrder).forEachIndexed { index, attempt ->
                                if (index > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        "Попытка ${attempt.attemptRow ?: (attempts.size - index).toString()}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    val attemptStatus = attempt.status ?: if (!attempt.completed.isNullOrBlank()) "Завершена" else "В процессе"
                                    Text(attemptStatus, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                                    attempt.started?.takeIf { it.isNotBlank() }?.let { Text("Начало: ${cleanMoodleText(it)}", style = MaterialTheme.typography.bodySmall) }
                                    attempt.completed?.takeIf { it.isNotBlank() }?.let { Text("Завершение: ${cleanMoodleText(it)}", style = MaterialTheme.typography.bodySmall) }
                                    attempt.score?.takeIf { it.isNotBlank() }?.let { score ->
                                        Text(
                                            "Результат: ${if (!attempt.maxScore.isNullOrBlank()) "$score из ${attempt.maxScore}" else score}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            when (progress.state) {
                MoodleQuizProgressState.IN_PROGRESS -> {
                    if (activeAttemptId != null) {
                        Button(onClick = { onContinueAttempt(activeAttemptId) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Продолжить попытку")
                        }
                    } else {
                        Text("Moodle не вернул числовой ID активной попытки. Обновите историю; приложение не будет открывать внешний сайт.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                }
                MoodleQuizProgressState.NOT_STARTED -> {
                    Button(onClick = onStartQuiz, enabled = canStart && !isLoadingQuizDetails,
                        modifier = Modifier.fillMaxWidth()) {
                        Text(if (canStart) "Начать тест" else "Тест недоступен")
                    }
                    if (!canStart && quiz.accessInfoLoaded) {
                        Text(
                            quiz.quizAccessReasons.firstOrNull() ?: "Moodle не подтвердил возможность начать новую попытку.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                MoodleQuizProgressState.COMPLETED -> {
                    if (reviewAttemptId != null && quiz.canReviewMyAttempts != false) {
                        OutlinedButton(onClick = { onReviewAttempt(reviewAttemptId) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Разобрать попытку")
                        }
                    } else {
                        Text("Тест завершён. ${if (quiz.canReviewMyAttempts == false) "Moodle не разрешает просмотр попытки." else "ID попытки или разрешение на просмотр не получены."}",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (canStart && !isLoadingQuizDetails) {
                        Button(onClick = onStartQuiz, modifier = Modifier.fillMaxWidth()) {
                            Text("Начать новую попытку")
                        }
                    } else if (quiz.accessInfoLoaded && quiz.canAttempt != true) {
                        Text(
                            quiz.quizAccessReasons.firstOrNull() ?: "Новых попыток больше нет или Moodle пока не разрешает повторное прохождение.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                MoodleQuizProgressState.UNKNOWN -> {
                    if (quiz.accessInfoLoaded && quiz.canAttempt == true) {
                        Button(onClick = onStartQuiz, modifier = Modifier.fillMaxWidth()) { Text("Начать тест") }
                    } else {
                        OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) { Text("Ожидаем подтверждения состояния теста") }
                    }
                }
            }
        }
    }
}


@Composable
private fun QuizRunnerScreen(
    runner: MoodleQuizRunnerUiState,
    moodleBaseUrl: String,
    onAdvance: (List<Pair<String, String>>) -> Unit,
    onSave: (List<Pair<String, String>>) -> Unit,
    onReturnToQuestions: () -> Unit,
    onFinish: () -> Unit,
    onClose: () -> Unit
) {
    var questionWebView by remember { mutableStateOf<WebView?>(null) }
    val html = remember(runner.questions, runner.isReview, runner.isSummary) {
        buildString {
            runner.questions.forEach { question ->
                append("<section class=\"quiz-question\">\n")
                if (question.status != null || question.number != null) {
                    append("<div class=\"quiz-question-meta\">")
                    append(question.number?.let { "Вопрос $it" }.orEmpty())
                    question.status?.let { append(" · ").append(it) }
                    append("</div>")
                }
                append(question.html)
                append("</section>\n")
            }
        }
    }
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (runner.isLoading) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                Text(runner.message ?: "Загрузка теста…")
            }
        }
        runner.error?.let {
            Card {
                Text(it, modifier = Modifier.fillMaxWidth().padding(16.dp), color = MaterialTheme.colorScheme.error)
            }
        }
        runner.message?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        runner.gradeText?.let {
            Text(it, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        }
        if (runner.questions.isNotEmpty()) {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        setBackgroundColor(Color.TRANSPARENT)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        settings.javaScriptCanOpenWindowsAutomatically = false
                        settings.setSupportMultipleWindows(false)
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = true
                            override fun shouldOverrideUrlLoading(view: WebView?, request: android.webkit.WebResourceRequest?): Boolean = true
                            override fun onPageFinished(view: WebView?, url: String?) {
                                // Prevent forms from navigating to attempt.php/review.php. The app
                                // collects field values and posts them through the WS endpoint.
                                view?.evaluateJavascript("document.querySelectorAll('form').forEach(function(f){f.addEventListener('submit',function(e){e.preventDefault()})})", null)
                            }
                        }
                        questionWebView = this
                        tag = html.hashCode()
                        loadDataWithBaseURL(moodleBaseUrl.trimEnd('/') + "/", buildQuizHtmlDocument(html), "text/html", "UTF-8", null)
                    }
                },
                update = { view ->
                    if (view.tag != html.hashCode()) {
                        view.tag = html.hashCode()
                        view.loadDataWithBaseURL(moodleBaseUrl.trimEnd('/') + "/", buildQuizHtmlDocument(html), "text/html", "UTF-8", null)
                    }
                    questionWebView = view
                },
                modifier = Modifier.fillMaxWidth().height(620.dp)
            )
        }
        runner.additionalData.forEach { extra ->
            if (extra.title.isNotBlank() || extra.content.isNotBlank()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (extra.title.isNotBlank()) Text(extra.title, fontWeight = FontWeight.SemiBold)
                        if (extra.content.isNotBlank()) Text(android.text.Html.fromHtml(extra.content, android.text.Html.FROM_HTML_MODE_COMPACT).toString())
                    }
                }
            }
        }
        when {
            runner.isReview -> Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Закрыть разбор") }
            runner.isCompleted -> Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Готово") }
            runner.isSummary -> {
                Button(onClick = onFinish, enabled = !runner.isSubmitting, modifier = Modifier.fillMaxWidth()) {
                    if (runner.isSubmitting) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Text("Отправить тест")
                }
                OutlinedButton(onClick = onReturnToQuestions, enabled = !runner.isSubmitting, modifier = Modifier.fillMaxWidth()) { Text("Вернуться к последней странице") }
                OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Закрыть без отправки") }
            }
            runner.attemptId != null && runner.questions.isNotEmpty() -> {
                OutlinedButton(
                    onClick = {
                        val webView = questionWebView
                        if (webView == null) onSave(emptyList()) else webView.evaluateJavascript(QUIZ_COLLECT_RESPONSES_JS) { raw ->
                            val pairs = runCatching {
                                val encoded = JsonParser.parseString(raw).asString
                                JsonParser.parseString(encoded).asJsonArray.mapNotNull { element ->
                                    if (!element.isJsonObject) null else {
                                        val item = element.asJsonObject
                                        val name = item.get("name")?.asString
                                        val value = item.get("value")?.asString
                                        if (name.isNullOrBlank() || value == null) null else name to value
                                    }
                                }
                            }.getOrDefault(emptyList())
                            onSave(pairs)
                        }
                    },
                    enabled = !runner.isSubmitting && !runner.isLoading,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Сохранить ответы") }
                Button(
                    onClick = {
                        val webView = questionWebView
                        if (webView == null) onAdvance(emptyList()) else webView.evaluateJavascript(QUIZ_COLLECT_RESPONSES_JS) { raw ->
                            val pairs = runCatching {
                                val encoded = JsonParser.parseString(raw).asString
                                JsonParser.parseString(encoded).asJsonArray.mapNotNull { element ->
                                    if (!element.isJsonObject) null else {
                                        val item = element.asJsonObject
                                        val name = item.get("name")?.asString
                                        val value = item.get("value")?.asString
                                        if (name.isNullOrBlank() || value == null) null else name to value
                                    }
                                }
                            }.getOrDefault(emptyList())
                            onAdvance(pairs)
                        }
                    },
                    enabled = !runner.isSubmitting && !runner.isLoading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (runner.isSubmitting) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Text(if (runner.nextPage >= 0) "Следующая страница" else "Проверить ответы")
                }
            }
        }
        if (!runner.isReview && !runner.isCompleted && runner.isSummary) {
            Text("После отправки изменить ответы будет нельзя. Просмотр правильных ответов зависит от настроек теста в Moodle.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private const val QUIZ_COLLECT_RESPONSES_JS = """(function(){var out=[];document.querySelectorAll('input[name],textarea[name],select[name]').forEach(function(e){if(e.disabled)return;var t=(e.type||'').toLowerCase();if(['submit','button','reset','file','image'].indexOf(t)>=0)return;if((t==='checkbox'||t==='radio')&&!e.checked)return;if(e.tagName==='SELECT'&&e.multiple){Array.from(e.options).filter(function(o){return o.selected}).forEach(function(o){out.push({name:e.name,value:o.value})});}else{out.push({name:e.name,value:e.value})}});return JSON.stringify(out)})()"""

private fun buildQuizHtmlDocument(questionHtml: String): String = """
    <!doctype html><html lang="ru"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
    <style>
      body{font-family:Roboto,Arial,sans-serif;color:#20212a;background:transparent;margin:0;padding:4px;line-height:1.5;overflow-wrap:anywhere}
      img,video,iframe{max-width:100%;height:auto} table{max-width:100%;border-collapse:collapse} td,th{padding:5px;border:1px solid #bbb}
      input,select,textarea{max-width:100%;font:inherit} textarea{width:100%;min-height:90px} .quiz-question{margin:0 0 18px;padding:14px;border-radius:14px;background:#e7e1eb}
      .quiz-question-meta{font-size:12px;color:#4556a3;font-weight:700;margin-bottom:8px} .formulation{margin:8px 0}
      .answer{margin-top:10px} .feedback,.outcome,.specificfeedback{margin-top:8px}
      .que{margin:8px 0 16px} .qtext{margin-bottom:10px} .answer div{margin:4px 0}
      .quiz-summary-row{padding:12px 0;border-bottom:1px solid #c6bfcc}.quiz-summary-row div{color:#40414b;font-size:14px;margin-top:4px}
    </style>
    <script>window.MathJax={tex:{inlineMath:[["\\(","\\)"],["$","$" ]],displayMath:[["\\[","\\]"],["$$","$$"]]},options:{skipHtmlTags:["script","noscript","style","textarea","pre","code"]}};</script>
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/3.2.2/es5/tex-mml-chtml.js"></script>
    </head><body>$questionHtml</body></html>
""".trimIndent()

@Composable
private fun QuizStateLine(
    title: String,
    detail: String,
    state: MoodleQuizProgressState
) {
    val container = when (state) {
        MoodleQuizProgressState.IN_PROGRESS -> MaterialTheme.colorScheme.tertiaryContainer
        MoodleQuizProgressState.COMPLETED -> MaterialTheme.colorScheme.secondaryContainer
        MoodleQuizProgressState.NOT_STARTED, MoodleQuizProgressState.UNKNOWN -> MaterialTheme.colorScheme.surfaceVariant
    }
    val content = when (state) {
        MoodleQuizProgressState.IN_PROGRESS -> MaterialTheme.colorScheme.onTertiaryContainer
        MoodleQuizProgressState.COMPLETED -> MaterialTheme.colorScheme.onSecondaryContainer
        MoodleQuizProgressState.NOT_STARTED, MoodleQuizProgressState.UNKNOWN -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(color = container, shape = RoundedCornerShape(12.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = content)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = content)
        }
    }
}

@Composable
private fun QuizMetric(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun QuizMetaChip(label: String, value: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(10.dp)) {
        Text(
            "$label: $value",
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

private data class QuizScheduleTimes(val openTime: String?, val closeTime: String?)

private fun quizScheduleTimes(quiz: MoodleQuiz, calendarEvents: List<MoodleCalendarEvent>): QuizScheduleTimes {
    val quizId = quiz.cmid?.takeIf { it.isNotBlank() }
    val matching = calendarEvents.filter { event ->
        val target = event.activityUrl ?: event.url.orEmpty()
        val sameActivity = quizId != null &&
            Regex("[?&](?:id|cmid)=${Regex.escape(quizId)}(?:&|$)").containsMatchIn(target)
        val sameName = event.name.isNotBlank() && (
            event.name.contains(quiz.quizName, ignoreCase = true) ||
                quiz.quizName.contains(event.name, ignoreCase = true)
            )
        sameActivity || sameName
    }
    fun time(event: MoodleCalendarEvent?): String? = event?.timestart?.let(::formatTimestamp)
        ?: event?.formattedTime?.takeIf { it.isNotBlank() }
    val open = matching.firstOrNull { it.eventtype.equals("open", true) }
    val close = matching.firstOrNull { it.eventtype.equals("close", true) || it.eventtype.equals("due", true) }
    return QuizScheduleTimes(
        openTime = time(open) ?: quiz.openTimeText,
        closeTime = time(close) ?: quiz.closeTimeText
    )
}

@Composable
private fun QuizInfoLine(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun GradesScreen(grades: List<MoodleGradeItem>, scrollState: androidx.compose.foundation.lazy.LazyListState) {
    if (grades.isEmpty()) {
        EmptyState(Icons.Outlined.Grade, "Оценок пока нет", "Здесь появятся выставленные результаты.")
        return
    }
    LazyColumn(state = scrollState, contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        items(grades, key = { it.id }) { grade ->
            GradeCard(grade.name, grade.score, grade.maxScore, grade.percent)
        }
    }
}

@Composable
private fun GradeCard(name: String, score: String?, maxScore: String?, percent: String?) {
    val scoreLabel = when {
        !score.isNullOrBlank() && !maxScore.isNullOrBlank() -> "${formatGradeNumber(score)} из ${formatGradeNumber(maxScore)} баллов"
        !score.isNullOrBlank() -> "${formatGradeNumber(score)} баллов"
        else -> "Оценка ещё не выставлена"
    }
    val percentValue = percent?.replace(',', '.')?.toFloatOrNull()?.coerceIn(0f, 100f)
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Text(normalizeMoodleDisplayName(name), modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                if (!percent.isNullOrBlank()) {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(10.dp)) {
                        Text("${percent.replace('.', ',')}%", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text(scoreLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (percentValue != null) {
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { percentValue / 100f },
                    modifier = Modifier.fillMaxWidth().height(6.dp)
                )
            }
        }
    }
}

private fun formatGradeNumber(value: String): String = value.trim().replace('.', ',')

@Composable
private fun AttemptsScreen(
    attempts: List<MoodleQuizAttempt>,
    quizzes: List<MoodleQuiz>,
    isLoading: Boolean,
    scrollState: androidx.compose.foundation.lazy.LazyListState
) {
    if (isLoading) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }
    if (attempts.isEmpty()) {
        EmptyState(Icons.Outlined.Timeline, "Попыток пока нет", "Здесь появится история ваших прохождений тестов.")
        return
    }
    LazyColumn(state = scrollState, contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(
                "История прохождений",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 2.dp)
            )
        }
        items(attempts, key = { "attempt_${it.cmid ?: it.quizName.orEmpty()}_${it.attemptId}" }) { attempt ->
            val sameQuizAttempts = attempts.filter {
                if (!attempt.cmid.isNullOrBlank()) it.cmid == attempt.cmid
                else it.quizName == attempt.quizName
            }
            val ordinal = sameQuizAttempts.size - sameQuizAttempts.indexOf(attempt)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(normalizeMoodleDisplayName(attempt.quizName ?: "Тест"), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text("Попытка $ordinal из ${sameQuizAttempts.size}", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary)
                    val status = attempt.status?.takeIf { it.isNotBlank() }
                    if (status != null) {
                        Surface(
                            color = if (status == "Завершена") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                status,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                style = MaterialTheme.typography.labelMedium,
                                color = if (status == "Завершена") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                    attempt.score?.takeIf { it.isNotBlank() }?.let { score ->
                        val scoreLabel = if (!attempt.maxScore.isNullOrBlank()) {
                            "Результат: ${formatGradeNumber(score)} из ${formatGradeNumber(attempt.maxScore)} баллов"
                        } else {
                            "Результат: ${formatGradeNumber(score)} баллов"
                        }
                        Text(scoreLabel, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary)
                    }
                    attempt.started?.takeIf { it.isNotBlank() }?.let {
                        Text("Начало: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    val linkedQuiz = quizzes.firstOrNull { quiz ->
                        if (!attempt.cmid.isNullOrBlank()) quiz.cmid == attempt.cmid
                        else quiz.quizName.equals(attempt.quizName, ignoreCase = true)
                    }
                    val completionText = attempt.completed?.takeIf { it.isNotBlank() && it != attempt.started }
                        ?: deriveMoodleAttemptCompletedTime(
                            started = attempt.started,
                            actualElapsed = attempt.elapsed,
                            recordedCompleted = attempt.completed,
                            configuredTimeLimit = linkedQuiz?.timeLimit
                        )
                    completionText?.let {
                        Text(
                            "Завершение: $it",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    (cleanMoodleElapsed(attempt.elapsed) ?: deriveMoodleElapsed(attempt.started, attempt.completed))?.let {
                        Text("Время выполнения: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    attempt.questionCount?.takeIf { it > 0 }?.let {
                        Text("Вопросов: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarScreen(
    events: List<MoodleCalendarEvent>,
    moodleBaseUrl: String,
    courseId: String,
    onOpenMoodle: (String) -> Unit,
    scrollState: androidx.compose.foundation.lazy.LazyListState
) {
    if (events.isEmpty()) {
        EmptyState(Icons.Outlined.CalendarMonth, "Предстоящих событий нет", "Здесь отображаются сроки заданий, тестов и другие события курса.")
        return
    }
    val sorted = events.sortedBy { it.timestart ?: Long.MAX_VALUE }
    LazyColumn(state = scrollState, contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Сроки и события", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 2.dp))
        }
        items(sorted, key = { it.eventId }) { event ->
            val title = cleanCalendarTitle(event.name).ifBlank { "Событие курса" }
            val time = event.timestart?.let(::formatTimestamp)
                ?: cleanMoodleText(event.formattedTime).takeIf { it.isNotBlank() }
            val eventType = calendarEventLabel(event)
            val endTime = if (event.timestart != null && (event.timeDuration ?: 0L) > 0L) {
                formatTimestamp(event.timestart + (event.timeDuration ?: 0L))
            } else null
            val description = cleanMoodleText(event.description).takeIf {
                it.isNotBlank() && !it.equals(title, true)
            }
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    Text(title, modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold)
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(8.dp)) {
                        Text(eventType, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    if (time != null) {
                        Text(
                            when (event.eventtype?.lowercase(Locale.ROOT)) {
                                "due", "close" -> "Открыто до: $time"
                                "open" -> "Открытие: $time"
                                else -> "Дата: $time"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (endTime != null && endTime != time) Text("Окончание: $endTime", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (!description.isNullOrBlank()) {
                        Text(description.take(260), style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    val target = (event.activityUrl ?: event.url)?.takeIf { it.startsWith("http", true) && !isSdoLink(it) }
                    if (target != null) {
                        Button(onClick = { onOpenMoodle(resolveMoodleTarget(target, moodleBaseUrl, event.courseId ?: courseId)) },
                            modifier = Modifier.fillMaxWidth()) { Text("Открыть") }
                    }
                }
            }
        }
    }
}

private fun calendarEventLabel(event: MoodleCalendarEvent): String {
    val category = when (event.eventtype?.lowercase(Locale.ROOT)) {
        "due" -> "Срок сдачи"
        "open" -> "Открытие"
        "close" -> "Закрытие"
        "action" -> "Задание"
        "course" -> "Событие курса"
        "user" -> "Личное событие"
        "site" -> "Событие Moodle"
        else -> null
    }
    if (category != null) return category
    val action = cleanMoodleText(event.actionName)
    return action.takeIf { it.isNotBlank() }?.take(30) ?: "Событие"
}

private fun cleanCalendarTitle(value: String?): String {
    if (value.isNullOrBlank()) return ""
    val withoutLinkedDate = value.replace(Regex("(?is)<a\\b[^>]*>.*?</a>"), " ")
    return cleanMoodleText(withoutLinkedDate)
        .replace(Regex("(?i)(?:,?\\s*)?\\d{1,2}:\\d{2}\\s*$"), "")
        .replace(Regex("(?i)\\s+(?:закрывается|открывается)\\s*$"), "")
        .trim()
}

private fun cleanMoodleText(value: String?): String {
    if (value.isNullOrBlank()) return ""
    return Html.fromHtml(value, Html.FROM_HTML_MODE_COMPACT).toString()
        .replace('\u00a0', ' ')
        .replace(Regex("(?i)\\bclose\\s*$"), "")
        .replace(Regex("(?i)\\bOBJ\\b"), "")
        .replace(Regex("(?i)выбрать элемент"), "")
        .replace(Regex("[ \t]+"), " ")
        .replace(Regex("\\n{2,}"), "\n")
        .trim()
}

@Composable
private fun SectionHeading(title: String, trailing: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Surface(color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(8.dp)) {
            Text(trailing, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimary)
        }
    }
}

@Composable
private fun EmptyState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
    action: String? = null,
    onAction: () -> Unit = {}
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        androidx.compose.material3.Icon(icon, contentDescription = null, modifier = Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        Text(title, modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(body, modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (action != null) {
            Spacer(Modifier.height(12.dp))
            Button(onClick = onAction) { Text(action) }
        }
    }
}

private fun extractUrls(raw: String?): List<String> {
    if (raw.isNullOrBlank()) return emptyList()
    val regex = Regex("https?://[^\\s\\\"'<>]+")
    return regex.findAll(raw).map { it.value.trimEnd(',', ';', ')', ']') }.distinct().toList()
}

private fun formatTimestamp(seconds: Long): String = runCatching {
    Instant.ofEpochSecond(seconds).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm", Locale.getDefault()))
}.getOrDefault(seconds.toString())

private fun buildCourseMoodleUrl(baseUrl: String, courseId: String): String =
    "${baseUrl.trimEnd('/')}/course/view.php?id=${Uri.encode(courseId)}"

private fun resolveMoodleTarget(rawUrl: String?, baseUrl: String, courseId: String): String {
    val fallback = buildCourseMoodleUrl(baseUrl, courseId)
    val candidate = rawUrl?.trim()?.takeIf { it.isNotBlank() }?.let { raw ->
        if (raw.startsWith("https://", ignoreCase = true)) raw
        else if (raw.startsWith("/")) "${baseUrl.trimEnd('/')}$raw"
        else "${baseUrl.trimEnd('/')}/$raw"
    } ?: fallback
    val uri = Uri.parse(candidate)
    val host = uri.host.orEmpty().lowercase()
    return if (uri.scheme == "https" && host == MOODLE_HOST) candidate else fallback
}

private fun isSdoLink(value: String?): Boolean {
    if (value.isNullOrBlank()) return false
    return runCatching {
        val host = Uri.parse(value).host.orEmpty()
        host.equals("sdo.tusur.ru", ignoreCase = true) || host.endsWith(".sdo.tusur.ru", ignoreCase = true)
    }.getOrDefault(false)
}

private fun htmlToText(value: String?): String? {
    if (value.isNullOrBlank()) return null
    return Html.fromHtml(value, Html.FROM_HTML_MODE_COMPACT).toString().trim().takeIf { it.isNotBlank() }
}

