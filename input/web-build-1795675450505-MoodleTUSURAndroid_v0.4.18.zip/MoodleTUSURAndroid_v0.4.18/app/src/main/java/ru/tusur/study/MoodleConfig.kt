package ru.tusur.study

const val MOODLE_HOST = "moodle.math.tusur.ru"
const val DEFAULT_MOODLE_BASE_URL = "https://$MOODLE_HOST/"
