package ru.tusur.moodle.data

/**
 * Recognises only Moodle's explicit empty-history messages. A generic table or an empty parser
 * result is not evidence that the student has never attempted the quiz.
 */
object MoodleQuizOverviewHistorySignal {
    private val noAttemptsPattern = Regex(
        "(?iu)(?:вы\\s+еще\\s+не\\s+(?:делали|предпринимали|совершали|пытались)\\s+(?:ни\\s+одной\\s+)?попыт(?:ки|ок)|" +
            "пока\\s+нет\\s+попыток|нет\\s+попыток|не\\s+было\\s+попыток|" +
            "you\\s+have\\s+not\\s+attempted\\s+(?:this\\s+)?quiz\\s+yet|" +
            "you\\s+have\\s+not\\s+made\\s+any\\s+attempts(?:\\s+yet)?|" +
            "no\\s+attempts\\s+(?:have\\s+been\\s+made|yet))"
    )

    fun explicitlyConfirmsNoAttempts(text: String): Boolean {
        val normalized = text.replace('ё', 'е').replace('Ё', 'Е')
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
        return noAttemptsPattern.containsMatchIn(normalized)
    }
}
