@echo off
setlocal
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\bootstrap-wrapper.ps1"
if errorlevel 1 (
  echo.
  echo Could not generate Gradle Wrapper. Check Java and network access.
  pause
  exit /b 1
)
echo.
echo Wrapper ready. Open this folder in Android Studio now.
pause
endlocal
