# SOURCE REVIEW — Moodle.TUSUR 0.4.15

## Цель ревизии

Исправить ложное отображение «Не начат» для завершённой попытки и не показывать пустую историю там, где Moodle вернул неполную/неразобранную строку. Эталонный случай — пользовательский скриншот Moodle со строкой `Завершены / Отправлено четверг, 10 сентября 2026, 10:55`, оценкой `10,00` из `18,00` и текстом `Не разрешается` в колонке просмотра.

## Обнаруженные дефекты

1. Парсер зависел от наличия номера попытки или ссылки с `attempt=<id>`. При запрещённом просмотре Moodle может не отдать review URL и номер, хотя видимые состояние, дата и оценка остаются.
2. Состояние пустой истории могло ошибочно перетянуть состояние «Не начат» на строку с неизвестным статусом.
3. API best grade нельзя трактовать как абсолютный индикатор истории: `hasgrade=false` может означать, что Moodle скрывает оценку по review settings.

## Изменения

- `MoodleQuizAttemptTableParser`: определяет header columns и сохраняет строку по статусу даже без attempt ID/link; получает grade/max из grade cell/header; сохраняет видимую подпись номера попытки.
- `MoodleQuizOverviewSummaryParser`: получает итоговую оценку из нижнего блока страницы и timestamp последней отправки.
- `MoodleDirectRepository`: новый `mod_quiz_get_user_quiz_attempts` предпочитается legacy методу; HTML `view.php` читается независимо; best grade используется как дополнительное, не исчерпывающее evidence.
- `MoodleQuizProgress`: строка попытки с неизвестным состоянием приводит к `UNKNOWN`, а не к `NOT_STARTED`; подтверждённо пустая история учитывается только при `attempts.isEmpty()`.
- `MoodleViewModel`: повторно загружает не полученные детали, invalidates stale empty-history evidence при обновлении; ошибки загрузки не превращают историю в подтверждённо пустую.
- `MainActivity`: оценка из видимой завершённой строки используется как fallback; отсутствующие значения отображаются прочерком; технические диагностики не выводятся в карточку/детальный экран.

## Проверки

- 11 тестов `MoodleQuizAttemptTableParserTest` запущены локальным Kotlin 1.9 harness; все прошли.
- В том же harness выполнено 17 тестов `MoodleQuizProgressTest`, 4 теста `MoodleQuizOverviewSummaryParserTest`, 3 теста `MoodleQuizOverviewHistorySignalTest`, 3 теста `MoodleQuizAttemptSourcePolicyTest` и 2 теста `MoodleApiBooleanTest`. Всего 40 чистых Kotlin regression checks — все прошли.
- Статический скрипт проверил 39 регрессионных условий, 38 Kotlin source files, 261 helper-call references и 378 внутренних объявлений; результат PASS.
- Специально проверен точный screenshot fixture: 10/18, «Завершены», без номера и ссылки, дата отправки 10.09.2026 10:55.

## Не проверено / ограничения

- Полная Android/Compose сборка и Gradle JUnit task не запускались. `./gradlew testDebugUnitTest --offline --no-daemon` завершился на попытке скачать Gradle 9.6.0: `UnknownHostException: services.gradle.org`. В среде нет `ANDROID_HOME`, `ANDROID_SDK_ROOT` и Android SDK.
- На живой авторизованной учётной записи Moodle ТУСУР изменения не проверялись; нужно проверить на телефоне по `TEST_PLAN_0.4.15_RU.md`.
- Полностью нативный quiz runner не реализован. Вопросы и прохождение пока используют Moodle WebView flow. Нативный login и quiz API transport methods есть, но native question renderer, autosave/resume/timer/submit UI ещё не подключены.

## Вывод

Кодовая причина ложного «Не начат» для показанной структуры таблицы исправлена и покрыта regression fixture. Это подтверждается локальными Kotlin проверками и static source checks, но не Android build или live Moodle test. До проверки на телефоне статус следует считать исправленным на уровне исходников, а не подтверждённым в эксплуатации.
