# SOURCE REVIEW — Moodle.TUSUR 0.4.10

## Причина трёх ошибок на скриншоте

В `TUSURStudyApp` вызывался `downloadMoodleResource(context, target)`, но `context` не принадлежал области видимости этой функции. Переменная с таким именем в предыдущем коде объявлялась в другом composable (`CourseDetailScreen`), а локальные переменные одной composable-функции недоступны в другой.

Из-за этого Kotlin интерпретировал `context` как неразрешённое выражение, что приводило к группе сообщений вида `Function invocation 'context(...)' expected`, ошибке выбора перегрузки и `No value passed for parameter 'block'`.

## Исправление

- В `MainActivity.onCreate` передаётся `this@MainActivity` в `TUSURStudyApp` как `appContext`.
- Сигнатура composable обновлена: `TUSURStudyApp(state, viewModel, appContext: Context)`.
- Прямое скачивание вызывается как `downloadMoodleResource(appContext, target)`.
- Переменная `context` больше не используется в этой точке, поэтому нет зависимости от `LocalContext` в другой composable-функции.

## Выполненные проверки

- Проверен единственный вызов `TUSURStudyApp` и совпадение с новой сигнатурой.
- Проверен тип `appContext: Context` и источник `this@MainActivity`.
- Проверены все вызовы `downloadMoodleResource` в `MainActivity.kt` и `MoodleWebViewScreen.kt`.
- Статический скрипт проверяет наличие Activity Context именно в области вызова загрузчика, а не просто наличие переменной `context` где-либо в файле.
- Все 16 Kotlin-файлов прошли проверку лексической структуры; внутренние импорты и проектные helper-вызовы сопоставлены с объявлениями.

## Ограничение

Gradle и Android/Compose type-check не запускались. Отчёт подтверждает устранение ошибки области видимости из указанного Build Output и успешное прохождение статических проверок; он не является подтверждением полной сборки APK.
