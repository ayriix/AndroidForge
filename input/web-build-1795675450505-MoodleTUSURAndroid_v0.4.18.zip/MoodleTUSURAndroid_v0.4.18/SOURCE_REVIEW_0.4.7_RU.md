# Проверка исходников Moodle ТУСУР 0.4.7

## Исправленная ошибка из Build Output 0.4.6

В `MoodleWebViewScreen.kt` запрос создавался цепочкой, последним вызовом которой был `allowScanningByMediaScanner()`. В целевой Android API этот вызов возвращает `Unit`, а не `DownloadManager.Request`. Поэтому Kotlin выводил тип переменной `request` как `Unit`, после чего возникали ошибки `addRequestHeader`, ошибки вывода типа в `let` и несовместимость аргумента для `enqueue`.

В 0.4.7 запрос создаётся как `DownloadManager.Request(uri).apply { ... }`. Все настройки и заголовки добавляются внутри receiver типа `DownloadManager.Request`; результат отдельных вызовов больше не используется как тип переменной. Устаревший вызов media scanner удалён.

## Что проверено статически

- Все Kotlin-файлы проекта, включая unit-тесты: баланс скобок, строк и комментариев.
- Все внутренние импорты `ru.tusur.*` сопоставлены с объявлениями внутри проекта.
- Регрессионные условия: `DownloadManager.Request(...).apply`, наличие заголовков `User-Agent` и `Cookie` внутри блока, передача именно `request` в `enqueue`, отсутствие `allowScanningByMediaScanner` в цепочке.
- Сохранены проверки исправлений из 0.4.6: `normalizeTableLabel`, `uniquePublicDownloadName` и callback параметров теста.
- Проверены `versionName=0.4.7`, `versionCode=21`, `applicationId=ru.tusur.study`.

## Результат

Статический скрипт завершился без замечаний: 15 Kotlin-файлов, 32 внутренних импорта, все целевые регрессионные проверки пройдены.

Gradle, компилятор Kotlin и APK-сборка не запускались. Это проверка исходного кода и конкретного потока типов; она не является полной проверкой типизации всех Android/Compose API.
