# Статический тест-план Moodle ТУСУР 0.4.6

Проверки этой версии выполняются по исходному коду без запуска Gradle/Android APK сборки.

1. Проверить, что `normalizeTableLabel` объявлена ровно один раз и доступна из `MoodleDirectRepository`.
2. Проверить ссылки обоих мест вызова `normalizeTableLabel` (таблица попыток и label/value на странице попытки).
3. Проверить, что `uniquePublicDownloadName` объявлена на уровне файла до использования в `downloadFromWebView`.
4. Проверить обработки nullable/отсутствующей службы `DownloadManager` при загрузке, запросе списка, открытии и удалении файлов.
5. Проверить все внутренние импорты `ru.tusur.*` по объявлениям исходников.
6. Проверить баланс скобок и строковых литералов всех Kotlin-файлов.
7. Сверить сигнатуру `onQuizMetadata` в `MoodleWebViewScreen`, `MainActivity` и `MoodleViewModel.saveQuizPageMetadata`.
8. Убедиться, что версия `versionName=0.4.6`, `versionCode=20`, `applicationId=ru.tusur.study`.

Полноценная проверка типов Android/Compose без Android SDK и зависимостей невозможна; эта версия не объявляется собранной или протестированной на устройстве.
